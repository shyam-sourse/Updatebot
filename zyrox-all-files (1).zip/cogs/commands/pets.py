# ╔══════════════════════════════════════════════════════════════════╗
# ║   Pets  ──  adopt a pet, feed it, play with it, level it up        ║
# ║   petshop • adoptpet • pet • feed • play • renamepet • pettopp      ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Virtual pets bought with economy coins. Premium unlocks rare species."""

from __future__ import annotations

import os
import random
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils import premium
from utils.emoji import CROSS, HEARTS, INFO, KING, MONEY, SPARKLE, TICK
from utils.premium_ui import send_limit

from .economy import money

DB = "db/pets.db"
ECO_DB = "db/economy.db"
COLOR = 0xFF0000

SPECIES = {
    "cat": ("🐱", 500, False),
    "dog": ("🐶", 500, False),
    "rabbit": ("🐰", 400, False),
    "panda": ("🐼", 1500, False),
    "dragon": ("🐲", 5000, True),
    "phoenix": ("🦅", 7500, True),
}
FEED_COOLDOWN = timedelta(hours=2)
PLAY_COOLDOWN = timedelta(hours=1)
FEED_XP = 8
PLAY_XP = 5
LEVEL_XP = 50
MAX_LEVEL = 50

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS pets (
        pet_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        species TEXT NOT NULL,
        name TEXT NOT NULL,
        xp INTEGER NOT NULL DEFAULT 0,
        last_fed TEXT,
        last_played TEXT,
        adopted_at TEXT
    )
    """,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def level_for(xp: int) -> int:
    return min(MAX_LEVEL, 1 + int(xp) // LEVEL_XP)


class Pets(commands.Cog):
    """Adopt, feed and level virtual pets."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (HEARTS, "Pets", "Adopt a pet, feed it and level it up with coins.")

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _eco(self):
        os.makedirs("db", exist_ok=True)
        db = await aiosqlite.connect(ECO_DB)
        db.row_factory = aiosqlite.Row
        await db.execute(
            "CREATE TABLE IF NOT EXISTS eco_users ("
            "guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, "
            "coins INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, "
            "streak INTEGER NOT NULL DEFAULT 0, last_daily TEXT, last_work TEXT, "
            "PRIMARY KEY (guild_id, user_id))")
        await db.commit()
        return db

    async def _wallet(self, guild_id: int, user_id: int):
        db = await self._eco()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            async with db.execute(
                "SELECT * FROM eco_users WHERE guild_id = ? AND user_id = ?",
                (guild_id, user_id)
            ) as cur:
                return await cur.fetchone()
        finally:
            await db.close()

    async def _pay(self, guild_id: int, user_id: int, amount: int) -> bool:
        db = await self._eco()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            async with db.execute(
                "SELECT coins FROM eco_users WHERE guild_id = ? AND user_id = ?",
                (guild_id, user_id)
            ) as cur:
                row = await cur.fetchone()
            if not row or int(row["coins"]) < amount:
                return False
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, user_id))
            await db.commit()
        finally:
            await db.close()
        return True

    # ── commands ─────────────────────────────────────────────────────
    @commands.command(name="petshop", aliases=["petstore"],
                      help="Browse the pets you can adopt.")
    @commands.guild_only()
    async def petshop(self, ctx):
        paid = await premium.is_paid(ctx.guild.id)
        lines = []
        for key, (emoji, price, premium_only) in SPECIES.items():
            lock = "" if paid or not premium_only else " 🔒 premium"
            lines.append(f"{emoji} **{key.title()}** — {money(price)} coins{lock}")
        wallet = await self._wallet(ctx.guild.id, ctx.author.id)
        await ctx.reply(embed=self.embed(
            f"{HEARTS} Pet Shop",
            "\n".join(lines) + f"\n\n**Your cash:** {money(wallet['coins'])} coins\n"
            f"Adopt with `{ctx.clean_prefix}adoptpet <species> [name]`."),
            mention_author=False)

    @commands.command(name="adoptpet", aliases=["buypet", "newpet"],
                      help="Buy a pet from the pet shop.")
    @commands.guild_only()
    @commands.cooldown(1, 6, commands.BucketType.user)
    async def adoptpet(self, ctx, species: str = None, *, name: str = None):
        key = (species or "").strip().lower()
        if key not in SPECIES:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}adoptpet cat Fluffy` — see `{ctx.clean_prefix}petshop`."))
        emoji, price, premium_only = SPECIES[key]
        if premium_only and not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Pet",
                f"**{key.title()}** is a **Premium** pet.\n"
                f"Run `{ctx.clean_prefix}premium` to unlock it."))
        limit = await premium.limit_for(ctx.guild.id, "pets")
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) FROM pets WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, ctx.author.id)
            ) as cur:
                owned = int((await cur.fetchone())[0])
            if limit is not None and owned >= limit:
                return await send_limit(ctx, "pets", owned, limit, guild_id=ctx.guild.id)
            if not await self._pay(ctx.guild.id, ctx.author.id, price):
                wallet = await self._wallet(ctx.guild.id, ctx.author.id)
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Coins",
                    f"**{key.title()}** costs **{money(price)}** coins, "
                    f"you have **{money(wallet['coins'])}**."))
            pet_name = (name or key.title()).strip()[:32]
            await db.execute(
                "INSERT INTO pets (guild_id, user_id, species, name, adopted_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (ctx.guild.id, ctx.author.id, key, pet_name, _now().isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Pet Adopted",
            f"{emoji} **{pet_name}** the {key} is now yours!\n"
            f"Feed with `{ctx.clean_prefix}feed` and play with `{ctx.clean_prefix}play`."),
            mention_author=False)

    @commands.command(name="pet", aliases=["mypet", "pets"],
                      help="Show your pets and their level.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def pet(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM pets WHERE guild_id = ? AND user_id = ? ORDER BY pet_id",
                (ctx.guild.id, member.id)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Pets",
                f"{member.display_name} has no pets yet. Try `{ctx.clean_prefix}petshop`."))
        embed = self.embed(f"{HEARTS} {member.display_name}'s Pets", "")
        for row in rows:
            emoji = SPECIES.get(row["species"], ("🐾", 0, False))[0]
            lvl = level_for(int(row["xp"]))
            into = int(row["xp"]) % LEVEL_XP
            embed.add_field(
                name=f"{emoji} {row['name']} · Lv {lvl}",
                value=f"{row['species'].title()} · XP {into}/{LEVEL_XP}",
                inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    async def _active_pet(self, ctx, name: str | None):
        db = await self._connect()
        try:
            if name:
                async with db.execute(
                    "SELECT * FROM pets WHERE guild_id = ? AND user_id = ? AND "
                    "LOWER(name) = ?", (ctx.guild.id, ctx.author.id, name.strip().lower())
                ) as cur:
                    return await cur.fetchone()
            async with db.execute(
                "SELECT * FROM pets WHERE guild_id = ? AND user_id = ? ORDER BY pet_id LIMIT 1",
                (ctx.guild.id, ctx.author.id)
            ) as cur:
                return await cur.fetchone()
        finally:
            await db.close()

    @commands.command(name="feed", aliases=["feedpet"],
                      help="Feed your pet for XP (2 hour cooldown).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def feed(self, ctx, *, pet_name: str = None):
        await self._care(ctx, pet_name, "feed")

    @commands.command(name="playpet", aliases=["petplay"],
                      help="Play with your pet for XP (1 hour cooldown).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def play(self, ctx, *, pet_name: str = None):
        await self._care(ctx, pet_name, "play")

    async def _care(self, ctx, pet_name: str | None, action: str):
        pet = await self._active_pet(ctx, pet_name)
        if pet is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Pet", f"Adopt one with `{ctx.clean_prefix}adoptpet cat`."))
        field = "last_fed" if action == "feed" else "last_played"
        cooldown = FEED_COOLDOWN if action == "feed" else PLAY_COOLDOWN
        gain = FEED_XP if action == "feed" else PLAY_XP
        last = pet[field]
        if last:
            try:
                last_dt = datetime.fromisoformat(last)
            except ValueError:
                last_dt = None
            if last_dt and _now() < last_dt + cooldown:
                ready = last_dt + cooldown
                return await ctx.reply(embed=self.embed(
                    f"{INFO} Not Yet",
                    f"**{pet['name']}** is not ready — try again "
                    f"<t:{int(ready.timestamp())}:R>."))
        emoji = SPECIES.get(pet["species"], ("🐾", 0, False))[0]
        before = level_for(int(pet["xp"]))
        xp = int(pet["xp"]) + gain
        after = level_for(xp)
        db = await self._connect()
        try:
            await db.execute(
                f"UPDATE pets SET xp = ?, {field} = ? WHERE pet_id = ?",
                (xp, _now().isoformat(), int(pet["pet_id"])))
            await db.commit()
        finally:
            await db.close()
        verb = "munched some treats" if action == "feed" else "had a great time playing"
        extra = f"\n🎉 **Level up!** {before} → **{after}**" if after > before else ""
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} {emoji} {pet['name']}",
            f"**{pet['name']}** {verb} — **+{gain} XP**.{extra}"),
            mention_author=False)

    @commands.command(name="renamepet", aliases=["petname"],
                      help="Rename one of your pets.")
    @commands.guild_only()
    async def renamepet(self, ctx, old: str = None, *, new: str = None):
        if not old or not new:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}renamepet Fluffy Snowy`"))
        pet = await self._active_pet(ctx, old)
        if pet is None:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} No Such Pet", f"You have no pet called **{old}**."))
        db = await self._connect()
        try:
            await db.execute(
                "UPDATE pets SET name = ? WHERE pet_id = ?", (new.strip()[:32], int(pet["pet_id"])))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Renamed", f"**{pet['name']}** is now **{new.strip()[:32]}**."),
            mention_author=False)

    @commands.command(name="releasepet", aliases=["abandonpet"],
                      help="Release a pet back into the wild.")
    @commands.guild_only()
    async def releasepet(self, ctx, *, pet_name: str = None):
        pet = await self._active_pet(ctx, pet_name)
        if pet is None:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} No Such Pet", "You have no pet by that name."))
        db = await self._connect()
        try:
            await db.execute("DELETE FROM pets WHERE pet_id = ?", (int(pet["pet_id"]),))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{INFO} Pet Released", f"**{pet['name']}** ran off into the wild."),
            mention_author=False)

    @commands.command(name="pettopp", aliases=["pettop", "petleaderboard"],
                      help="Highest level pets on this server.")
    @commands.guild_only()
    @commands.cooldown(1, 6, commands.BucketType.channel)
    async def pettopp(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT user_id, name, species, xp FROM pets WHERE guild_id = ? "
                "ORDER BY xp DESC LIMIT 10", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Pets Yet", "Nobody has adopted a pet on this server."))
        lines = []
        for index, row in enumerate(rows, start=1):
            medal = KING if index == 1 else f"`#{index}`"
            emoji = SPECIES.get(row["species"], ("🐾", 0, False))[0]
            lines.append(f"{medal} {emoji} **{row['name']}** — Lv {level_for(int(row['xp']))} "
                         f"(<@{int(row['user_id'])}>)")
        await ctx.reply(embed=self.embed(f"{HEARTS} Pet Leaderboard", "\n".join(lines)),
                        mention_author=False)


async def setup(bot):
    await bot.add_cog(Pets(bot))
