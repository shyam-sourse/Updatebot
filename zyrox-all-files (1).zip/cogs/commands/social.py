# ╔══════════════════════════════════════════════════════════════════╗
# ║   Social  ──  reputation, profile cards and marriages              ║
# ║   rep • userprofile • bio • marry • divorce • repboard             ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Light social layer: give reputation, show a profile card, marry a member.

Reputation is limited per giver per day (3 free / 10 premium / unlimited on
Premium+). Profile cards mix coins from the economy, XP from leveling and rep.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils import premium
from utils.emoji import BOOST, CROSS, HEARTS, INFO, KING, MONEY, SPARKLE, TICK
from utils.premium_ui import send_limit

DB = "db/social.db"
COLOR = 0xFF0000

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS social_users (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        rep INTEGER NOT NULL DEFAULT 0,
        bio TEXT,
        married_to INTEGER,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS rep_given (
        guild_id INTEGER NOT NULL,
        giver_id INTEGER NOT NULL,
        day TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, giver_id, day)
    )
    """,
)


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


class MarryView(discord.ui.View):
    """Accept / decline buttons for a marriage proposal."""

    def __init__(self, cog: "Social", guild_id: int, proposer_id: int, target_id: int):
        super().__init__(timeout=120)
        self.cog = cog
        self.guild_id = guild_id
        self.proposer_id = proposer_id
        self.target_id = target_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.target_id:
            await interaction.response.send_message(
                "This proposal is not addressed to you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success, emoji="💍")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        error = await self.cog.set_marriage(self.guild_id, self.proposer_id, self.target_id)
        self.stop()
        if error:
            return await interaction.response.edit_message(
                embed=self.cog.embed(f"{CROSS} Could Not Marry", error), view=None)
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{HEARTS} Just Married",
            f"<@{self.proposer_id}> and <@{self.target_id}> are now married! 💍"), view=None)

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.secondary, emoji="✖️")
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{CROSS} Proposal Declined",
            f"<@{self.target_id}> said no. Maybe next time."), view=None)


class Social(commands.Cog):
    """Reputation, profile cards and marriages."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (HEARTS, "Social", "Reputation, profile cards and marriages.")

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _user(self, db, guild_id: int, user_id: int):
        await db.execute(
            "INSERT OR IGNORE INTO social_users (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id))
        async with db.execute(
            "SELECT * FROM social_users WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ) as cur:
            return await cur.fetchone()

    async def _accent(self, guild_id: int, user_id: int):
        """Read the premium profile accent set through Social+."""
        path = "db/socialplus.db"
        if not os.path.exists(path):
            return None
        try:
            async with aiosqlite.connect(f"file:{path}?mode=ro", uri=True) as db:
                async with db.execute(
                    "SELECT accent FROM profile_extras WHERE guild_id = ? AND user_id = ?",
                    (guild_id, user_id)
                ) as cur:
                    row = await cur.fetchone()
            if row and row[0]:
                return discord.Colour(int(row[0], 16))
        except Exception:
            return None
        return None

    # ── marriage helpers ─────────────────────────────────────────────
    async def set_marriage(self, guild_id: int, first_id: int, second_id: int) -> str | None:
        """Marry two members. Returns an error string, or None on success."""
        db = await self._connect()
        try:
            first = await self._user(db, guild_id, first_id)
            second = await self._user(db, guild_id, second_id)
            if first["married_to"] and int(first["married_to"]) != second_id:
                return "One of you is already married."
            if second["married_to"] and int(second["married_to"]) != first_id:
                return "One of you is already married."
            await db.execute(
                "UPDATE social_users SET married_to = ? WHERE guild_id = ? AND user_id = ?",
                (second_id, guild_id, first_id))
            await db.execute(
                "UPDATE social_users SET married_to = ? WHERE guild_id = ? AND user_id = ?",
                (first_id, guild_id, second_id))
            await db.commit()
        finally:
            await db.close()
        return None

    # ── commands ─────────────────────────────────────────────────────
    @commands.command(name="rep", aliases=["reputation", "vouch"],
                      help="Give a reputation point to a member.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def rep(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}rep @member`"))
        if member.bot:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Bots Have No Rep", "Pick a human member."))
        if member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Nice Try", "You cannot rep yourself."))
        limit = await premium.limit_for(ctx.guild.id, "rep_per_day")
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT amount FROM rep_given WHERE guild_id = ? AND giver_id = ? AND day = ?",
                (ctx.guild.id, ctx.author.id, _today())
            ) as cur:
                row = await cur.fetchone()
            used = int(row["amount"]) if row else 0
            if limit is not None and used >= limit:
                return await send_limit(ctx, "rep_per_day", used, limit, guild_id=ctx.guild.id)
            await db.execute(
                "INSERT INTO rep_given (guild_id, giver_id, day, amount) VALUES (?, ?, ?, 1) "
                "ON CONFLICT(guild_id, giver_id, day) DO UPDATE SET amount = amount + 1",
                (ctx.guild.id, ctx.author.id, _today()))
            await self._user(db, ctx.guild.id, member.id)
            await db.execute(
                "UPDATE social_users SET rep = rep + 1 WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, member.id))
            await db.commit()
            target = await self._user(db, ctx.guild.id, member.id)
        finally:
            await db.close()
        remaining = "∞" if limit is None else str(max(0, limit - used - 1))
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Reputation Given",
            f"{ctx.author.mention} gave +1 rep to {member.mention}.\n"
            f"**{member.display_name}** now has **{int(target['rep'])}** rep.\n"
            f"Your reps left today: **{remaining}**"), mention_author=False)

    @commands.command(name="userprofile", aliases=["uprofile", "myprofile"],
                      help="Show a member's profile card.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def userprofile(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db = await self._connect()
        try:
            row = await self._user(db, ctx.guild.id, member.id)
        finally:
            await db.close()

        coins = await premium.count_rows(
            "db/economy.db",
            "SELECT coins + bank FROM eco_users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id))
        level = await premium.count_rows(
            "db/leveling.db",
            "SELECT level FROM users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id))
        xp = await premium.count_rows(
            "db/leveling.db",
            "SELECT xp FROM users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id))

        spouse_id = row["married_to"] if row else None
        spouse = ctx.guild.get_member(int(spouse_id)) if spouse_id else None
        plan = (await premium.get_plan(guild_id=ctx.guild.id))["name"]

        badges = [KING] if member.id == ctx.guild.owner_id else []
        if member.premium_since:
            badges.append(BOOST)

        description = []
        if row and row["bio"]:
            description.append(f"*{row['bio']}*")
        description.append(
            f"**Reputation:** {int(row['rep']) if row else 0}\n"
            f"**Coins:** {coins:,}\n"
            f"**Level:** {level or 1} · **XP:** {xp:,}\n"
            f"**Married to:** {spouse.mention if spouse else 'nobody'}")
        if badges:
            description.append("**Badges:** " + " ".join(badges))

        embed = self.embed(f"{HEARTS} {member.display_name}", "\n\n".join(description))
        accent = await self._accent(ctx.guild.id, member.id)
        if accent is not None:
            embed.colour = accent
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>"
                        if member.joined_at else "unknown", inline=True)
        embed.add_field(name="Created", value=f"<t:{int(member.created_at.timestamp())}:R>",
                        inline=True)
        embed.set_footer(text=f"{ctx.guild.name} · {plan} plan")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="bio", aliases=["setbio"],
                      help="Set the short bio shown on your profile (premium).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def bio(self, ctx, *, text: str = None):
        plan = await premium.get_plan_key(ctx.guild.id)
        if plan == premium.FREE:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature",
                f"Custom profile bios are **Premium**.\n"
                f"Run `{ctx.clean_prefix}premium` to unlock them."), mention_author=False)
        db = await self._connect()
        try:
            await self._user(db, ctx.guild.id, ctx.author.id)
            if not text:
                await db.execute(
                    "UPDATE social_users SET bio = NULL WHERE guild_id = ? AND user_id = ?",
                    (ctx.guild.id, ctx.author.id))
                await db.commit()
                return await ctx.reply(embed=self.embed(
                    f"{TICK} Bio Cleared", "Your profile bio has been removed."))
            await db.execute(
                "UPDATE social_users SET bio = ? WHERE guild_id = ? AND user_id = ?",
                (text.strip()[:200], ctx.guild.id, ctx.author.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Bio Saved", f"Your profile now shows:\n*{text.strip()[:200]}*"),
            mention_author=False)

    @commands.command(name="marry", aliases=["propose"],
                      help="Propose to another member.")
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def marry(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}marry @member`"))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Propose to another human member."))
        db = await self._connect()
        try:
            mine = await self._user(db, ctx.guild.id, ctx.author.id)
            theirs = await self._user(db, ctx.guild.id, member.id)
        finally:
            await db.close()
        if mine["married_to"]:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Already Married",
                f"You are already married to <@{int(mine['married_to'])}>. "
                f"Use `{ctx.clean_prefix}divorce` first."))
        if theirs["married_to"]:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} They Are Taken",
                f"{member.mention} is already married to <@{int(theirs['married_to'])}>."))
        await ctx.reply(
            content=member.mention,
            embed=self.embed(
                f"{HEARTS} Marriage Proposal",
                f"{ctx.author.mention} is proposing to {member.mention}!\n\n"
                f"{member.mention}, do you accept? You have 2 minutes."),
            view=MarryView(self, ctx.guild.id, ctx.author.id, member.id),
            mention_author=False)

    @commands.command(name="divorce", aliases=["breakup"],
                      help="End your marriage.")
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def divorce(self, ctx):
        db = await self._connect()
        try:
            mine = await self._user(db, ctx.guild.id, ctx.author.id)
            spouse_id = mine["married_to"]
            if not spouse_id:
                return await ctx.reply(embed=self.embed(
                    f"{INFO} Not Married", "You are not married to anyone."))
            await db.execute(
                "UPDATE social_users SET married_to = NULL WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, ctx.author.id))
            await db.execute(
                "UPDATE social_users SET married_to = NULL WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, int(spouse_id)))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{CROSS} Divorced",
            f"{ctx.author.mention} and <@{int(spouse_id)}> are no longer married."),
            mention_author=False)

    @commands.command(name="repboard", aliases=["reptop", "toprep"],
                      help="Members with the most reputation.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def repboard(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT user_id, rep FROM social_users WHERE guild_id = ? AND rep > 0 "
                "ORDER BY rep DESC LIMIT 10", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Reputation Yet",
                f"Nobody has rep here. Try `{ctx.clean_prefix}rep @member`."))
        lines = []
        for index, row in enumerate(rows, start=1):
            member = ctx.guild.get_member(int(row["user_id"]))
            name = member.mention if member else f"`{row['user_id']}`"
            medal = KING if index == 1 else f"`#{index}`"
            lines.append(f"{medal} {name} — **{int(row['rep'])}** rep")
        await ctx.reply(embed=self.embed(f"{SPARKLE} Reputation Board", "\n".join(lines)),
                        mention_author=False)


async def setup(bot):
    await bot.add_cog(Social(bot))
