"""One-time No-Prefix Trial panel with a claim button.

Staff post the panel with ``nptrial panel``. Any member can press
"Claim No-Prefix Trial" once and gets ``utils.nptrial.TRIAL_DAYS`` days of
prefix-free commands (7 by default, override with ``NP_TRIAL_DAYS``).
"""

from __future__ import annotations

from datetime import datetime

import discord
from discord.ext import commands

from utils import nptrial
from utils.config import BRAND_NAME, OWNER_IDS

COLOR = 0x9B59B6
GREEN = 0x2ECC71


def is_staff(member: discord.Member | None) -> bool:
    if member is None:
        return False
    if member.id in OWNER_IDS:
        return True
    perms = getattr(member, "guild_permissions", None)
    return bool(perms is not None and (perms.administrator or perms.manage_guild))


async def _reply(ctx, message: str | None = None, ephemeral: bool = False, embed=None):
    kwargs: dict = {}
    if message is not None:
        kwargs["content"] = message
    if embed is not None:
        kwargs["embed"] = embed
    if ctx.interaction is not None:
        kwargs["ephemeral"] = ephemeral
        if ctx.interaction.response.is_done():
            return await ctx.interaction.followup.send(**kwargs)
        return await ctx.interaction.response.send_message(**kwargs)
    return await ctx.send(**kwargs)


def trial_embed(guild: discord.Guild | None = None) -> discord.Embed:
    embed = discord.Embed(
        title="🎁 No-Prefix Trial",
        description=(
            "Unlock **prefix-free commands** for a limited time.\n"
            "Tap the button below to activate your trial instantly."
        ),
        color=COLOR,
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="Duration", value=f"> **{nptrial.TRIAL_DAYS} days**", inline=False)
    embed.add_field(name="Eligibility", value="> One claim per member", inline=False)
    embed.add_field(name="Benefit", value="> Run commands without typing a prefix", inline=False)
    icon = getattr(guild, "icon", None)
    if icon is not None:
        embed.set_thumbnail(url=icon.url)
    embed.set_footer(text=f"{BRAND_NAME} · No-Prefix Trial System")
    return embed


def activated_embed(trial: dict) -> discord.Embed:
    expires = datetime.fromisoformat(trial["expires_at"])
    embed = discord.Embed(
        title="✅ No-Prefix Trial Activated",
        description=(
            "You can now run commands **without a prefix**.\n\n"
            f"**Trial ends:** {discord.utils.format_dt(expires, 'F')} "
            f"({discord.utils.format_dt(expires, 'R')})\n"
            "Try typing `help` in chat — no prefix needed."
        ),
        color=GREEN,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_footer(text=f"{BRAND_NAME} · No-Prefix Trial System")
    return embed


class ClaimButton(discord.ui.Button):
    def __init__(self, cog: "NoPrefixTrial"):
        super().__init__(
            label="Claim No-Prefix Trial",
            emoji="🎁",
            style=discord.ButtonStyle.success,
            custom_id="nptrial:claim",
        )
        self.cog = cog

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        if await nptrial.has_permanent(interaction.user.id):
            return await interaction.followup.send(
                "✅ You already have **No-Prefix** — your commands already work "
                "without a prefix.",
                ephemeral=True,
            )

        status, trial = await nptrial.claim(
            interaction.user.id,
            interaction.guild.id if interaction.guild else None,
        )

        if status == "error":
            return await interaction.followup.send(
                "❌ Could not activate the trial right now. Please try again later.",
                ephemeral=True,
            )

        if status == "claimed":
            if trial and await nptrial.is_active(interaction.user.id):
                expires = datetime.fromisoformat(trial["expires_at"])
                return await interaction.followup.send(
                    f"You already claimed your trial — it ends "
                    f"{discord.utils.format_dt(expires, 'R')}.",
                    ephemeral=True,
                )
            return await interaction.followup.send(
                "You already used your **one** No-Prefix Trial.", ephemeral=True
            )

        if trial is None:
            return await interaction.followup.send(
                "✅ Trial activated.", ephemeral=True
            )
        await interaction.followup.send(embed=activated_embed(trial), ephemeral=True)


class ClaimView(discord.ui.View):
    def __init__(self, cog: "NoPrefixTrial"):
        super().__init__(timeout=None)
        self.add_item(ClaimButton(cog))


class NoPrefixTrial(commands.Cog, name="NoPrefixTrial"):
    def __init__(self, bot):
        self.bot = bot
        bot.loop.create_task(nptrial.init())
        try:
            bot.add_view(ClaimView(self))
        except ValueError:
            pass

    def help_custom(self):
        return "🎁", "No-Prefix Trial", "Claim free prefix-free commands for a few days"

    @commands.hybrid_group(
        name="nptrial",
        invoke_without_command=True,
        description="No-prefix trial panel and member status.",
    )
    async def nptrial_group(self, ctx):
        await ctx.send_help(ctx.command)

    @nptrial_group.command(name="panel", description="Post the claimable No-Prefix Trial panel.")
    async def panel(self, ctx):
        if not is_staff(ctx.author):
            return await _reply(
                ctx, "Only admins can post the trial panel.", ephemeral=True
            )
        await ctx.send(embed=trial_embed(ctx.guild), view=ClaimView(self))
        if ctx.interaction is not None:
            await _reply(ctx, "✅ Panel posted.", ephemeral=True)

    @nptrial_group.command(name="status", description="Check a member's No-Prefix Trial.")
    async def status(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        if member != ctx.author and not is_staff(ctx.author):
            return await _reply(
                ctx, "Only admins can check another member's trial.", ephemeral=True
            )

        trial = await nptrial.get_trial(member.id)
        if not trial:
            return await _reply(
                ctx,
                f"**{member.display_name}** has not claimed a No-Prefix Trial yet.",
                ephemeral=True,
            )

        expires = datetime.fromisoformat(trial["expires_at"])
        claimed = datetime.fromisoformat(trial["claimed_at"])
        active = await nptrial.is_active(member.id)
        embed = discord.Embed(
            title="🎁 No-Prefix Trial Status",
            description=(
                f"**Member:** {member.mention}\n"
                f"**Claimed:** {discord.utils.format_dt(claimed, 'f')}\n"
                f"**Ends:** {discord.utils.format_dt(expires, 'F')}\n"
                f"**Status:** {'Active ✅' if active else 'Expired ❌'}"
            ),
            color=GREEN if active else 0x95A5A6,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text=f"{BRAND_NAME} · No-Prefix Trial System")
        await _reply(ctx, embed=embed, ephemeral=True)

    @nptrial_group.command(name="remove", description="Clear a member's trial so they can claim again.")
    async def remove(self, ctx, member: discord.Member):
        if not is_staff(ctx.author):
            return await _reply(
                ctx, "Only admins can reset trials.", ephemeral=True
            )
        removed = await nptrial.remove(member.id)
        if not removed:
            return await _reply(
                ctx, f"{member.mention} has no trial record.", ephemeral=True
            )
        await _reply(
            ctx, f"🗑️ Cleared the trial for {member.mention}. They can claim again."
        )


async def setup(bot):
    await bot.add_cog(NoPrefixTrial(bot))
