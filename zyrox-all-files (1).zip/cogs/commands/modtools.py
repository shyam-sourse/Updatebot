# ╔══════════════════════════════════════════════════════════════════╗
# ║   Mod Tools  ──  tempban, softban, mass role                       ║
# ║   tempban • tempbans • untempban • softban • massrole              ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Extra moderation actions that the moderation package does not cover.

``tempban`` stores an expiry and a background task unbans automatically.
``softban`` wipes recent messages and immediately unbans.
``massrole`` adds or removes one role for every human member (Premium).
"""

from __future__ import annotations

import os
import re
import time

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import premium
from utils.botlog import botlog
from utils.emoji import CROSS, INFO, TICK, WARNING, ZBAN

DB = "db/modtools.db"
COLOR = 0xFF0000

DURATION_RE = re.compile(r"^(\d{1,4})\s*([smhdw])$", re.IGNORECASE)
UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
UNIT_NAMES = {"s": "seconds", "m": "minutes", "h": "hours", "d": "days", "w": "weeks"}


def parse_duration(raw: str | None) -> int | None:
    """``1d`` / ``12h`` / ``30m`` → seconds, else None."""
    if not raw:
        return None
    match = DURATION_RE.match(raw.strip())
    if not match:
        return None
    amount, unit = match.groups()
    return int(amount) * UNITS[unit.lower()]


def human_duration(seconds: int) -> str:
    if seconds % 604800 == 0:
        return f"{seconds // 604800} week(s)"
    if seconds % 86400 == 0:
        return f"{seconds // 86400} day(s)"
    if seconds % 3600 == 0:
        return f"{seconds // 3600} hour(s)"
    if seconds % 60 == 0:
        return f"{seconds // 60} minute(s)"
    return f"{seconds} second(s)"


SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS tempbans (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        reason TEXT,
        moderator_id INTEGER,
        created_at INTEGER,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
)


class ModTools(commands.Cog):
    """Temporary bans, softbans and bulk role changes."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (ZBAN, "Mod Tools", "Temporary bans, softbans and mass role changes.")

    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    # ── storage ──────────────────────────────────────────────────────
    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def cog_load(self):
        self.expire_bans.start()

    async def cog_unload(self):
        self.expire_bans.cancel()

    @tasks.loop(seconds=60)
    async def expire_bans(self):
        try:
            await self._ensure()
            db = await self._connect()
            try:
                async with db.execute(
                    "SELECT * FROM tempbans WHERE expires_at <= ?", (int(time.time()),)
                ) as cur:
                    rows = await cur.fetchall()
            finally:
                await db.close()
        except Exception:
            return
        for row in rows:
            guild = self.bot.get_guild(int(row["guild_id"]))
            if guild is None:
                continue
            try:
                await guild.unban(discord.Object(id=int(row["user_id"])),
                                  reason="Temporary ban expired")
            except discord.NotFound:
                pass
            except discord.HTTPException:
                continue
            db = await self._connect()
            try:
                await db.execute(
                    "DELETE FROM tempbans WHERE guild_id = ? AND user_id = ?",
                    (int(row["guild_id"]), int(row["user_id"])))
                await db.commit()
            finally:
                await db.close()

    @expire_bans.before_loop
    async def _wait_ready(self):
        await self.bot.wait_until_ready()

    # ── helpers ──────────────────────────────────────────────────────
    def _hierarchy_error(self, ctx, member) -> str | None:
        if member.id == ctx.author.id:
            return "You cannot moderate yourself."
        if member.id == self.bot.user.id:
            return "I cannot moderate myself."
        if member.id == ctx.guild.owner_id:
            return "You cannot moderate the server owner."
        if ctx.author.id != ctx.guild.owner_id and member.top_role >= ctx.author.top_role:
            return "That member's top role is equal to or higher than yours."
        if member.top_role >= ctx.guild.me.top_role:
            return "That member's top role is higher than mine — move my role up first."
        return None

    # ── tempban ──────────────────────────────────────────────────────
    @commands.command(name="tempban", aliases=["tban", "banfor"],
                      help="Ban a member for a set time (e.g. 1d, 12h, 30m).")
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def tempban(self, ctx, member: discord.Member = None, duration: str = None,
                      *, reason: str = "No reason provided"):
        if member is None or duration is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}tempban @member 1d spamming`\n"
                f"Units: `s` `m` `h` `d` `w`"), mention_author=False)
        seconds = parse_duration(duration)
        if seconds is None:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Duration",
                "Use a number and unit, like `30m`, `12h`, `1d` or `1w`."))
        max_days = await premium.limit_for(ctx.guild.id, "tempban_days")
        if max_days is not None and seconds > max_days * 86400:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Too Long",
                f"Your plan allows tempbans up to **{max_days} days**.\n"
                f"Run `{ctx.clean_prefix}premium` for longer bans."), mention_author=False)
        problem = self._hierarchy_error(ctx, member)
        if problem:
            return await ctx.reply(embed=self.embed(f"{CROSS} Cannot Ban", problem))
        try:
            await member.ban(reason=f"[tempban {duration}] {reason} — by {ctx.author}")
        except discord.HTTPException as error:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Ban Failed", f"Discord refused the ban: `{error}`"))
        expires_at = int(time.time()) + seconds
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO tempbans (guild_id, user_id, expires_at, reason, moderator_id, "
                "created_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(guild_id, user_id) "
                "DO UPDATE SET expires_at = excluded.expires_at, reason = excluded.reason, "
                "moderator_id = excluded.moderator_id, created_at = excluded.created_at",
                (ctx.guild.id, member.id, expires_at, reason, ctx.author.id, int(time.time())))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Member Tempbanned",
            f"**{member}** is banned for **{human_duration(seconds)}**.\n"
            f"**Reason:** {reason}\nUnban: <t:{expires_at}:R>"), mention_author=False)
        botlog.log("Tempban", description=(
            f"**User:** {member} (`{member.id}`)\n**Server:** {ctx.guild.name}\n"
            f"**Duration:** {human_duration(seconds)}\n**Moderator:** {ctx.author}\n"
            f"**Reason:** {reason}"), color=COLOR)

    @commands.command(name="tempbans", aliases=["tbans"],
                      help="List active temporary bans on this server.")
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    async def tempbans(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM tempbans WHERE guild_id = ? ORDER BY expires_at",
                (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Tempbans", "Nobody is temporarily banned right now."))
        lines = [
            f"<@{row['user_id']}> (`{row['user_id']}`) — ends <t:{int(row['expires_at'])}:R>"
            f"\n  ↳ {(row['reason'] or 'No reason')[:120]}"
            for row in rows[:20]
        ]
        await ctx.reply(embed=self.embed(
            f"{WARNING} Active Tempbans — {len(rows)}", "\n".join(lines)[:3900]),
            mention_author=False)

    @commands.command(name="untempban", aliases=["untimeban"],
                      help="Clear a temporary ban and unban the user now.")
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def untempban(self, ctx, user_id: int = None):
        if user_id is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}untempban <user id>`"))
        try:
            await ctx.guild.unban(discord.Object(id=user_id), reason=f"Tempban cleared by {ctx.author}")
        except discord.NotFound:
            pass
        except discord.HTTPException as error:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Unban Failed", f"Discord refused the unban: `{error}`"))
        db = await self._connect()
        try:
            await db.execute(
                "DELETE FROM tempbans WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, user_id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Tempban Cleared", f"`{user_id}` is unbanned and the timer is removed."),
            mention_author=False)

    # ── softban ──────────────────────────────────────────────────────
    @commands.command(name="softban", help="Ban then instantly unban to delete recent messages.")
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def softban(self, ctx, member: discord.Member = None,
                      *, reason: str = "No reason provided"):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}softban @member spamming`"), mention_author=False)
        problem = self._hierarchy_error(ctx, member)
        if problem:
            return await ctx.reply(embed=self.embed(f"{CROSS} Cannot Softban", problem))
        try:
            await member.ban(reason=f"[softban] {reason} — by {ctx.author}",
                             delete_message_days=7)
            await ctx.guild.unban(discord.Object(id=member.id),
                                  reason=f"[softban] {reason}")
        except discord.HTTPException as error:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Softban Failed", f"Discord refused the action: `{error}`"))
        await ctx.reply(embed=self.embed(
            f"{TICK} Member Softbanned",
            f"**{member}** was banned and unbanned so their last 7 days of "
            f"messages are gone.\n**Reason:** {reason}"), mention_author=False)
        botlog.log("Softban", description=(
            f"**User:** {member} (`{member.id}`)\n**Server:** {ctx.guild.name}\n"
            f"**Moderator:** {ctx.author}\n**Reason:** {reason}"), color=COLOR)

    # ── mass role ────────────────────────────────────────────────────
    @commands.command(name="massrole", aliases=["roleall"],
                      help="Give or remove one role for every human member (premium).")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def massrole(self, ctx, role: discord.Role = None, action: str = "add"):
        plan = await premium.get_plan_key(ctx.guild.id)
        if plan == premium.FREE:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature",
                f"`massrole` is **Premium** because it touches every member.\n"
                f"Run `{ctx.clean_prefix}premium` to upgrade."), mention_author=False)
        if role is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}massrole @role add` or `... remove`"))
        if role >= ctx.guild.me.top_role or role.is_default() or role.managed:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Role Not Manageable",
                "I cannot hand out that role — it is higher than my top role, "
                "`@everyone`, or managed by an integration."))
        action = action.strip().lower()
        if action not in ("add", "remove"):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Action", "Use `add` or `remove`."))
        members = [m for m in ctx.guild.members if not m.bot]
        changed = 0
        failures = 0
        status = await ctx.reply(embed=self.embed(
            f"{WARNING} Working…",
            f"{'Adding' if action == 'add' else 'Removing'} {role.mention} "
            f"for {len(members)} members."))
        for member in members:
            has_role = role in member.roles
            if action == "add" and has_role:
                continue
            if action == "remove" and not has_role:
                continue
            try:
                if action == "add":
                    await member.add_roles(role, reason=f"massrole by {ctx.author}")
                else:
                    await member.remove_roles(role, reason=f"massrole by {ctx.author}")
                changed += 1
            except discord.HTTPException:
                failures += 1
        try:
            await status.edit(embed=self.embed(
                f"{TICK} Mass Role Done",
                f"**{role.mention}** {'added to' if action == 'add' else 'removed from'} "
                f"**{changed}** member(s)."
                + (f"\n{failures} failure(s) — check my role position." if failures else "")))
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(ModTools(bot))
