# ╔══════════════════════════════════════════════════════════════════╗
# ║   Stocks  ──  buy and sell shares in fake server companies          ║
# ║   stocks • stocks market • stocks buy • stocks sell • portfolio     ║
# ╚══════════════════════════════════════════════════════════════════╝
"""A tiny server stock market. Prices drift every few hours."""

from __future__ import annotations

import os
import random
from datetime import datetime, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import premium
from utils.emoji import CROSS, INFO, MONEY, SPARKLE, TICK

from .economy import money, parse_amount

ECO_DB = "db/economy.db"
DB = "db/stocks.db"
COLOR = 0xFF0000

SYMBOLS = {
    "ZRX": ("Zyrox Corp", 500),
    "MOON": ("Moon Labs", 300),
    "NITRO": ("Nitro Fuel", 900),
    "CODE": ("CodeX Systems", 700),
    "PIXEL": ("Pixel Forge", 1200),
}
MIN_PRICE = 25
MAX_PRICE = 50_000


def _now() -> datetime:
    return datetime.now(timezone.utc)


SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS stock_prices (
        guild_id INTEGER NOT NULL,
        symbol TEXT NOT NULL,
        price INTEGER NOT NULL,
        updated_at TEXT,
        PRIMARY KEY (guild_id, symbol)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS stock_holdings (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        symbol TEXT NOT NULL,
        shares INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, symbol)
    )
    """,
)


class Stocks(commands.Cog):
    """Buy and sell fake shares with economy coins."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (MONEY, "Stocks", "Buy and sell shares in fake server companies.")

    def cog_load(self):
        self.market_watch.start()

    def cog_unload(self):
        self.market_watch.cancel()

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _eco(self):
        os.makedirs("db", exist_ok=True)
        db = await aiosqlite.connect(ECO_DB)
        db.row_factory = aiosqlite.Row
        await db.execute(
            "CREATE TABLE IF NOT EXISTS eco_users ("
            "guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, "
            "coins INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, "
            "streak INTEGER NOT NULL DEFAULT 0, last_daily TEXT, last_work TEXT, "
            "PRIMARY KEY (guild_id, user_id))")
        await db.commit()
        return db

    async def _price(self, guild_id: int, symbol: str) -> int | None:
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT price FROM stock_prices WHERE guild_id = ? AND symbol = ?",
                (guild_id, symbol)
            ) as cur:
                row = await cur.fetchone()
            if row is not None:
                return int(row["price"])
            base = SYMBOLS[symbol][1]
            await db.execute(
                "INSERT OR IGNORE INTO stock_prices (guild_id, symbol, price, updated_at) "
                "VALUES (?, ?, ?, ?)", (guild_id, symbol, base, _now().isoformat()))
            await db.commit()
            return base
        finally:
            await db.close()

    async def _all_prices(self, guild_id: int):
        prices = {}
        for symbol in SYMBOLS:
            prices[symbol] = await self._price(guild_id, symbol)
        return prices

    async def _cash(self, guild_id: int, user_id: int) -> int:
        db = await self._eco()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            await db.commit()
            async with db.execute(
                "SELECT coins FROM eco_users WHERE guild_id = ? AND user_id = ?",
                (guild_id, user_id)
            ) as cur:
                row = await cur.fetchone()
            return int(row["coins"]) if row else 0
        finally:
            await db.close()

    async def _move_coins(self, guild_id: int, user_id: int, delta: int) -> bool:
        db = await self._eco()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            await db.commit()
            if delta < 0:
                async with db.execute(
                    "SELECT coins FROM eco_users WHERE guild_id = ? AND user_id = ?",
                    (guild_id, user_id)
                ) as cur:
                    row = await cur.fetchone()
                if not row or int(row["coins"]) < -delta:
                    return False
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (delta, guild_id, user_id))
            await db.commit()
            return True
        finally:
            await db.close()

    # ── market ───────────────────────────────────────────────────────
    @commands.group(name="stocks", aliases=["stockmarket"], invoke_without_command=True,
                    help="Show the server stock market.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def stocks(self, ctx):
        prices = await self._all_prices(ctx.guild.id)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT symbol, shares FROM stock_holdings WHERE guild_id = ? AND user_id = ? "
                "AND shares > 0", (ctx.guild.id, ctx.author.id)
            ) as cur:
                holdings = await cur.fetchall()
        finally:
            await db.close()
        lines = [f"**{symbol}** — {SYMBOLS[symbol][0]} · {money(price)} coins"
                 for symbol, price in prices.items()]
        value = sum(prices.get(row["symbol"], 0) * int(row["shares"]) for row in holdings)
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{MONEY} Stock Market",
            "\n".join(lines) + f"\n\n**Your portfolio value:** {money(value)} coins\n"
            f"`{p}stocks buy ZRX 2` · `{p}stocks sell ZRX all` · `{p}portfolio`"),
            mention_author=False)

    @stocks.command(name="market", aliases=["prices"])
    @commands.guild_only()
    async def stocks_market(self, ctx):
        prices = await self._all_prices(ctx.guild.id)
        lines = [f"`{symbol}` **{SYMBOLS[symbol][0]}** — {money(price)} coins"
                 for symbol, price in prices.items()]
        await ctx.reply(embed=self.embed(f"{MONEY} Live Prices", "\n".join(lines)),
                        mention_author=False)

    @stocks.command(name="buy")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def stocks_buy(self, ctx, symbol: str = None, shares: str = "1"):
        symbol = (symbol or "").upper()
        if symbol not in SYMBOLS:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Unknown Symbol",
                "Pick one of: " + ", ".join(f"`{s}`" for s in SYMBOLS)))
        count = parse_amount(shares)
        if count is None or count <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}stocks buy ZRX 2`"))
        price = await self._price(ctx.guild.id, symbol)
        cost = price * count
        if not await self._move_coins(ctx.guild.id, ctx.author.id, -cost):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Enough Coins",
                f"{count} × **{symbol}** costs **{money(cost)} coins**, "
                f"you have **{money(await self._cash(ctx.guild.id, ctx.author.id))}**."))
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO stock_holdings (guild_id, user_id, symbol, shares) "
                "VALUES (?, ?, ?, ?) ON CONFLICT(guild_id, user_id, symbol) "
                "DO UPDATE SET shares = shares + ?",
                (ctx.guild.id, ctx.author.id, symbol, count, count))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Shares Bought",
            f"Bought **{count} × {symbol}** for **{money(cost)} coins** "
            f"at {money(price)} each."), mention_author=False)

    @stocks.command(name="sell")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def stocks_sell(self, ctx, symbol: str = None, shares: str = "all"):
        symbol = (symbol or "").upper()
        if symbol not in SYMBOLS:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Unknown Symbol", "Pick a valid symbol from `stocks`."))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT shares FROM stock_holdings WHERE guild_id = ? AND user_id = ? "
                "AND symbol = ?", (ctx.guild.id, ctx.author.id, symbol)
            ) as cur:
                row = await cur.fetchone()
            owned = int(row["shares"]) if row else 0
            if owned < 1:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Nothing To Sell", f"You own no **{symbol}** shares."))
            count = parse_amount(shares)
            if count in (None, -1):
                count = owned
            count = min(count, owned)
            price = await self._price(ctx.guild.id, symbol)
            total = price * count
            new_shares = owned - count
            if new_shares <= 0:
                await db.execute(
                    "DELETE FROM stock_holdings WHERE guild_id = ? AND user_id = ? "
                    "AND symbol = ?", (ctx.guild.id, ctx.author.id, symbol))
            else:
                await db.execute(
                    "UPDATE stock_holdings SET shares = ? WHERE guild_id = ? "
                    "AND user_id = ? AND symbol = ?",
                    (new_shares, ctx.guild.id, ctx.author.id, symbol))
            await db.commit()
        finally:
            await db.close()
        await self._move_coins(ctx.guild.id, ctx.author.id, total)
        await ctx.reply(embed=self.embed(
            f"{TICK} Shares Sold",
            f"Sold **{count} × {symbol}** for **{money(total)} coins** "
            f"at {money(price)} each."), mention_author=False)

    @commands.command(name="portfolio", aliases=["investments", "shares"],
                      help="Show your share holdings.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def portfolio(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        prices = await self._all_prices(ctx.guild.id)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT symbol, shares FROM stock_holdings WHERE guild_id = ? "
                "AND user_id = ? AND shares > 0 ORDER BY symbol",
                (ctx.guild.id, member.id)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Shares",
                f"{member.display_name} owns no shares yet. See `{ctx.clean_prefix}stocks`."))
        lines = []
        total = 0
        for row in rows:
            price = prices.get(row["symbol"], 0)
            value = price * int(row["shares"])
            total += value
            lines.append(f"**{row['symbol']}** — {int(row['shares'])} share(s) · "
                         f"{money(value)} coins")
        embed = self.embed(f"{MONEY} {member.display_name}'s Portfolio",
                           "\n".join(lines) + f"\n\n**Total:** {money(total)} coins")
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    # ── price movement ───────────────────────────────────────────────
    @tasks.loop(hours=4)
    async def market_watch(self):
        await self.bot.wait_until_ready()
        db = await self._connect()
        try:
            async with db.execute("SELECT guild_id FROM stock_prices GROUP BY guild_id") as cur:
                guilds = [int(r["guild_id"]) for r in await cur.fetchall()]
        finally:
            await db.close()
        for guild_id in guilds:
            for symbol in SYMBOLS:
                price = await self._price(guild_id, symbol)
                drift = random.uniform(-0.15, 0.18)
                new_price = max(MIN_PRICE, min(MAX_PRICE, int(price * (1 + drift))))
                db = await self._connect()
                try:
                    await db.execute(
                        "UPDATE stock_prices SET price = ?, updated_at = ? "
                        "WHERE guild_id = ? AND symbol = ?",
                        (new_price, _now().isoformat(), guild_id, symbol))
                    await db.commit()
                finally:
                    await db.close()


async def setup(bot):
    await bot.add_cog(Stocks(bot))
