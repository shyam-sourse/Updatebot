# ╔══════════════════════════════════════════════════════════════════╗
# ║   Utility Plus  ──  reminders, trivia, coin drops, duels, notes    ║
# ║   remind • trivia • drop • duel • note • notes • delnote           ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Everyday extras: reminders, trivia rounds, coin drops, duels and staff notes."""

from __future__ import annotations

import os
import random
import re
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import premium
from utils.emoji import CROSS, INFO, MONEY, SPARKLE, TICK, TIMER, WARNING

from .economy import money

ECO_DB = "db/economy.db"
DB = "db/utilityplus.db"
COLOR = 0xFF0000

TIME_RE = re.compile(r"(\d+)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|"
                     r"h|hr|hrs|hour|hours|d|day|days)", re.IGNORECASE)
UNIT_SECONDS = {"s": 1, "m": 60, "h": 3600, "d": 86400}
MAX_REMIND = 30 * 86400

TRIVIA = (
    ("Which planet is known as the Red Planet?", "Mars",
     ["Venus", "Jupiter", "Mercury"]),
    ("How many players are on a football team on the field?", "11",
     ["10", "9", "12"]),
    ("What is the capital of Japan?", "Tokyo", ["Osaka", "Kyoto", "Seoul"]),
    ("Which language is this bot written in?", "Python",
     ["JavaScript", "Java", "C++"]),
    ("How many sides does a hexagon have?", "6", ["5", "7", "8"]),
    ("What does CPU stand for?", "Central Processing Unit",
     ["Computer Personal Unit", "Central Program Utility", "Core Process Unit"]),
    ("Which ocean is the largest?", "Pacific", ["Atlantic", "Indian", "Arctic"]),
    ("What is 15% of 200?", "30", ["25", "35", "20"]),
    ("Who wrote Romeo and Juliet?", "William Shakespeare",
     ["Charles Dickens", "Jane Austen", "Mark Twain"]),
    ("What is the fastest land animal?", "Cheetah", ["Lion", "Horse", "Leopard"]),
    ("How many continents are there?", "7", ["5", "6", "8"]),
    ("What year did Discord launch?", "2015", ["2014", "2016", "2017"]),
    ("Which gas do plants absorb?", "Carbon dioxide",
     ["Oxygen", "Nitrogen", "Hydrogen"]),
    ("What is the largest planet?", "Jupiter", ["Saturn", "Neptune", "Earth"]),
    ("How many bits are in a byte?", "8", ["4", "16", "32"]),
    ("Which country gifted the Statue of Liberty?", "France",
     ["Italy", "Spain", "Germany"]),
    ("What is the boiling point of water at sea level?", "100°C",
     ["90°C", "110°C", "80°C"]),
    ("Which element has the symbol Fe?", "Iron", ["Gold", "Fluorine", "Lead"]),
    ("How many strings does a standard guitar have?", "6", ["5", "7", "4"]),
    ("What does HTTP stand for?", "HyperText Transfer Protocol",
     ["High Transfer Text Protocol", "Hyper Transfer Type Process",
      "Host Transfer Text Program"]),
)

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS reminders (
        reminder_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER,
        channel_id INTEGER,
        user_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        due_at TEXT NOT NULL,
        created_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS staff_notes (
        note_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        author_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        created_at TEXT
    )
    """,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_duration(raw: str) -> int | None:
    """``10m`` / ``1h30m`` / ``2 days`` → seconds, or None."""
    if not raw:
        return None
    text = raw.strip().lower().replace(" ", "")
    total = 0
    matched = False
    for amount, unit in TIME_RE.findall(text):
        matched = True
        total += int(amount) * UNIT_SECONDS[unit[0]]
    if not matched or total <= 0:
        return None
    return min(total, MAX_REMIND)


class DuelView(discord.ui.View):
    """Accept / decline a coin duel."""

    def __init__(self, cog: "UtilityPlus", guild_id: int, challenger_id: int,
                 opponent_id: int, amount: int):
        super().__init__(timeout=90)
        self.cog = cog
        self.guild_id = guild_id
        self.challenger_id = challenger_id
        self.opponent_id = opponent_id
        self.amount = amount

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.opponent_id:
            await interaction.response.send_message(
                "This duel is not for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.danger, emoji="⚔️")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        error, winner = await self.cog.resolve_duel(
            self.guild_id, self.challenger_id, self.opponent_id, self.amount)
        self.stop()
        if error:
            return await interaction.response.edit_message(
                embed=self.cog.embed(f"{CROSS} Duel Cancelled", error), view=None)
        loser = (self.opponent_id if winner == self.challenger_id
                 else self.challenger_id)
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{TICK} Duel Finished",
            f"<@{winner}> won **{money(self.amount)} coins** from <@{loser}>!"),
            view=None)

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.secondary, emoji="✖️")
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{CROSS} Duel Declined", "No coins were moved."), view=None)


class TriviaView(discord.ui.View):
    """Four answer buttons for one trivia round."""

    def __init__(self, cog: "UtilityPlus", guild_id: int, user_id: int,
                 answer: str, reward: int, options: dict[str, str]):
        super().__init__(timeout=30)
        self.cog = cog
        self.guild_id = guild_id
        self.user_id = user_id
        self.answer = answer
        self.reward = reward
        self.options = options
        self.answered = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.user_id:
            return True
        await interaction.response.send_message(
            "This trivia round is not yours — run the command yourself.",
            ephemeral=True)
        return False

    async def _answer(self, interaction: discord.Interaction, choice: str,
                      button: discord.ui.Button):
        if self.answered:
            return await interaction.response.send_message(
                "You already answered.", ephemeral=True)
        self.answered = True
        correct = self.options.get(choice) == self.answer
        for child in self.children:
            child.disabled = True
        if correct:
            await self.cog.add_coins(self.guild_id, self.user_id, self.reward)
            embed = self.cog.embed(
                f"{TICK} Correct",
                f"**{self.answer}** is right — **+{money(self.reward)} coins**.")
        else:
            embed = self.cog.embed(
                f"{CROSS} Wrong",
                f"The answer was **{self.answer}**. No coins this time.")
        self.stop()
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="A", style=discord.ButtonStyle.primary)
    async def option_a(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._answer(interaction, button.label, button)

    @discord.ui.button(label="B", style=discord.ButtonStyle.primary)
    async def option_b(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._answer(interaction, button.label, button)

    @discord.ui.button(label="C", style=discord.ButtonStyle.primary)
    async def option_c(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._answer(interaction, button.label, button)

    @discord.ui.button(label="D", style=discord.ButtonStyle.primary)
    async def option_d(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._answer(interaction, button.label, button)


class DropView(discord.ui.View):
    """First person to press Claim takes the coins."""

    def __init__(self, cog: "UtilityPlus", guild_id: int, coins: int):
        super().__init__(timeout=60)
        self.cog = cog
        self.guild_id = guild_id
        self.coins = coins
        self.claimed = False

    @discord.ui.button(label="Claim", style=discord.ButtonStyle.success, emoji="💸")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.claimed:
            return await interaction.response.send_message(
                "Too late — it is already gone.", ephemeral=True)
        self.claimed = True
        button.disabled = True
        await self.cog.add_coins(self.guild_id, interaction.user.id, self.coins)
        self.stop()
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{MONEY} Claimed",
            f"{interaction.user.mention} grabbed **{money(self.coins)} coins**!"),
            view=self)


class UtilityPlus(commands.Cog):
    """Reminders, trivia, coin drops, duels and staff notes."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False
        self._drop_cooldowns: dict[int, datetime] = {}

    @staticmethod
    def help_custom():
        return (TIMER, "Utility+", "Reminders, trivia, drops, duels and staff notes.")

    def cog_load(self):
        self.reminder_watch.start()

    def cog_unload(self):
        self.reminder_watch.cancel()

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _eco(self, guild_id: int):
        os.makedirs("db", exist_ok=True)
        db = await aiosqlite.connect(ECO_DB)
        db.row_factory = aiosqlite.Row
        await db.execute(
            "CREATE TABLE IF NOT EXISTS eco_users ("
            "guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, "
            "coins INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, "
            "streak INTEGER NOT NULL DEFAULT 0, last_daily TEXT, last_work TEXT, "
            "PRIMARY KEY (guild_id, user_id))")
        await db.commit()
        return db

    async def _user_row(self, db, guild_id: int, user_id: int):
        await db.execute(
            "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id))
        async with db.execute(
            "SELECT * FROM eco_users WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ) as cur:
            return await cur.fetchone()

    async def add_coins(self, guild_id: int, user_id: int, amount: int):
        db = await self._eco(guild_id)
        try:
            await self._user_row(db, guild_id, user_id)
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, user_id))
            await db.commit()
        finally:
            await db.close()

    # ── reminders ────────────────────────────────────────────────────
    @commands.command(name="remind", aliases=["reminder", "remindme"],
                      help="Get a DM reminder, e.g. `remind 10m drink water`.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def remind(self, ctx, duration: str = None, *, text: str = None):
        seconds = _parse_duration(duration or "")
        if seconds is None or not text:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}remind 10m drink water` — s/m/h/d supported."))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) FROM reminders WHERE user_id = ?", (ctx.author.id,)
            ) as cur:
                pending = int((await cur.fetchone())[0])
            limit = await premium.limit_for(ctx.guild.id, "reminders")
            if limit is not None and pending >= limit:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Too Many Reminders",
                    f"Your plan allows **{limit}** pending reminders and you already "
                    f"have **{pending}**."))
            due = _now() + timedelta(seconds=seconds)
            await db.execute(
                "INSERT INTO reminders (guild_id, channel_id, user_id, text, due_at, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (ctx.guild.id, ctx.channel.id, ctx.author.id, text.strip()[:400],
                 due.isoformat(), _now().isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TIMER} Reminder Set",
            f"I will DM you {f'<t:{int(due.timestamp())}:R>'} about **{text.strip()[:120]}**."),
            mention_author=False)

    @commands.command(name="reminders", aliases=["myreminders"],
                      help="List your pending reminders.")
    @commands.guild_only()
    async def reminders(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT reminder_id, text, due_at FROM reminders WHERE user_id = ? "
                "ORDER BY due_at LIMIT 15", (ctx.author.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Reminders",
                f"Set one with `{ctx.clean_prefix}remind 1h stretch`."))
        lines = []
        for row in rows:
            try:
                stamp = int(datetime.fromisoformat(row["due_at"]).timestamp())
            except ValueError:
                stamp = 0
            lines.append(f"`#{int(row['reminder_id'])}` {row['text'][:80]} — <t:{stamp}:R>")
        await ctx.reply(embed=self.embed(f"{TIMER} Your Reminders", "\n".join(lines)),
                        mention_author=False)

    @tasks.loop(seconds=20)
    async def reminder_watch(self):
        await self.bot.wait_until_ready()
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM reminders WHERE due_at <= ? LIMIT 20", (_now().isoformat(),)
            ) as cur:
                rows = await cur.fetchall()
            for row in rows:
                await db.execute(
                    "DELETE FROM reminders WHERE reminder_id = ?", (int(row["reminder_id"]),))
            await db.commit()
        finally:
            await db.close()
        for row in rows:
            user = self.bot.get_user(int(row["user_id"]))
            if user is None:
                try:
                    user = await self.bot.fetch_user(int(row["user_id"]))
                except discord.HTTPException:
                    continue
            channel = self.bot.get_channel(int(row["channel_id"])) if row["channel_id"] else None
            embed = discord.Embed(
                title="Reminder",
                description=row["text"],
                color=COLOR,
                timestamp=_now())
            if channel is not None:
                embed.add_field(name="From", value=channel.mention, inline=False)
            try:
                await user.send(embed=embed)
            except discord.HTTPException:
                if channel is not None:
                    try:
                        await channel.send(content=f"<@{int(row['user_id'])}> reminder: "
                                                   f"{row['text'][:300]}")
                    except discord.HTTPException:
                        pass

    # ── trivia ───────────────────────────────────────────────────────
    @commands.command(name="trivia", aliases=["quiz"],
                      help="Answer a trivia question for coins.")
    @commands.guild_only()
    @commands.cooldown(1, 15, commands.BucketType.channel)
    async def trivia(self, ctx):
        question, answer, wrong = random.choice(TRIVIA)
        shuffled = [answer, *wrong]
        random.shuffle(shuffled)
        labels = ["A", "B", "C", "D"]
        mapping = {labels[index]: option for index, option in enumerate(shuffled)}
        paid = await premium.is_paid(ctx.guild.id)
        reward = 150 if paid else 75
        lines = [f"**{label}.** {option}" for label, option in mapping.items()]
        view = TriviaView(self, ctx.guild.id, ctx.author.id, answer, reward, mapping)
        for index, child in enumerate(view.children):
            child.label = labels[index]
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Trivia · {money(reward)} coins",
            f"{question}\n\n" + "\n".join(lines) + "\n\nPick an answer within 30 seconds."),
            view=view, mention_author=False)

    # ── coin drops ───────────────────────────────────────────────────
    @commands.command(name="drop", aliases=["coindrop"],
                      help="Drop free coins for the fastest clicker.")
    @commands.guild_only()
    @commands.cooldown(1, 600, commands.BucketType.channel)
    async def drop(self, ctx):
        paid = await premium.is_paid(ctx.guild.id)
        high = 750 if paid else 400
        coins = random.randint(50, high)
        await ctx.reply(embed=self.embed(
            f"{MONEY} Coin Drop!",
            f"**{money(coins)} coins** on the floor — first to claim them wins."),
            view=DropView(self, ctx.guild.id, coins), mention_author=False)

    # ── duels ────────────────────────────────────────────────────────
    @commands.command(name="duel", aliases=["challenge"],
                      help="Challenge a member to a coin duel.")
    @commands.guild_only()
    @commands.cooldown(1, 15, commands.BucketType.user)
    async def duel(self, ctx, member: discord.Member = None, amount: str = None):
        from .economy import parse_amount

        value = parse_amount(amount)
        if member is None or value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}duel @member 500`"))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Duel another human member."))
        db = await self._eco(ctx.guild.id)
        try:
            challenger = await self._user_row(db, ctx.guild.id, ctx.author.id)
            opponent = await self._user_row(db, ctx.guild.id, member.id)
        finally:
            await db.close()
        if int(challenger["coins"]) < value:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Enough Cash",
                f"You only have **{money(challenger['coins'])}** coins."))
        if int(opponent["coins"]) < value:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} They Are Broke",
                f"{member.display_name} cannot cover **{money(value)}** coins."))
        await ctx.reply(
            content=member.mention,
            embed=self.embed(
                f"⚔️ Duel Challenge",
                f"{ctx.author.mention} challenges {member.mention} for "
                f"**{money(value)} coins**!\nAccept within 90 seconds."),
            view=DuelView(self, ctx.guild.id, ctx.author.id, member.id, value),
            mention_author=False)

    async def resolve_duel(self, guild_id: int, challenger_id: int, opponent_id: int,
                           amount: int) -> tuple[str | None, int | None]:
        db = await self._eco(guild_id)
        try:
            challenger = await self._user_row(db, guild_id, challenger_id)
            opponent = await self._user_row(db, guild_id, opponent_id)
            if int(challenger["coins"]) < amount or int(opponent["coins"]) < amount:
                return "One of you no longer has enough coins.", None
            winner = random.choice((challenger_id, opponent_id))
            loser = opponent_id if winner == challenger_id else challenger_id
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, loser))
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, winner))
            await db.commit()
        finally:
            await db.close()
        return None, winner

    # ── staff notes ──────────────────────────────────────────────────
    @commands.command(name="note", aliases=["addnote"],
                      help="Add a staff note to a member (staff only).")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def note(self, ctx, member: discord.Member = None, *, text: str = None):
        if member is None or not text:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}note @member <text>`"))
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO staff_notes (guild_id, target_id, author_id, text, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (ctx.guild.id, member.id, ctx.author.id, text.strip()[:500],
                 _now().isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Note Saved", f"Staff note added to {member.mention}."),
            mention_author=False)

    @commands.command(name="notes", aliases=["usernotes"],
                      help="Show staff notes for a member.")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def notes(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}notes @member`"))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT note_id, author_id, text, created_at FROM staff_notes "
                "WHERE guild_id = ? AND target_id = ? ORDER BY note_id DESC LIMIT 15",
                (ctx.guild.id, member.id)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Notes", f"{member.display_name} has no staff notes."))
        lines = []
        for row in rows:
            lines.append(f"`#{int(row['note_id'])}` <@{int(row['author_id'])}> — "
                         f"{row['text'][:200]}")
        embed = self.embed(f"📝 {member.display_name} · Notes", "\n".join(lines)[:3900])
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="delnote", aliases=["removenote"],
                      help="Delete one staff note by id.")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def delnote(self, ctx, note_id: int = None):
        if note_id is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}delnote 12`"))
        db = await self._connect()
        try:
            cur = await db.execute(
                "DELETE FROM staff_notes WHERE note_id = ? AND guild_id = ?",
                (note_id, ctx.guild.id))
            await db.commit()
            removed = cur.rowcount
        finally:
            await db.close()
        if not removed:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Found", f"No note with id **{note_id}**."))
        await ctx.reply(embed=self.embed(
            f"{TICK} Note Deleted", f"Note `#{note_id}` removed."), mention_author=False)


async def setup(bot):
    await bot.add_cog(UtilityPlus(bot))
