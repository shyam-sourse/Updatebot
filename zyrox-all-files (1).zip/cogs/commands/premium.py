"""Premium plans, checkout and order handling (/premium)."""

from __future__ import annotations

import discord
from discord.ext import commands

from utils import premium
from utils.config import BRAND_NAME, OWNER_IDS

COLOR = 0xFF0000
GREEN = 0x2ECC71


async def _reply(ctx, message: str | None = None, ephemeral: bool = False, embed=None):
    """Reply to a hybrid command without breaking on prefix invocations."""
    kwargs: dict = {}
    if message is not None:
        kwargs["content"] = message
    if embed is not None:
        kwargs["embed"] = embed
    if ctx.interaction is not None:
        kwargs["ephemeral"] = ephemeral
        if ctx.interaction.response.is_done():
            return await ctx.interaction.followup.send(**kwargs)
        return await ctx.interaction.response.send_message(**kwargs)
    return await ctx.send(**kwargs)


def parse_id(raw) -> int | None:
    """Accept ``123456789``, ``<#123456789>`` or a copied ``Server ID`` text."""
    if raw is None:
        return None
    digits = "".join(ch for ch in str(raw) if ch.isdigit())
    if not digits or len(digits) < 15 or len(digits) > 21:
        return None
    return int(digits)


def is_staff(member: discord.Member | None) -> bool:
    if member is None:
        return False
    if member.id in OWNER_IDS:
        return True
    perms = getattr(member, "guild_permissions", None)
    if perms is not None and (perms.administrator or perms.manage_guild):
        return True
    return bool(premium.SALES_ROLE_ID) and any(
        role.id == premium.SALES_ROLE_ID for role in getattr(member, "roles", [])
    )


async def _servers_used(guild_id: int) -> int:
    order = await premium.active_order_for_guild(guild_id)
    if not order:
        return 1
    return max(1, await premium.order_server_count(order["order_id"]))


async def build_status_embed(guild: discord.Guild) -> discord.Embed:
    key = await premium.get_plan_key(guild.id)
    plan = premium.PLANS[key]
    limits = await premium.get_limits(guild.id)
    expiry = await premium.get_expiry(guild.id)
    ai_used = await premium.ai_used_today(guild.id)
    servers = await _servers_used(guild.id)
    referrals = await premium.referral_bonus(guild.id) if key == premium.PREMIUM_PLUS else 0

    if key == premium.FREE:
        renewal = "No expiry — free forever"
    elif expiry:
        renewal = f"{discord.utils.format_dt(expiry, 'D')} ({discord.utils.format_dt(expiry, 'R')})"
    else:
        renewal = "Unknown"

    ai_limit = limits.get("ai_chat_per_day")
    ai_text = (
        f"{ai_used} used today · **unlimited**"
        if ai_limit is None
        else f"{ai_used} / {ai_limit} used today · **{max(0, ai_limit - ai_used)}** left"
    )

    embed = discord.Embed(
        title=f"✨ {BRAND_NAME} Premium",
        description=(
            f"**Plan:** {plan['name']} — {premium.format_price(plan['price'])}\n"
            f"**Renews / expires:** {renewal}\n"
            f"**Servers:** {servers} / {premium.format_limit(limits.get('servers'))}"
            + (f" · {referrals} referral bonus" if referrals else "")
            + f"\n**AI chat:** {ai_text}"
        ),
        color=COLOR,
    )

    embed.add_field(
        name="Usage",
        value=await premium.usage_line(guild.id),
        inline=False,
    )
    embed.add_field(
        name=f"What {plan['name']} includes",
        value="\n".join(f"• {perk}" for perk in plan["perks"])[:1024],
        inline=False,
    )
    embed.set_footer(text="Buy with UPI, or redeem a key with /premium keyredeem")
    return embed


def plan_embed(key: str, current_key: str) -> discord.Embed:
    plan = premium.PLANS[key]
    limits = plan["limits"]
    rows = [
        ("Custom commands", limits["custom_commands"]),
        ("AutoMod rules", limits["automod_rules"]),
        ("Ticket panels", limits["ticket_panels"]),
        ("Giveaways", limits["giveaways"]),
        ("Embeds", limits["embeds"]),
        ("Reminders", limits["reminders"]),
        ("Temp voice channels", limits["temp_voice"]),
        ("Servers", limits["servers"]),
        ("AI chat replies / day", limits["ai_chat_per_day"]),
        ("AI ticket replies / month", limits["ai_ticket_replies_per_month"]),
    ]
    details = "\n".join(
        f"**{label}:** {premium.format_limit(value)}" for label, value in rows
    )
    perks = "\n".join(f"• {perk}" for perk in plan["perks"])
    embed = discord.Embed(
        title=f"{plan['name']} — {premium.format_price(plan['price'])}",
        description=details,
        color=COLOR,
    )
    embed.add_field(name="Also included", value=perks[:1024], inline=False)
    if key == premium.PREMIUM_PLUS:
        embed.add_field(
            name="Server slots",
            value="4 servers, plus one extra slot for every successful referral.",
            inline=False,
        )
    if key == current_key:
        embed.set_footer(text="This is your current plan.")
    else:
        embed.set_footer(text="30 days per payment · activated by staff after the UPI screenshot")
    return embed


# ── Views ────────────────────────────────────────────────────────────────────
class HomeView(discord.ui.View):
    def __init__(self, guild: discord.Guild):
        super().__init__(timeout=300)
        self.guild = guild
        self.add_item(
            discord.ui.Button(
                label="Support server",
                style=discord.ButtonStyle.link,
                url=premium.SUPPORT_INVITE,
                row=1,
            )
        )

    @discord.ui.button(label="Free — Rs 0", style=discord.ButtonStyle.secondary, row=0)
    async def free_plan(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _show_plan(interaction, premium.FREE)

    @discord.ui.button(label="Premium — Rs 129", style=discord.ButtonStyle.primary, row=0)
    async def premium_plan(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _show_plan(interaction, premium.PREMIUM)

    @discord.ui.button(label="Premium+ — Rs 199", style=discord.ButtonStyle.success, row=0)
    async def premium_plus_plan(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _show_plan(interaction, premium.PREMIUM_PLUS)

    @discord.ui.button(label="Usage", style=discord.ButtonStyle.secondary, row=1)
    async def usage(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            embed=await build_status_embed(interaction.guild), ephemeral=True
        )


class PlanView(discord.ui.View):
    def __init__(self, guild: discord.Guild, plan_key: str):
        super().__init__(timeout=300)
        self.guild = guild
        self.plan_key = plan_key
        buy = discord.ui.Button(
            label=f"Buy — {premium.format_price(premium.PLAN_PRICES[plan_key])}",
            style=discord.ButtonStyle.success,
            row=0,
            disabled=plan_key == premium.FREE,
        )
        buy.callback = self._buy
        self.add_item(buy)

    async def _buy(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            embed=method_embed(self.plan_key), view=MethodView(self.guild, self.plan_key)
        )

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, row=0)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=await build_status_embed(self.guild), view=HomeView(self.guild)
        )


class MethodView(discord.ui.View):
    def __init__(self, guild: discord.Guild, plan_key: str):
        super().__init__(timeout=300)
        self.guild = guild
        self.plan_key = plan_key

    @discord.ui.button(label="Support-server ticket", style=discord.ButtonStyle.primary, row=0)
    async def ticket_method(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=checkout_embed(self.plan_key, "ticket"),
            view=CheckoutView(self.guild, self.plan_key, "ticket", interaction.channel_id),
        )

    @discord.ui.button(label="Direct two-server bridge", style=discord.ButtonStyle.success, row=0)
    async def bridge_method(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=checkout_embed(self.plan_key, "bridge"),
            view=CheckoutView(self.guild, self.plan_key, "bridge", interaction.channel_id),
        )

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=plan_embed(self.plan_key, await premium.get_plan_key(self.guild.id)),
            view=PlanView(self.guild, self.plan_key),
        )


class CheckoutView(discord.ui.View):
    def __init__(self, guild, plan_key, method, origin_channel_id):
        super().__init__(timeout=600)
        self.guild = guild
        self.plan_key = plan_key
        self.method = method
        self.origin_channel_id = origin_channel_id

    @discord.ui.button(label="I've paid — send screenshot", style=discord.ButtonStyle.success, row=0)
    async def paid(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(
            ScreenshotModal(self.guild, self.plan_key, self.method, self.origin_channel_id)
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary, row=0)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=await build_status_embed(self.guild), view=HomeView(self.guild)
        )


class ScreenshotModal(discord.ui.Modal, title="Confirm your payment"):
    screenshot = discord.ui.TextInput(
        label="Screenshot link (optional)",
        placeholder="https://... — or leave blank and upload it in the ticket",
        required=False,
        max_length=400,
    )
    note = discord.ui.TextInput(
        label="Anything staff should know?",
        placeholder="UPI reference / transaction id (optional)",
        required=False,
        max_length=200,
    )

    def __init__(self, guild, plan_key, method, origin_channel_id):
        super().__init__()
        self.guild = guild
        self.plan_key = plan_key
        self.method = method
        self.origin_channel_id = origin_channel_id

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        order = await premium.create_order(
            guild_id=self.guild.id,
            user_id=interaction.user.id,
            plan_key=self.plan_key,
            method=self.method,
            origin_channel_id=self.origin_channel_id,
            note=str(self.note.value or "").strip() or None,
        )
        url = str(self.screenshot.value or "").strip()
        if url.startswith("http"):
            await premium.set_order_screenshot(order["order_id"], url)
            order["screenshot_url"] = url

        channel, error = await open_order_ticket(interaction.client, order, interaction.user)

        lines = [
            f"**Order:** `{order['order_id']}`",
            f"**Plan:** {premium.PLAN_LABELS[order['plan']]} — {premium.format_price(order['amount'])}",
        ]
        if channel:
            lines.append(f"**Ticket:** {channel.mention}")
            lines.append("Upload the payment screenshot in the ticket so staff can press **Mark paid**.")
        else:
            lines.append(f"Payment ticket could not be opened: {error}")
            lines.append("Contact staff in the support server with your order id.")

        embed = discord.Embed(
            title="Order created",
            description="\n".join(lines),
            color=GREEN,
        )
        embed.set_footer(text="Your 30 days start when staff mark the payment as received.")
        await interaction.followup.send(embed=embed, ephemeral=True)


class MarkPaidView(discord.ui.View):
    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        button = discord.ui.Button(
            label="Mark paid",
            emoji="✅",
            style=discord.ButtonStyle.success,
            custom_id=f"premium_mark_paid:{order_id}",
        )
        button.callback = self._mark_paid
        self.add_item(button)
        self.order_id = order_id

    async def _mark_paid(self, interaction: discord.Interaction):
        if not is_staff(interaction.user):
            return await interaction.response.send_message(
                "Only sales staff can mark an order paid.", ephemeral=True
            )

        order = await premium.get_order(self.order_id)
        if not order:
            return await interaction.response.send_message("This order no longer exists.", ephemeral=True)
        if order["status"] == "paid":
            return await interaction.response.send_message(
                f"Order `{self.order_id}` is already paid.", ephemeral=True
            )

        await interaction.response.defer()
        order = await premium.mark_paid(self.order_id, interaction.user.id)
        expiry = await premium.get_expiry(order["guild_id"])

        embed = discord.Embed(
            title="Payment received ✅",
            description=(
                f"**Order:** `{order['order_id']}`\n"
                f"**Plan:** {premium.PLAN_LABELS[order['plan']]}\n"
                f"**Server:** `{order['guild_id']}`\n"
                f"**Active until:** {discord.utils.format_dt(expiry, 'D') if expiry else '—'}\n"
                f"**Marked by:** {interaction.user.mention}"
            ),
            color=GREEN,
            timestamp=discord.utils.utcnow(),
        )
        await interaction.followup.send(embed=embed)

        try:
            buyer = interaction.client.get_user(order["user_id"]) or await interaction.client.fetch_user(order["user_id"])
            if buyer:
                await buyer.send(
                    f"✅ Payment received for **{premium.PLAN_LABELS[order['plan']]}** "
                    f"(`{order['order_id']}`). Your plan is active until "
                    f"{discord.utils.format_dt(expiry, 'D') if expiry else '—'}."
                )
        except (discord.Forbidden, discord.HTTPException):
            pass


# ── Checkout helpers ─────────────────────────────────────────────────────────
def method_embed(plan_key: str) -> discord.Embed:
    plan = premium.PLANS[plan_key]
    return discord.Embed(
        title="How do you want to pay?",
        description=(
            f"**{plan['name']} — {premium.format_price(plan['price'])}** for 30 days.\n\n"
            "**Support-server ticket** — we open a private order ticket in the support server. "
            "Staff verify the screenshot there.\n\n"
            "**Direct two-server bridge** — same order ticket, plus a link posted in this server "
            "so your staff and ours share one thread."
        ),
        color=COLOR,
    ).set_footer(text="Both options end with a UPI payment and a screenshot.")


def checkout_embed(plan_key: str, method: str) -> discord.Embed:
    plan = premium.PLANS[plan_key]
    upi_line = f"**UPI ID:** `{premium.UPI_ID}`" if premium.UPI_ID else (
        "**UPI ID:** not configured yet — staff will share it in your ticket."
    )
    embed = discord.Embed(
        title=f"Pay {premium.format_price(plan['price'])} by UPI",
        description=(
            f"**Plan:** {plan['name']} (30 days)\n"
            f"**Amount:** {premium.format_price(plan['price'])}\n"
            f"{upi_line}\n\n"
            "1. Pay the amount to the UPI ID above (or scan the QR).\n"
            "2. Press **I've paid** below.\n"
            "3. Drop the payment screenshot in the order ticket.\n"
            "4. Staff press **Mark paid** and your 30 days start."
        ),
        color=COLOR,
    )
    if premium.UPI_QR_URL.startswith("http"):
        embed.set_image(url=premium.UPI_QR_URL)
    embed.set_footer(
        text="Support-server ticket" if method == "ticket" else "Direct two-server bridge"
    )
    return embed


async def _show_plan(interaction: discord.Interaction, plan_key: str):
    current = await premium.get_plan_key(interaction.guild.id)
    await interaction.response.edit_message(
        embed=plan_embed(plan_key, current), view=PlanView(interaction.guild, plan_key)
    )


async def open_premium(target):
    """Open the premium screen from a Context or an Interaction."""
    guild = getattr(target, "guild", None)
    if guild is None:
        if isinstance(target, discord.Interaction):
            return await target.response.send_message(
                "Premium plans are per server — run this in your server.", ephemeral=True
            )
        return await target.send("Premium plans are per server — run this in your server.")

    embed = await build_status_embed(guild)
    view = HomeView(guild)

    if isinstance(target, discord.Interaction):
        if target.response.is_done():
            return await target.followup.send(embed=embed, view=view, ephemeral=True)
        return await target.response.send_message(embed=embed, view=view, ephemeral=True)

    return await target.send(embed=embed, view=view)


async def open_order_ticket(
    bot: commands.Bot, order: dict, buyer: discord.abc.User
) -> tuple[discord.TextChannel | None, str]:
    """Create the order ticket in the support server. Returns (channel, error)."""
    if not premium.SUPPORT_GUILD_ID:
        return None, "SUPPORT_GUILD_ID is not set."

    guild = bot.get_guild(premium.SUPPORT_GUILD_ID)
    if guild is None:
        return None, "the bot is not in the support server."

    category = guild.get_channel(premium.ORDERS_CATEGORY_ID) if premium.ORDERS_CATEGORY_ID else None
    if premium.ORDERS_CATEGORY_ID and category is None:
        return None, "the orders category is missing."

    role = guild.get_role(premium.SALES_ROLE_ID) if premium.SALES_ROLE_ID else None
    member = guild.get_member(buyer.id)

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
    }
    if member:
        overwrites[member] = discord.PermissionOverwrite(view_channel=True, send_messages=True)
    if role:
        overwrites[role] = discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True
        )

    try:
        channel = await guild.create_text_channel(
            name=f"order-{order['order_id'].lower()}",
            category=category,
            overwrites=overwrites,
            topic=f"Premium order {order['order_id']} · {premium.PLAN_LABELS[order['plan']]}",
            reason="Premium order ticket",
        )
    except (discord.Forbidden, discord.HTTPException) as exc:
        return None, f"could not create the ticket channel ({exc})."

    await premium.set_order_ticket(order["order_id"], channel.id)

    method_label = "Direct two-server bridge" if order["method"] == "bridge" else "Support-server ticket"
    embed = discord.Embed(
        title=f"New {premium.PLAN_LABELS[order['plan']]} order",
        description=(
            f"**Order:** `{order['order_id']}`\n"
            f"**Plan:** {premium.PLAN_LABELS[order['plan']]} — {premium.format_price(order['amount'])}\n"
            f"**Buyer:** {buyer.mention} (`{buyer.id}`)\n"
            f"**Server:** `{order['guild_id']}`\n"
            f"**Method:** {method_label}"
        ),
        color=COLOR,
    )
    if order.get("screenshot_url"):
        embed.add_field(name="Screenshot", value=order["screenshot_url"], inline=False)
    else:
        embed.add_field(name="Screenshot", value="Waiting for the buyer to upload it here.", inline=False)
    if order.get("note"):
        embed.add_field(name="Buyer note", value=order["note"][:1024], inline=False)
    embed.set_footer(text="Staff: verify the payment, then press Mark paid.")

    pings = [p for p in (buyer.mention if member else None, role.mention if role else None) if p]
    await channel.send(
        content=" ".join(pings) or None,
        embed=embed,
        view=MarkPaidView(order["order_id"]),
    )

    if order["method"] == "bridge" and order.get("origin_channel_id"):
        origin = bot.get_channel(order["origin_channel_id"])
        if origin is not None and getattr(origin, "guild", None) and origin.guild.id != guild.id:
            try:
                await origin.send(
                    f"🌉 Order `{order['order_id']}` is bridged: {channel.mention} in "
                    f"**{guild.name}**. Both teams share this ticket."
                )
            except (discord.Forbidden, discord.HTTPException):
                pass

    return channel, ""


# ── Cog ──────────────────────────────────────────────────────────────────────
class Premium(commands.Cog, name="Premium"):
    def __init__(self, bot):
        self.bot = bot
        bot.loop.create_task(premium.init())

    def help_custom(self):
        return "✨", "Premium", "Plans, premium keys, upgrades and orders"

    @commands.hybrid_group(name="premium", invoke_without_command=True,
                           description="Show your plan, usage and upgrade options.")
    async def premium_group(self, ctx):
        await open_premium(ctx)

    @premium_group.command(name="status", description="Your tier, expiry and remaining AI replies.")
    @commands.guild_only()
    async def status(self, ctx):
        await ctx.send(embed=await build_status_embed(ctx.guild))

    @premium_group.command(name="orders", description="List recent pending orders (staff).")
    @commands.guild_only()
    async def orders(self, ctx):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only sales staff can view orders.", ephemeral=True)
        pending = await premium.pending_orders()
        if not pending:
            return await _reply(ctx, "No pending orders.")
        lines = [
            f"`{o['order_id']}` · {premium.PLAN_LABELS[o['plan']]} · <@{o['user_id']}> · "
            f"server `{o['guild_id']}` · {o['method']}"
            for o in pending
        ]
        embed = discord.Embed(title="Pending orders", description="\n".join(lines)[:4000], color=COLOR)
        await ctx.send(embed=embed)

    @premium_group.command(name="markpaid", description="Mark an order paid and start its 30 days (staff).")
    @commands.guild_only()
    async def markpaid(self, ctx, order_id: str):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only sales staff can mark orders paid.", ephemeral=True)
        order = await premium.get_order(order_id.strip().upper())
        if not order:
            return await _reply(ctx, "Order not found.", ephemeral=True)
        if order["status"] == "paid":
            return await _reply(ctx, f"`{order['order_id']}` is already paid.", ephemeral=True)

        order = await premium.mark_paid(order["order_id"], ctx.author.id)
        expiry = await premium.get_expiry(order["guild_id"])
        await _reply(
            ctx,
            f"✅ `{order['order_id']}` marked paid. **{premium.PLAN_LABELS[order['plan']]}** "
            f"active for server `{order['guild_id']}` until "
            f"{discord.utils.format_dt(expiry, 'D') if expiry else '—'}.",
        )

    @premium_group.command(name="servers", description="Servers covered by this subscription.")
    @commands.guild_only()
    async def servers(self, ctx):
        order = await premium.active_order_for_guild(ctx.guild.id)
        limits = await premium.get_limits(ctx.guild.id)
        used = await _servers_used(ctx.guild.id)
        if not order:
            return await ctx.send(
                f"**Servers:** {used} / {premium.format_limit(limits.get('servers'))}\n"
                "Extra server slots come with Premium+."
            )
        guild_ids = [str(gid) for gid in await premium.order_guild_ids(order["order_id"])]
        await ctx.send(
            f"**Servers:** {used} / {premium.format_limit(limits.get('servers'))}\n"
            f"`{'`, `'.join(guild_ids)}`"
        )

    @premium_group.command(name="add-server", description="Add another server to this Premium+ subscription.")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def add_server(self, ctx, server_id: str):
        guild_id = parse_id(server_id)
        if guild_id is None:
            return await _reply(
                ctx, "Give the server ID — Server Settings → right-click the server → Copy Server ID.",
                ephemeral=True,
            )
        plan_key = await premium.get_plan_key(ctx.guild.id)
        if plan_key != premium.PREMIUM_PLUS:
            return await ctx.send("Only **Premium+** covers more than one server.")
        target = self.bot.get_guild(guild_id)
        if target is None:
            return await ctx.send(
                f"I am not in server `{guild_id}`, so it cannot use the plan. "
                "Invite me there first, then run this again."
            )
        order = await premium.active_order_for_guild(ctx.guild.id)
        if not order:
            return await ctx.send("This server has no active paid order to extend.")
        limits = await premium.get_limits(ctx.guild.id)
        used = await premium.order_server_count(order["order_id"])
        if used >= (limits.get("servers") or 0):
            return await ctx.send(
                f"All **{used} / {premium.format_limit(limits.get('servers'))}** server slots are in use. "
                "Refer another server to earn an extra slot."
            )
        expiry = await premium.get_expiry(ctx.guild.id)
        await premium.activate(
            guild_id,
            order["plan"],
            order_id=order["order_id"],
            expires_at=expiry.isoformat() if expiry else None,
        )
        await premium.add_order_server(order["order_id"], guild_id)
        await ctx.send(
            f"✅ **{target.name}** (`{guild_id}`) now shares this Premium+ subscription "
            f"({used + 1} / {premium.format_limit(limits.get('servers'))})."
        )

    @premium_group.command(name="referral", description="Record a successful referral for an extra server slot (staff).")
    @commands.guild_only()
    async def referral(self, ctx, member: discord.Member):
        if not is_staff(ctx.author):
            return await ctx.send("Only sales staff can record referrals.")
        if await premium.get_plan_key(ctx.guild.id) != premium.PREMIUM_PLUS:
            return await ctx.send("Referral slots apply to **Premium+** servers only.")
        added = await premium.record_referral(ctx.guild.id, member.id)
        if not added:
            return await ctx.send(f"{member.mention} is already recorded for this server.")
        bonus = await premium.referral_bonus(ctx.guild.id)
        await ctx.send(
            f"✅ Referral recorded for {member.mention}. Server slots: "
            f"{4 + bonus} ({bonus} bonus)."
        )

    @premium_group.command(name="grant", description="Set a plan for any server ID (bot owner only).")
    @commands.is_owner()
    async def grant(self, ctx, server_id: str, plan: str, days: int = 30):
        guild_id = parse_id(server_id)
        if guild_id is None:
            return await _reply(
                ctx, "Give a server ID (right-click the server → Copy Server ID).", ephemeral=True
            )
        key = plan.strip().lower()
        if key in ("premium+", "premiumplus", "premium_plus", "plus"):
            key = premium.PREMIUM_PLUS
        elif key == "premium":
            key = premium.PREMIUM
        elif key == "free":
            key = premium.FREE
        if key not in premium.PLANS:
            return await ctx.send("Plan must be `free`, `premium` or `premium_plus`.")
        target = self.bot.get_guild(guild_id)
        label = f"**{target.name}** (`{guild_id}`)" if target else f"server `{guild_id}`"
        expiry = await premium.activate(guild_id, key, days=max(0, days))
        await ctx.send(
            f"✅ {label} set to **{premium.PLAN_LABELS[key]}** "
            f"until {discord.utils.format_dt(expiry, 'D')}."
        )

    # ── Keys ────────────────────────────────────────────────────────────────
    @premium_group.command(name="keygen", description="Create activation keys for a plan (staff).")
    async def keygen(self, ctx, plan: str, days: int = 30, count: int = 1, uses: int = 1):
        if not (ctx.author.id in OWNER_IDS or is_staff(ctx.author)):
            return await _reply(ctx, "Only sales staff can create keys.", ephemeral=True)
        key = plan.strip().lower()
        if key in ("premium+", "premiumplus", "premium_plus", "plus"):
            key = premium.PREMIUM_PLUS
        elif key == "premium":
            key = premium.PREMIUM
        if key not in (premium.PREMIUM, premium.PREMIUM_PLUS):
            return await _reply(
                ctx, "Keys are for paid plans only: `premium` or `premium_plus`.", ephemeral=True
            )
        if not (1 <= days <= 3650):
            return await _reply(ctx, "Days must be between 1 and 3650.", ephemeral=True)
        codes = await premium.create_keys(
            key,
            days=days,
            count=count,
            max_uses=uses,
            created_by=ctx.author.id,
            note=f"by {ctx.author}"[:200],
        )
        lines = [
            f"`{premium.format_key(code)}` — {premium.PLAN_LABELS[key]} · {days} days · "
            f"{uses} server{'s' if uses != 1 else ''}"
            for code in codes
        ]
        embed = discord.Embed(
            title=f"{len(codes)} key{'s' if len(codes) != 1 else ''} created",
            description="\n".join(lines)[:4000],
            color=GREEN,
        )
        embed.set_footer(text="Redeem with /premium keyredeem <code> — one key, one server")
        if ctx.guild is not None:
            try:
                await ctx.author.send(embed=embed)
                return await _reply(ctx, "✅ Keys sent to your DMs.", ephemeral=True)
            except discord.Forbidden:
                pass
        await ctx.send(embed=embed)

    @premium_group.command(name="keyredeem", description="Activate premium on this server with a key.")
    async def keyredeem(self, ctx, code: str, server_id: str = None):
        target_id = parse_id(server_id) if server_id else None
        if target_id is None and ctx.guild is not None:
            target_id = ctx.guild.id
        if target_id is None:
            return await _reply(
                ctx,
                "Run this in a server, or pass the server ID (bot owner only).",
                ephemeral=True,
            )
        if target_id != (ctx.guild.id if ctx.guild else 0) and ctx.author.id not in OWNER_IDS:
            return await _reply(
                ctx, "Only the bot owner can redeem a key for another server.", ephemeral=True
            )
        if ctx.guild is not None and target_id == ctx.guild.id and not is_staff(ctx.author):
            if not (
                ctx.author.guild_permissions.administrator
                or ctx.author.guild_permissions.manage_guild
            ):
                return await _reply(
                    ctx, "Only admins can redeem keys for this server.", ephemeral=True
                )

        ok, error, details = await premium.redeem_key(code, target_id, ctx.author.id)
        if not ok:
            return await _reply(ctx, f"❌ {error}", ephemeral=True)

        target = self.bot.get_guild(target_id)
        label = f"**{target.name}**" if target else f"server `{target_id}`"
        uses_line = (
            f"\n**Key uses left:** {details['remaining']} / {details['max_uses']}"
            if details["max_uses"] > 1
            else ""
        )
        embed = discord.Embed(
            title="Premium activated ✅",
            description=(
                f"**Plan:** {premium.PLAN_LABELS[details['plan']]}\n"
                f"**Server:** {label}\n"
                f"**Days added:** {details['days']}\n"
                f"**Active until:** {discord.utils.format_dt(details['expiry'], 'D')} "
                f"({discord.utils.format_dt(details['expiry'], 'R')})"
                f"{uses_line}"
            ),
            color=GREEN,
            timestamp=discord.utils.utcnow(),
        )
        await _reply(ctx, embed=embed)

    @premium_group.command(name="keylist", description="List active premium keys (staff).")
    async def keylist(self, ctx, code: str = None):
        if not (ctx.author.id in OWNER_IDS or is_staff(ctx.author)):
            return await _reply(ctx, "Only sales staff can view keys.", ephemeral=True)
        if code:
            key = await premium.get_key(code)
            if not key:
                return await _reply(ctx, "Key not found.", ephemeral=True)
            uses = await premium.key_use_rows(key["code"])
            used_lines = (
                "\n".join(
                    f"· `{row['guild_id']}` <@{row['user_id']}> — {row['expires_at'][:10]}"
                    for row in uses
                )
                or "Not redeemed yet."
            )
            embed = discord.Embed(
                title=f"Key {premium.format_key(key['code'])}",
                description=(
                    f"**Plan:** {premium.PLAN_LABELS.get(key['plan'], key['plan'])}\n"
                    f"**Days:** {key['days']}\n"
                    f"**Uses:** {key['uses']} / {key['max_uses']}"
                    f"{' · revoked' if key['revoked'] else ''}\n\n**Redeemed by**\n{used_lines}"
                )[:4000],
                color=COLOR,
            )
            return await _reply(ctx, embed=embed)

        keys = await premium.list_keys(25)
        if not keys:
            return await _reply(ctx, "No usable keys. Create one with `/premium keygen`.", ephemeral=True)
        lines = [
            f"`{premium.format_key(k['code'])}` · {premium.PLAN_LABELS.get(k['plan'], k['plan'])} · "
            f"{k['days']}d · {k['uses']}/{k['max_uses']} used"
            for k in keys
        ]
        embed = discord.Embed(
            title="Active premium keys",
            description="\n".join(lines)[:4000],
            color=COLOR,
        )
        await _reply(ctx, embed=embed)

    @premium_group.command(name="keyrevoke", description="Disable a premium key (staff).")
    async def keyrevoke(self, ctx, code: str):
        if not (ctx.author.id in OWNER_IDS or is_staff(ctx.author)):
            return await _reply(ctx, "Only sales staff can revoke keys.", ephemeral=True)
        ok = await premium.revoke_key(code)
        if not ok:
            return await _reply(ctx, "Key not found.", ephemeral=True)
        await _reply(
            ctx,
            f"🗑️ Key `{premium.format_key(code)}` revoked. Servers that already redeemed it keep their time.",
        )


async def setup(bot):
    await bot.add_cog(Premium(bot))
