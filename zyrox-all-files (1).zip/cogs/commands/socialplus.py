# ╔══════════════════════════════════════════════════════════════════╗
# ║   Social Plus  ──  family trees, gifting and confessions          ║
# ║   family • adopt • disown • gift • giveitem • confess             ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Family trees, coin/item gifting and anonymous confessions."""

from __future__ import annotations

import os
from datetime import datetime, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils import premium
from utils.emoji import CROSS, HEARTS, INFO, MONEY, SPARKLE, TICK

from .economy import money, parse_amount

ECO_DB = "db/economy.db"
DB = "db/socialplus.db"
COLOR = 0xFF0000


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS social_family (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        parent_id INTEGER,
        adopted_at TEXT,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS confession_settings (
        guild_id INTEGER PRIMARY KEY,
        channel_id INTEGER NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS confession_times (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        day TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, day)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS joint_accounts (
        guild_id INTEGER NOT NULL,
        pair_key TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, pair_key)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS anniversaries (
        guild_id INTEGER NOT NULL,
        pair_key TEXT NOT NULL,
        day TEXT NOT NULL,
        PRIMARY KEY (guild_id, pair_key)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS profile_extras (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        accent TEXT,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
)


class SocialPlus(commands.Cog):
    """Family trees, gifting and anonymous confessions."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (HEARTS, "Social+", "Family trees, coin gifts and confessions.")

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _row(self, db, guild_id: int, user_id: int):
        await db.execute(
            "INSERT OR IGNORE INTO social_family (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id))
        async with db.execute(
            "SELECT * FROM social_family WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ) as cur:
            return await cur.fetchone()

    async def _eco(self):
        os.makedirs("db", exist_ok=True)
        db = await aiosqlite.connect(ECO_DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _eco_user(self, db, guild_id: int, user_id: int):
        await db.execute(
            "CREATE TABLE IF NOT EXISTS eco_users ("
            "guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, "
            "coins INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, "
            "streak INTEGER NOT NULL DEFAULT 0, last_daily TEXT, last_work TEXT, "
            "PRIMARY KEY (guild_id, user_id))")
        await db.execute(
            "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id))
        async with db.execute(
            "SELECT * FROM eco_users WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ) as cur:
            return await cur.fetchone()

    # ── family ───────────────────────────────────────────────────────
    @commands.command(name="family", aliases=["fam", "familytree"],
                      help="Show a member's family tree.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def family(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db = await self._connect()
        try:
            row = await self._row(db, ctx.guild.id, member.id)
            async with db.execute(
                "SELECT user_id FROM social_family WHERE guild_id = ? AND parent_id = ?",
                (ctx.guild.id, member.id)
            ) as cur:
                children = [int(r["user_id"]) for r in await cur.fetchall()]
        finally:
            await db.close()
        parent_id = int(row["parent_id"]) if row and row["parent_id"] else None
        children = [cid for cid in children if cid != member.id]
        lines = [
            f"**Parents:** {f'<@{parent_id}>' if parent_id else 'none'}",
            f"**Children:** {', '.join(f'<@{cid}>' for cid in children) if children else 'none'}",
        ]
        embed = self.embed(f"{HEARTS} {member.display_name}'s Family", "\n".join(lines))
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Adopt with {ctx.clean_prefix}adopt @member")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="adopt", aliases=["adoptme"],
                      help="Adopt a member as your child.")
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def adopt(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}adopt @member`"))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Pick another human member."))
        db = await self._connect()
        try:
            mine = await self._row(db, ctx.guild.id, ctx.author.id)
            theirs = await self._row(db, ctx.guild.id, member.id)
            if theirs["parent_id"]:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Already Adopted",
                    f"{member.mention} already has a parent (<@{int(theirs['parent_id'])}>)."))
            cursor = mine["parent_id"]
            depth = 0
            while cursor and depth < 20:
                if int(cursor) == member.id:
                    return await ctx.reply(embed=self.embed(
                        f"{CROSS} Not Possible",
                        "That member is already above you in your family tree."))
                async with db.execute(
                    "SELECT parent_id FROM social_family WHERE guild_id = ? AND user_id = ?",
                    (ctx.guild.id, int(cursor))
                ) as cur:
                    up = await cur.fetchone()
                cursor = up["parent_id"] if up else None
                depth += 1
            await db.execute(
                "UPDATE social_family SET parent_id = ?, adopted_at = ? "
                "WHERE guild_id = ? AND user_id = ?",
                (ctx.author.id, datetime.now(timezone.utc).isoformat(),
                 ctx.guild.id, member.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{HEARTS} Adopted",
            f"{ctx.author.mention} adopted {member.mention}! 👨‍👦"), mention_author=False)

    @commands.command(name="disown", aliases=["emancipate"],
                      help="Remove someone from your family.")
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def disown(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}disown @member`"))
        db = await self._connect()
        try:
            theirs = await self._row(db, ctx.guild.id, member.id)
            if not theirs["parent_id"] or int(theirs["parent_id"]) != ctx.author.id:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Your Child", f"{member.mention} is not in your family."))
            await db.execute(
                "UPDATE social_family SET parent_id = NULL WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, member.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{CROSS} Disowned", f"{member.mention} is no longer your child."),
            mention_author=False)

    # ── gifting ──────────────────────────────────────────────────────
    @commands.command(name="gift", aliases=["sendcoins"],
                      help="Gift coins to another member.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def gift(self, ctx, member: discord.Member = None, amount: str = None):
        value = parse_amount(amount)
        if member is None or value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}gift @member 500`"))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Gift another human member."))
        db = await self._eco()
        try:
            sender = await self._eco_user(db, ctx.guild.id, ctx.author.id)
            if int(sender["coins"]) < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Cash",
                    f"You only have **{money(sender['coins'])}** coins."))
            await self._eco_user(db, ctx.guild.id, member.id)
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, ctx.author.id))
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, member.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{MONEY} Gift Sent",
            f"{ctx.author.mention} gifted **{money(value)} coins** to {member.mention} 🎁"),
            mention_author=False)

    @commands.command(name="giveitem", aliases=["senditem"],
                      help="Give one of your shop items to a member.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def giveitem(self, ctx, member: discord.Member = None, *, item: str = None):
        if member is None or not item:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}giveitem @member <item>`"))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Give the item to another human member."))
        key = item.strip().lower()[:60]
        db = await self._eco()
        try:
            async with db.execute(
                "SELECT amount FROM eco_inventory WHERE guild_id = ? AND user_id = ? "
                "AND item = ?", (ctx.guild.id, ctx.author.id, key)
            ) as cur:
                row = await cur.fetchone()
            if not row or int(row["amount"]) < 1:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Item Missing", f"You do not own **{key}**."))
            await db.execute(
                "UPDATE eco_inventory SET amount = amount - 1 WHERE guild_id = ? "
                "AND user_id = ? AND item = ?", (ctx.guild.id, ctx.author.id, key))
            await db.execute(
                "INSERT INTO eco_inventory (guild_id, user_id, item, amount) "
                "VALUES (?, ?, ?, 1) ON CONFLICT(guild_id, user_id, item) "
                "DO UPDATE SET amount = amount + 1", (ctx.guild.id, member.id, key))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Item Gifted",
            f"{ctx.author.mention} gave **{key}** to {member.mention}."),
            mention_author=False)

    # ── confessions ──────────────────────────────────────────────────
    @commands.group(name="confession", aliases=["confessions"],
                    invoke_without_command=True,
                    help="Configure the anonymous confession channel.")
    @commands.guild_only()
    async def confession(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT channel_id, enabled FROM confession_settings WHERE guild_id = ?",
                (ctx.guild.id,)
            ) as cur:
                row = await cur.fetchone()
        finally:
            await db.close()
        p = ctx.clean_prefix
        state = "not set"
        if row and row["channel_id"]:
            state = f"<#{int(row['channel_id'])}> ({'on' if int(row['enabled']) else 'off'})"
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Confessions",
            f"**Channel:** {state}\n\n"
            f"`{p}confession setup #channel` · `{p}confession disable`\n"
            f"Members post with `{p}confess <text>`."), mention_author=False)

    @confession.command(name="setup", aliases=["channel"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def confession_setup(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO confession_settings (guild_id, channel_id, enabled) "
                "VALUES (?, ?, 1) ON CONFLICT(guild_id) DO UPDATE SET "
                "channel_id = excluded.channel_id, enabled = 1",
                (ctx.guild.id, channel.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Confessions Configured",
            f"Anonymous confessions will be posted in {channel.mention}."),
            mention_author=False)

    @confession.command(name="disable", aliases=["off"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def confession_disable(self, ctx):
        db = await self._connect()
        try:
            cur = await db.execute(
                "UPDATE confession_settings SET enabled = 0 WHERE guild_id = ?",
                (ctx.guild.id,))
            await db.commit()
            changed = cur.rowcount
        finally:
            await db.close()
        if not changed:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Set Up", "There is no confession channel to disable."))
        await ctx.reply(embed=self.embed(
            f"{TICK} Confessions Disabled", "No new confessions will be posted."),
            mention_author=False)

    @commands.command(name="confess", aliases=["confessionpost"],
                      help="Post an anonymous confession.")
    @commands.guild_only()
    @commands.cooldown(1, 60, commands.BucketType.user)
    async def confess(self, ctx, *, text: str = None):
        if not text or len(text.strip()) < 5:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}confess <your secret>`"))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT channel_id, enabled FROM confession_settings WHERE guild_id = ?",
                (ctx.guild.id,)
            ) as cur:
                row = await cur.fetchone()
        finally:
            await db.close()
        if not row or not int(row["enabled"]):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Confessions Off",
                f"An admin must run `{ctx.clean_prefix}confession setup #channel` first."))
        channel = ctx.guild.get_channel(int(row["channel_id"]))
        if channel is None:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Channel Missing", "The confession channel was deleted."))
        body = text.strip()[:900]
        embed = discord.Embed(
            title="Anonymous Confession",
            description=body,
            color=COLOR,
            timestamp=datetime.now(timezone.utc))
        embed.set_footer(text="Nobody can see who sent this")
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Could Not Post",
                "I need **Send Messages** + **Embed Links** in that channel."))
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
        await ctx.reply(embed=self.embed(
            f"{TICK} Confession Posted", f"Your confession went to {channel.mention} anonymously."),
            mention_author=False)


    # ── joint bank (premium) ─────────────────────────────────────────
    def _pair(self, first_id: int, second_id: int) -> str:
        low, high = sorted((first_id, second_id))
        return f"{low}:{high}"

    async def _spouse(self, guild_id: int, user_id: int) -> int | None:
        try:
            async with aiosqlite.connect("db/social.db") as db:
                async with db.execute(
                    "SELECT married_to FROM social_users WHERE guild_id = ? AND user_id = ?",
                    (guild_id, user_id)
                ) as cur:
                    row = await cur.fetchone()
            return int(row[0]) if row and row[0] else None
        except Exception:
            return None

    @commands.group(name="jointbank", aliases=["couplebank"], invoke_without_command=True,
                    help="Shared bank for married couples (premium).")
    @commands.guild_only()
    async def jointbank(self, ctx):
        if not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature",
                f"Joint bank accounts are **Premium**.\n"
                f"Run `{ctx.clean_prefix}premium` to unlock them."))
        spouse = await self._spouse(ctx.guild.id, ctx.author.id)
        if spouse is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Married",
                f"Marry someone first with `{ctx.clean_prefix}marry @member`."))
        pair = self._pair(ctx.author.id, spouse)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT amount FROM joint_accounts WHERE guild_id = ? AND pair_key = ?",
                (ctx.guild.id, pair)
            ) as cur:
                row = await cur.fetchone()
        finally:
            await db.close()
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{MONEY} Joint Bank",
            f"**Balance:** {money(row['amount'] if row else 0)} coins\n"
            f"**With:** <@{spouse}>\n\n"
            f"`{p}jointbank deposit 500` · `{p}jointbank withdraw 500`"),
            mention_author=False)

    @jointbank.command(name="deposit", aliases=["dep"])
    @commands.guild_only()
    async def jointbank_deposit(self, ctx, amount: str = None):
        if not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature", "Joint bank accounts are **Premium**."))
        spouse = await self._spouse(ctx.guild.id, ctx.author.id)
        if spouse is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Married", "You need a spouse for a joint account."))
        value = parse_amount(amount)
        if value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}jointbank deposit 500`"))
        db = await self._eco()
        try:
            row = await self._eco_user(db, ctx.guild.id, ctx.author.id)
            if int(row["coins"]) < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Cash",
                    f"You only have **{money(row['coins'])}** coins."))
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, ctx.author.id))
            await db.commit()
        finally:
            await db.close()
        pair = self._pair(ctx.author.id, spouse)
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO joint_accounts (guild_id, pair_key, amount) VALUES (?, ?, ?) "
                "ON CONFLICT(guild_id, pair_key) DO UPDATE SET amount = amount + ?",
                (ctx.guild.id, pair, value, value))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Joint Deposit",
            f"**{money(value)} coins** added to your couple bank."), mention_author=False)

    @jointbank.command(name="withdraw", aliases=["with"])
    @commands.guild_only()
    async def jointbank_withdraw(self, ctx, amount: str = None):
        if not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature", "Joint bank accounts are **Premium**."))
        spouse = await self._spouse(ctx.guild.id, ctx.author.id)
        if spouse is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Married", "You need a spouse for a joint account."))
        pair = self._pair(ctx.author.id, spouse)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT amount FROM joint_accounts WHERE guild_id = ? AND pair_key = ?",
                (ctx.guild.id, pair)
            ) as cur:
                row = await cur.fetchone()
            held = int(row["amount"]) if row else 0
            value = parse_amount(amount)
            if value in (None, -1):
                value = held
            if value <= 0 or held < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough",
                    f"The joint account holds **{money(held)}** coins."))
            await db.execute(
                "UPDATE joint_accounts SET amount = amount - ? WHERE guild_id = ? "
                "AND pair_key = ?", (value, ctx.guild.id, pair))
            await db.commit()
        finally:
            await db.close()
        db = await self._eco()
        try:
            await self._eco_user(db, ctx.guild.id, ctx.author.id)
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, ctx.author.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Joint Withdrawal",
            f"Took **{money(value)} coins** out of the couple bank."), mention_author=False)

    # ── anniversary ─────────────────────────────────────────────────
    @commands.group(name="anniversary", aliases=["anniv"], invoke_without_command=True,
                    help="Track the anniversary of your marriage.")
    @commands.guild_only()
    async def anniversary(self, ctx):
        spouse = await self._spouse(ctx.guild.id, ctx.author.id)
        if spouse is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Married", "Marry someone first to track an anniversary."))
        pair = self._pair(ctx.author.id, spouse)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT day FROM anniversaries WHERE guild_id = ? AND pair_key = ?",
                (ctx.guild.id, pair)
            ) as cur:
                row = await cur.fetchone()
        finally:
            await db.close()
        if not row:
            return await ctx.reply(embed=self.embed(
                f"{HEARTS} Anniversary",
                f"Set your wedding date with "
                f"`{ctx.clean_prefix}anniversary set 2026-11-22`."))
        try:
            day = datetime.fromisoformat(str(row["day"])).date()
        except ValueError:
            day = None
        if day is None:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Date", "Resave your date with `anniversary set`."))
        today = datetime.now(timezone.utc).date()
        days = (today - day).days
        await ctx.reply(embed=self.embed(
            f"{HEARTS} Anniversary",
            f"You and <@{spouse}> have been married for **{max(0, days)}** day(s).\n"
            f"Wedding date: **{day.isoformat()}**"), mention_author=False)

    @anniversary.command(name="set")
    @commands.guild_only()
    async def anniversary_set(self, ctx, day: str = None):
        spouse = await self._spouse(ctx.guild.id, ctx.author.id)
        if spouse is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Married", "You need a spouse first."))
        try:
            parsed = datetime.fromisoformat((day or "").strip())
        except ValueError:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Date", "Use `YYYY-MM-DD`, for example `2026-02-14`."))
        if parsed.date() > datetime.now(timezone.utc).date():
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Future Date", "The date cannot be in the future."))
        pair = self._pair(ctx.author.id, spouse)
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO anniversaries (guild_id, pair_key, day) VALUES (?, ?, ?) "
                "ON CONFLICT(guild_id, pair_key) DO UPDATE SET day = excluded.day",
                (ctx.guild.id, pair, parsed.date().isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Anniversary Saved",
            f"Wedding date set to **{parsed.date().isoformat()}**."), mention_author=False)

    # ── profile accent (premium) ────────────────────────────────────
    @commands.command(name="accent", aliases=["profilecolor", "setaccent"],
                      help="Set your profile card colour (premium).")
    @commands.guild_only()
    async def accent(self, ctx, colour: str = None):
        if not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature",
                f"Profile colours are **Premium**.\n"
                f"Run `{ctx.clean_prefix}premium` to unlock them."))
        raw = (colour or "").strip().lstrip("#")
        if len(raw) != 6:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}accent #ff0000` (a hex colour)."))
        try:
            int(raw, 16)
        except ValueError:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Colour", "That is not a hex colour like `#ff0000`."))
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO profile_extras (guild_id, user_id, accent) VALUES (?, ?, ?) "
                "ON CONFLICT(guild_id, user_id) DO UPDATE SET accent = excluded.accent",
                (ctx.guild.id, ctx.author.id, raw.lower()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Accent Saved", f"Your profile card now uses **#{raw.lower()}**."),
            mention_author=False)


async def setup(bot):
    await bot.add_cog(SocialPlus(bot))
