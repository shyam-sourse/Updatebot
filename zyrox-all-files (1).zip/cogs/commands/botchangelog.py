"""Bot changes log — AI-polished bot update notes posted to one channel.

Staff pick a channel with ``botlog set #channel``. Later they paste raw
change notes into ``botlog post <notes>``; FreeLLMAPI turns those notes into
a clean Added / Improved / Fixed changelog and the bot posts it to the
selected channel.

Config lives in ``db/botlog.db``:

* ``botlog_config`` – guild_id → channel_id
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils import ai_utils
from utils.config import BRAND_NAME, OWNER_IDS

DB_PATH = os.path.join("db", "botlog.db")

COLOR = 0xFF0000
GREEN = 0x2ECC71
GREY = 0x95A5A6

AI_SYSTEM = (
    "You write Discord bot update changelogs. The user gives raw change notes. "
    "Rewrite them into a short, clean changelog.\n"
    "Rules:\n"
    "- Use only these section headings when relevant: **✨ Added**, **🛠️ Improved**, **🐛 Fixed**\n"
    "- One short bullet per change, starting with '- '\n"
    "- Keep every fact; never invent features, dates or versions\n"
    "- No intro, no outro, no extra commentary\n"
    "- Maximum 12 bullets total"
)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


async def init_db() -> None:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS botlog_config (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER NOT NULL,
                updated_at TEXT
            )
            """
        )
        await db.commit()


async def get_channel_id(guild_id: int) -> int | None:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(
                "SELECT channel_id FROM botlog_config WHERE guild_id = ?", (guild_id,)
            ) as cursor:
                row = await cursor.fetchone()
    except aiosqlite.Error:
        return None
    return int(row[0]) if row else None


async def set_channel(guild_id: int, channel_id: int) -> None:
    await init_db()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO botlog_config (guild_id, channel_id, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET "
            "channel_id = excluded.channel_id, updated_at = excluded.updated_at",
            (guild_id, channel_id, _utcnow().isoformat()),
        )
        await db.commit()


async def clear_channel(guild_id: int) -> bool:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("DELETE FROM botlog_config WHERE guild_id = ?", (guild_id,))
            await db.commit()
            return cursor.rowcount > 0
    except aiosqlite.Error:
        return False


async def find_guild_for_channel(channel_id: int) -> int | None:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(
                "SELECT guild_id FROM botlog_config WHERE channel_id = ?", (channel_id,)
            ) as cursor:
                row = await cursor.fetchone()
    except aiosqlite.Error:
        return None
    return int(row[0]) if row else None


def is_staff(member: discord.Member | None) -> bool:
    if member is None:
        return False
    if member.id in OWNER_IDS:
        return True
    perms = getattr(member, "guild_permissions", None)
    return bool(perms is not None and (perms.administrator or perms.manage_guild))


async def _reply(ctx, message: str | None = None, ephemeral: bool = False, embed=None):
    kwargs: dict = {}
    if message is not None:
        kwargs["content"] = message
    if embed is not None:
        kwargs["embed"] = embed
    if ctx.interaction is not None:
        kwargs["ephemeral"] = ephemeral
        if ctx.interaction.response.is_done():
            return await ctx.interaction.followup.send(**kwargs)
        return await ctx.interaction.response.send_message(**kwargs)
    return await ctx.send(**kwargs)


def _raw_changelog(notes: str) -> str:
    lines = [line.strip(" -•\t") for line in notes.splitlines() if line.strip()]
    return "\n".join(f"- {line}" for line in lines)[:3800]


async def analyze_changes(notes: str) -> tuple[str, bool]:
    """Return ``(changelog_text, used_ai)``."""
    if not ai_utils.is_configured():
        return _raw_changelog(notes), False
    try:
        text = await asyncio.wait_for(
            ai_utils.ask_ai(
                f"Raw bot change notes:\n{notes[:3000]}",
                system=AI_SYSTEM,
                max_tokens=600,
            ),
            timeout=35,
        )
    except Exception:
        return _raw_changelog(notes), False
    text = (text or "").strip()
    if not text or len(text) < 5:
        return _raw_changelog(notes), False
    return text[:3800], True


def update_embed(changelog: str, author: discord.abc.User, used_ai: bool) -> discord.Embed:
    embed = discord.Embed(
        title="🚀 Bot Update",
        description=changelog,
        color=COLOR,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_footer(text=f"{BRAND_NAME} · Bot Changes Log")
    embed.add_field(
        name="Posted by",
        value=f"{author.mention} (`{author.id}`)",
        inline=False,
    )
    if not used_ai:
        embed.add_field(
            name="AI analysis",
            value="Not available — raw notes posted. Set `FREELLM_API_KEY` to auto-format.",
            inline=False,
        )
    return embed


class BotChangesLog(commands.Cog, name="BotChangesLog"):
    def __init__(self, bot):
        self.bot = bot
        bot.loop.create_task(init_db())

    def help_custom(self):
        return "🚀", "Bot Changes Log", "Post AI-written bot update notes to a channel"

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        guild_id = await find_guild_for_channel(channel.id)
        if guild_id is not None:
            await clear_channel(guild_id)

    @commands.hybrid_group(
        name="botlog",
        aliases=["botchangelog"],
        invoke_without_command=True,
        description="AI-analyzed bot changes posted to a selected channel.",
    )
    async def botlog(self, ctx):
        await ctx.send_help(ctx.command)

    @botlog.command(name="set", description="Choose the channel for bot change posts (admin).")
    async def set_cmd(self, ctx, channel: discord.TextChannel):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can set the bot changes channel.", ephemeral=True)
        await set_channel(ctx.guild.id, channel.id)
        await _reply(
            ctx,
            f"✅ Bot changes will be posted in {channel.mention}.\n"
            "Use `botlog post <changes>` to publish an update.",
            ephemeral=True,
        )

    @botlog.command(name="off", description="Stop bot change posts in this server.")
    async def off(self, ctx):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can change this setting.", ephemeral=True)
        removed = await clear_channel(ctx.guild.id)
        await _reply(
            ctx,
            "🗑️ Bot changes channel removed." if removed else "Bot changes channel was not set.",
            ephemeral=True,
        )

    @botlog.command(name="status", description="Show the selected bot changes channel.")
    async def status(self, ctx):
        channel_id = await get_channel_id(ctx.guild.id)
        channel = ctx.guild.get_channel(channel_id) if channel_id else None
        embed = discord.Embed(
            title="🚀 Bot Changes Log",
            description=(
                f"**Channel:** {channel.mention if channel else ('missing — set it again' if channel_id else 'not set')}\n"
                f"**AI analysis:** {'ready' if ai_utils.is_configured() else 'not configured'}\n"
                "**Post with:** `botlog post <your raw change notes>`"
            ),
            color=GREEN if channel else GREY,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text=f"{BRAND_NAME} · Bot Changes Log")
        await _reply(ctx, embed=embed, ephemeral=True)

    @botlog.command(name="preview", description="Preview the AI-formatted update without posting it.")
    async def preview(self, ctx, *, notes: str):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can preview bot updates.", ephemeral=True)
        await _reply(ctx, "🧠 Analyzing changes…", ephemeral=True)
        changelog, used_ai = await analyze_changes(notes)
        embed = update_embed(changelog, ctx.author, used_ai)
        embed.title = "🚀 Bot Update (preview)"
        if ctx.interaction is not None:
            return await ctx.interaction.followup.send(embed=embed, ephemeral=True)
        await ctx.reply(embed=embed)

    @botlog.command(name="post", description="AI-format your changes and post them to the selected channel.")
    async def post(self, ctx, *, notes: str):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can post bot updates.", ephemeral=True)
        channel_id = await get_channel_id(ctx.guild.id)
        channel = ctx.guild.get_channel(channel_id) if channel_id else None
        if channel is None:
            return await _reply(
                ctx,
                "Set a channel first with `botlog set #channel`.",
                ephemeral=True,
            )
        await _reply(ctx, "🧠 Analyzing changes…", ephemeral=True)
        changelog, used_ai = await analyze_changes(notes)
        embed = update_embed(changelog, ctx.author, used_ai)
        try:
            message = await channel.send(embed=embed)
        except (discord.Forbidden, discord.HTTPException):
            return await ctx.send(
                f"❌ I cannot post in {channel.mention}. Check my Send Messages / Embed Links permission."
            )
        note = "AI-formatted" if used_ai else "AI not configured, raw notes posted"
        if ctx.interaction is not None:
            return await ctx.interaction.followup.send(
                f"✅ Posted in {channel.mention} ({note}).\n{message.jump_url}",
                ephemeral=True,
            )
        await ctx.reply(
            f"✅ Posted in {channel.mention} ({note}).\n{message.jump_url}",
            mention_author=False,
        )


async def setup(bot):
    await bot.add_cog(BotChangesLog(bot))
