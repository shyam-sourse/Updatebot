# ╔══════════════════════════════════════════════════════════════════╗
# ║   AI Extras  ──  a pile of small AI tools (free + premium)        ║
# ║   aitldr • aigrammar • aipoem • aistory • aibio • ainame • aijoke ║
# ║   aievent • aiinterview • aistudy • aifaq • aidebate • aibrand    ║
# ║   aicatchup • aihub                                               ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Extra AI commands built on top of the single FreeLLMAPI backend.

Free for every server: summary, rewrite, poem, story, bio, names, jokes.
Premium only: event plan, mock interview, study plan, FAQ, debate, brand kit
and AI channel catch-up. Every command spends one AI reply from the server's
daily budget (``ai_chat_per_day``), so a busy server cannot burn the endpoint.
"""

import discord
from discord.ext import commands

from utils import freellm, premium
from utils.ai_utils import ask_ai
from utils.emoji import ZAI, TICK, CROSS, WARNING, INFO, ENABLE, DISABLE

COLOR = 0xFF0000
MAX_EMBED = 3900
MAX_SOURCE = 4000

#: ask_ai returns its error text as a normal string, so it can be detected
ERROR_STARTS = ("🔑", "⏳", "🚦", "🌐", "⚠️", "📡", "🤖", "🛡️")

NOT_CONFIGURED = (
    "The bot owner has not configured the AI endpoint yet.\n"
    "It needs `FREELLM_API_URL`, `FREELLM_API_KEY` and `FREELLM_MODEL` "
    "in the `.env` file."
)


class AIExtras(commands.Cog):
    """Small AI helpers: writing, planning, summarising and coaching."""

    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    def help_custom():
        return (ZAI, "AI Extras",
                "Summarise, rewrite, write, plan and more with AI.")

    # ── helpers ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description[:MAX_EMBED],
                             color=COLOR)

    async def _ready(self, ctx) -> bool:
        """False (and a message) when the AI endpoint is not configured."""
        if freellm.is_configured():
            return True
        await ctx.send(embed=self.embed(f"{WARNING} AI Not Configured", NOT_CONFIGURED))
        return False

    async def _spend(self, ctx) -> bool:
        """Charge one daily AI reply. False when the server is out of budget."""
        if not ctx.guild:
            return True
        try:
            allowed, used, limit = await premium.consume_ai(ctx.guild.id)
        except Exception:
            return True
        if allowed:
            return True
        if premium.ai_limit_notice_pending(ctx.guild.id):
            plan_name = (await premium.get_plan(guild_id=ctx.guild.id))["name"]
            await ctx.send(embed=self.embed(
                f"{WARNING} AI Limit Reached",
                f"This server used all **{used} / {limit}** AI replies for "
                f"today on the **{plan_name}** plan.\n"
                f"Upgrade with `{ctx.clean_prefix}premium` to raise the limit."))
        return False

    async def _paid(self, ctx) -> bool:
        """False (and an upgrade prompt) when the guild is on the free plan."""
        if not ctx.guild:
            return False
        plan = await premium.get_plan_key(ctx.guild.id)
        if plan != premium.FREE:
            return True
        await ctx.send(embed=self.embed(
            f"{CROSS} Premium Feature",
            f"`{ctx.command.qualified_name}` is a **Premium** command.\n\n"
            f"Premium unlocks AI planning, coaching, FAQs and channel "
            f"catch-up.\nRun `{ctx.clean_prefix}premium` to upgrade."))
        return False

    async def _reply(self, ctx, title, text):
        """Send long AI text as up to three embeds."""
        text = (text or "").strip()
        if not text:
            text = "The AI returned an empty answer. Try again."
        chunks = [text[i:i + MAX_EMBED] for i in range(0, len(text), MAX_EMBED)][:3]
        await ctx.reply(embed=self.embed(title, chunks[0]), mention_author=False)
        for extra in chunks[1:]:
            await ctx.send(embed=self.embed(f"{title} (cont.)", extra))

    async def _generate(self, ctx, title, prompt, system, max_tokens=700):
        """Shared pipeline: config check -> budget -> AI -> embed."""
        if not await self._ready(ctx):
            return
        if not await self._spend(ctx):
            return
        async with ctx.typing():
            text = await ask_ai(prompt[:MAX_SOURCE], system=system,
                                max_tokens=max_tokens)
        if isinstance(text, str) and text.startswith(ERROR_STARTS):
            return await ctx.send(embed=self.embed(f"{CROSS} AI Error", text))
        await self._reply(ctx, title, text)

    async def _source_text(self, ctx, text):
        """Use the given text, else the replied-to message, else None."""
        if text:
            return text.strip()
        ref = ctx.message.reference
        if ref and ref.message_id:
            try:
                target = ref.resolved or await ctx.channel.fetch_message(ref.message_id)
            except (discord.HTTPException, AttributeError):
                return None
            if isinstance(target, discord.Message):
                return (target.content or "").strip()
        return None

    # ── hub ──────────────────────────────────────────────────────────
    @commands.command(name="aihub", aliases=["aifeatures", "aiextras", "aitools"],
                      help="List every extra AI command.")
    async def aihub(self, ctx):
        p = ctx.clean_prefix
        await ctx.send(embed=self.embed(
            f"{ZAI} AI Extras",
            f"**Free for everyone**\n"
            f"`{p}aitldr [text]` — summary of text or a replied message\n"
            f"`{p}aigrammar [text]` — fix grammar & make it sound natural\n"
            f"`{p}aipoem <topic>` — poem, rap or short song\n"
            f"`{p}aistory <topic>` — short story\n"
            f"`{p}aibio [traits]` — Discord about-me / bio\n"
            f"`{p}ainame [what]` — name ideas for servers, channels, roles\n"
            f"`{p}aijoke [topic]` — joke or riddle with the answer\n\n"
            f"{ENABLE} **Premium**\n"
            f"`{p}aievent <idea>` — full event plan with timeline\n"
            f"`{p}aiinterview <role>` — mock interview questions + tips\n"
            f"`{p}aistudy <subject> [days]` — study plan\n"
            f"`{p}aifaq <topic>` — FAQ draft for your server\n"
            f"`{p}aidebate <topic>` — both sides of an argument\n"
            f"`{p}aibrand <description>` — brand kit: name, tagline, tone\n"
            f"`{p}aicatchup [count]` — AI summary of recent channel chat\n\n"
            f"Every command uses one AI reply from the server's daily budget."))

    # ── free commands ────────────────────────────────────────────────
    @commands.command(name="aitldr", aliases=["aitl", "aisum"],
                      help="Summarise a long text or the message you replied to.")
    async def aitldr(self, ctx, *, text: str = None):
        source = await self._source_text(ctx, text)
        if not source:
            return await ctx.send(embed=self.embed(
                f"{INFO} Nothing To Summarise",
                f"Usage: `{ctx.clean_prefix}aitldr <long text>` — or reply to "
                f"a message with `{ctx.clean_prefix}aitldr`."))
        await self._generate(
            ctx, f"{ZAI} Summary",
            f"Summarise this text:\n\n{source}",
            "You summarise text for a Discord user. Reply with a 2-4 line "
            "TL;DR, then 3-5 short bullet points of the key facts. Be concise, "
            "no extra commentary.", max_tokens=500)

    @commands.command(name="aigrammar", aliases=["aifix", "airewrite"],
                      help="Fix grammar and rewrite text so it reads naturally.")
    async def aigrammar(self, ctx, *, text: str = None):
        source = await self._source_text(ctx, text)
        if not source:
            return await ctx.send(embed=self.embed(
                f"{INFO} Nothing To Rewrite",
                f"Usage: `{ctx.clean_prefix}aigrammar <text>` — or reply to a "
                f"message."))
        await self._generate(
            ctx, f"{ZAI} Rewritten",
            f"Rewrite this text with correct grammar and a natural tone, "
            f"keeping the meaning and language the same:\n\n{source}",
            "You are a careful editor. Return the corrected text only, then a "
            "line '— changed: ...' listing the main fixes in at most 3 items.",
            max_tokens=600)

    @commands.command(name="aipoem", help="Write a poem, rap or short song.")
    async def aipoem(self, ctx, *, topic: str = None):
        if not topic:
            return await ctx.send(embed=self.embed(
                f"{INFO} Topic Required",
                f"Usage: `{ctx.clean_prefix}aipoem <topic or feeling>`"))
        await self._generate(
            ctx, f"{ZAI} Poem — {topic[:60]}",
            f"Write a short poem (8-12 lines) about: {topic}",
            "You are a poet. Write one short, original poem with rhythm and "
            "imagery. No introduction, just the poem.", max_tokens=450)

    @commands.command(name="aistory", help="Write a short story.")
    async def aistory(self, ctx, *, topic: str = None):
        if not topic:
            return await ctx.send(embed=self.embed(
                f"{INFO} Topic Required",
                f"Usage: `{ctx.clean_prefix}aistory <topic or opening line>`"))
        await self._generate(
            ctx, f"{ZAI} Story — {topic[:60]}",
            f"Write a short story (200-300 words) about: {topic}",
            "You are a storyteller. Write a complete short story with a hook, "
            "a small twist and a satisfying ending. Plain text only.",
            max_tokens=800)

    @commands.command(name="aibio", aliases=["aiabout"],
                      help="Write a Discord bio / about-me.")
    async def aibio(self, ctx, *, traits: str = None):
        subject = traits or f"a Discord user named {ctx.author.display_name}"
        await self._generate(
            ctx, f"{ZAI} Your Bio",
            f"Write 3 different Discord 'About Me' bios for: {subject}",
            "Write three short, punchy Discord bios (max 130 characters each), "
            "numbered 1-3, matching the given vibe. No hashtags, no emoji spam.",
            max_tokens=350)

    @commands.command(name="ainame", aliases=["ainames"],
                      help="Generate names for a server, channel, role or team.")
    async def ainame(self, ctx, *, what: str = None):
        if not what:
            return await ctx.send(embed=self.embed(
                f"{INFO} Description Required",
                f"Example: `{ctx.clean_prefix}ainame gaming community for "
                f"mobile players`"))
        await self._generate(
            ctx, f"{ZAI} Name Ideas",
            f"Suggest names for: {what}",
            "Suggest 12 short name ideas (1-3 words each), grouped as: "
            "Clean, Edgy, Cozy. No duplicates, no explanation.", max_tokens=400)

    @commands.command(name="aijoke", aliases=["airiddle"],
                      help="Tell a joke or a riddle with the answer.")
    async def aijoke(self, ctx, *, topic: str = None):
        await self._generate(
            ctx, f"{ZAI} Joke",
            f"Tell a joke" + (f" about {topic}" if topic else "") +
            " and then a riddle with its answer hidden below.",
            "You are a fun Discord bot. Output one short joke (2 lines max), "
            "then a riddle, then '||answer||' using Discord spoiler tags. "
            "Keep it clean and friendly.", max_tokens=300)

    # ── premium commands ─────────────────────────────────────────────
    @commands.command(name="aievent", help="Plan an event with a timeline (premium).")
    @commands.guild_only()
    async def aievent(self, ctx, *, idea: str = None):
        if not await self._paid(ctx):
            return
        if not idea:
            return await ctx.send(embed=self.embed(
                f"{INFO} Idea Required",
                f"Example: `{ctx.clean_prefix}aievent 24 hour Minecraft build "
                f"competition`"))
        await self._generate(
            ctx, f"{ZAI} Event Plan",
            f"Plan this Discord community event: {idea}",
            "You plan Discord community events. Give: a catchy title, a "
            "one-line pitch, a step-by-step timeline with timings, what staff "
            "must prepare, 3 engagement hooks and how to measure success. "
            "Use short headings and bullets.", max_tokens=800)

    @commands.command(name="aiinterview", aliases=["aimock"],
                      help="Mock interview questions for a role (premium).")
    @commands.guild_only()
    async def aiinterview(self, ctx, *, role: str = None):
        if not await self._paid(ctx):
            return
        if not role:
            return await ctx.send(embed=self.embed(
                f"{INFO} Role Required",
                f"Example: `{ctx.clean_prefix}aiinterview discord moderator`"))
        await self._generate(
            ctx, f"{ZAI} Interview — {role[:50]}",
            f"Prepare a mock interview for the role: {role}",
            "You are an interview coach. Give 8 realistic questions (mix of "
            "behavioural and role-specific), then for each a one-line hint on "
            "what a strong answer includes. Numbered list, no filler.",
            max_tokens=900)

    @commands.command(name="aistudy", help="Build a study plan (premium).")
    @commands.guild_only()
    async def aistudy(self, ctx, *, subject: str = None):
        if not await self._paid(ctx):
            return
        if not subject:
            return await ctx.send(embed=self.embed(
                f"{INFO} Subject Required",
                f"Example: `{ctx.clean_prefix}aistudy physics 14`"))
        await self._generate(
            ctx, f"{ZAI} Study Plan",
            f"Build a study plan for: {subject}",
            "You are a study coach. Ask for no extra info: assume 1-2 hours a "
            "day. Output a day-by-day plan (max 14 days) with what to study, "
            "one practice task per day, and 3 exam-day tips. Short bullets.",
            max_tokens=900)

    @commands.command(name="aifaq", help="Draft an FAQ for your server (premium).")
    @commands.guild_only()
    async def aifaq(self, ctx, *, topic: str = None):
        if not await self._paid(ctx):
            return
        if not topic:
            return await ctx.send(embed=self.embed(
                f"{INFO} Topic Required",
                f"Example: `{ctx.clean_prefix}aifaq rules, verification and "
                f"how to get support`"))
        await self._generate(
            ctx, f"{ZAI} FAQ Draft",
            f"Write an FAQ for a Discord server about: {topic}",
            "Write 8 FAQ entries as '**Q:** ...' and '**A:** ...' pairs. Keep "
            "answers under 3 lines, friendly and practical. No intro.",
            max_tokens=900)

    @commands.command(name="aidebate", help="Argue both sides of a topic (premium).")
    @commands.guild_only()
    async def aidebate(self, ctx, *, topic: str = None):
        if not await self._paid(ctx):
            return
        if not topic:
            return await ctx.send(embed=self.embed(
                f"{INFO} Topic Required",
                f"Example: `{ctx.clean_prefix}aidebate homework should be "
                f"banned in schools`"))
        await self._generate(
            ctx, f"{ZAI} Both Sides",
            f"Debate topic: {topic}",
            "You are a neutral debate coach. Give 'For:' with 4 strong points, "
            "'Against:' with 4 strong points, then a one-line verdict on which "
            "side is easier to defend and why. No bias, no insults.",
            max_tokens=800)

    @commands.command(name="aibrand", help="Create a brand kit (premium).")
    @commands.guild_only()
    async def aibrand(self, ctx, *, description: str = None):
        if not await self._paid(ctx):
            return
        if not description:
            return await ctx.send(embed=self.embed(
                f"{INFO} Description Required",
                f"Example: `{ctx.clean_prefix}aibrand a Discord community for "
                f"indie game devs`"))
        await self._generate(
            ctx, f"{ZAI} Brand Kit",
            f"Create a brand kit for: {description}",
            "Act as a brand designer. Output: 3 name options, a tagline, brand "
            "tone (3 adjectives), a colour palette of 4 hex codes with names, "
            "5 emoji that fit, and a one-line server description. Compact.",
            max_tokens=700)

    @commands.command(name="aicatchup", aliases=["aisummarize", "aicatch"],
                      help="AI summary of recent chat in this channel (premium).")
    @commands.guild_only()
    @commands.bot_has_permissions(read_message_history=True)
    async def aicatchup(self, ctx, count: int = 60):
        if not await self._paid(ctx):
            return
        count = max(10, min(count, 150))
        async with ctx.typing():
            lines = []
            try:
                async for msg in ctx.channel.history(limit=count):
                    if msg.author.bot or not msg.content:
                        continue
                    lines.append(f"{msg.author.display_name}: {msg.content[:200]}")
            except discord.HTTPException:
                return await ctx.send(embed=self.embed(
                    f"{CROSS} Could Not Read Messages",
                    "I need **Read Message History** in this channel."))
        if not lines:
            return await ctx.send(embed=self.embed(
                f"{INFO} Nothing To Catch Up On",
                "No recent messages with text were found here."))
        transcript = "\n".join(reversed(lines))[:MAX_SOURCE]
        await self._generate(
            ctx, f"{ZAI} Catch Up — last {len(lines)} messages",
            f"Recent chat in #{ctx.channel.name}:\n\n{transcript}",
            "Summarise this Discord conversation for someone who missed it. "
            "Give: TL;DR in one line, the main topics, any decisions made, and "
            "anything awaiting a reply. Short bullets, no names unless needed.",
            max_tokens=700)

    @commands.command(name="aicoach", aliases=["aigrowth"],
                      help="Growth plan for this server from its stats (premium).")
    @commands.guild_only()
    async def aicoach(self, ctx):
        if not await self._paid(ctx):
            return
        guild = ctx.guild
        text_channels = list(guild.text_channels)
        tracked = await premium.count_rows(
            "db/leveling.db",
            "SELECT COUNT(*) FROM users WHERE guild_id = ? AND xp > 0",
            (guild.id,))
        stats = (
            f"Name: {guild.name}\n"
            f"Members: {len(guild.members)} "
            f"({sum(1 for m in guild.members if m.bot)} bots)\n"
            f"Members with XP: {tracked}\n"
            f"Text channels ({len(text_channels)}): "
            f"{', '.join(c.name for c in text_channels[:12])}\n"
            f"Voice channels: {len(guild.voice_channels)}\n"
            f"Roles: {len(guild.roles)}\n"
            f"Boosts: {guild.premium_subscription_count} (tier {guild.premium_tier})\n"
            f"Created: {guild.created_at.date().isoformat()}"
        )
        await self._generate(
            ctx, f"{ZAI} Growth Coach — {guild.name}",
            f"Server stats:\n{stats}\n\nGive this server a growth plan.",
            "You coach Discord community owners. Using only the stats given, "
            "reply with: 5 concrete actions for this week, 2 event ideas that fit "
            "the channel list, 1 retention fix, and the single number they should "
            "watch. Short bullets, no generic filler.", max_tokens=800)

    @commands.command(name="aimod", aliases=["aimodnote", "aimodreport"],
                      help="Turn a messy report into a clean mod note (premium).")
    @commands.guild_only()
    async def aimod(self, ctx, *, text: str = None):
        if not await self._paid(ctx):
            return
        source = await self._source_text(ctx, text)
        if not source:
            return await ctx.send(embed=self.embed(
                f"{INFO} Nothing To Review",
                f"Usage: `{ctx.clean_prefix}aimod <report or chat log>` — or reply "
                f"to the message you want judged."))
        await self._generate(
            ctx, f"{ZAI} Moderator Note",
            f"Raw report or chat log:\n\n{source}",
            "You assist Discord moderators. Reply with: a neutral one-line summary, "
            "the likely rule(s) broken in generic terms, one suggested action "
            "(warn/timeout/kick/ban) with a duration, and a short message to send "
            "the member. No moralising, no assumptions beyond the text.",
            max_tokens=600)


async def setup(bot):
    await bot.add_cog(AIExtras(bot))
