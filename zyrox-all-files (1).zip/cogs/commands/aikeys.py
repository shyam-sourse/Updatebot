# ╔══════════════════════════════════════════════════════════════════╗
# ║   AI Status  ──  inspect the FreeLLMAPI backend from Discord      ║
# ║   status • test • models • reload                                ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Owner-only commands to inspect the bot's AI backend.

The bot has exactly one AI backend now (FreeLLMAPI), configured in ``.env``:

    FREELLM_API_URL=...
    FREELLM_API_KEY=...
    FREELLM_MODEL=...

Nothing is stored in a database and there is no key pool to rotate, so these
commands only report status, ping the endpoint and list the models it serves.
"""

import aiohttp
import discord
from discord.ext import commands

from utils import freellm
from utils.emoji import ZAI, TICK, CROSS, WARNING, INFO

COLOR = 0xFF0000


class AIKeys(commands.Cog):
    """Show and test the single FreeLLMAPI endpoint the bot uses."""

    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    def help_custom():
        return (ZAI, "AI Status", "Check and test the bot's FreeLLMAPI endpoint.")

    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    @staticmethod
    def _status_text():
        cfg = freellm.config()
        host = cfg["url"].split("://", 1)[-1].split("/", 1)[0] if cfg["url"] else "—"
        return (
            f"**Endpoint:** `{host}`\n"
            f"**Model:** `{cfg['model'] or '(caller default)'}`\n"
            f"**Key:** {'set' if cfg['key'] else 'not set'}\n"
            f"**Configured:** {'yes' if freellm.is_configured() else 'no'}"
        )

    # --------------------------- commands -----------------------------
    @commands.group(name="aikeys", aliases=["gkeys", "aikey", "aistatus"],
                    invoke_without_command=True,
                    help="Show the AI backend status (owner only).")
    @commands.is_owner()
    async def aikeys(self, ctx):
        p = ctx.clean_prefix
        body = self._status_text()
        if not freellm.is_configured():
            body += ("\n\n⚠️ `FREELLM_API_URL` is not set, so every AI feature is "
                     "disabled. Add `FREELLM_API_URL`, `FREELLM_API_KEY` and "
                     "`FREELLM_MODEL` to the bot's `.env`, then restart.")
        await ctx.send(embed=self.embed(
            f"{ZAI} AI Backend (FreeLLMAPI)",
            f"{body}\n\n"
            f"`{p}aikeys status` — same panel\n"
            f"`{p}aikeys test` — send a live test prompt\n"
            f"`{p}aikeys models` — list models the endpoint offers\n"
            f"`{p}aikeys reload` — re-read `.env` without restarting"))

    @aikeys.command(name="status", aliases=["show"], help="Show the AI backend status.")
    @commands.is_owner()
    async def status(self, ctx):
        await ctx.send(embed=self.embed(
            f"{ZAI} AI Backend (FreeLLMAPI)", self._status_text()))

    @aikeys.command(name="test", aliases=["check", "ping"],
                    help="Send a live test prompt to the AI endpoint.")
    @commands.is_owner()
    async def test(self, ctx):
        if not freellm.is_configured():
            return await ctx.send(embed=self.embed(
                f"{WARNING} Not Configured",
                "Set `FREELLM_API_URL`, `FREELLM_API_KEY` and `FREELLM_MODEL` "
                "in the `.env` file first."))
        async with ctx.typing():
            try:
                started = discord.utils.utcnow()
                data = await freellm.chat({
                    "model": freellm.model_for(),
                    "messages": [{"role": "user", "content": "Reply with exactly: OK"}],
                    "max_tokens": 16,
                })
                reply = freellm.message_text(
                    ((data.get("choices") or [{}])[0].get("message") or {}))
                ms = int((discord.utils.utcnow() - started).total_seconds() * 1000)
            except freellm.FreeLLMError as exc:
                return await ctx.send(embed=self.embed(
                    f"{CROSS} Test Failed", f"{exc.user_message}\n\n```{exc}```"[:1900]))
        await ctx.send(embed=self.embed(
            f"{TICK} AI Responded",
            f"**Latency:** `{ms} ms`\n**Model:** `{freellm.model_for()}`\n"
            f"**Reply:** `{reply[:300] or '(empty)'}`"))

    @aikeys.command(name="models", help="List the models the endpoint serves.")
    @commands.is_owner()
    async def models(self, ctx):
        cfg = freellm.config()
        if not cfg["url"]:
            return await ctx.send(embed=self.embed(
                f"{WARNING} Not Configured", "`FREELLM_API_URL` is not set."))
        base = cfg["url"].rstrip("/")
        if base.endswith("/chat/completions"):
            base = base[: -len("/chat/completions")]
        url = base + "/models"
        headers = {}
        if cfg["key"]:
            headers["Authorization"] = f"Bearer {cfg['key']}"
        async with ctx.typing():
            try:
                async with aiohttp.ClientSession(
                    timeout=aiohttp.ClientTimeout(total=20)
                ) as session:
                    async with session.get(url, headers=headers) as resp:
                        if resp.status != 200:
                            raise RuntimeError(f"HTTP {resp.status}")
                        data = await resp.json()
            except Exception as exc:  # noqa: BLE001 - reported to the owner
                return await ctx.send(embed=self.embed(
                    f"{CROSS} Could Not List Models",
                    f"`{url}`\n```{exc}```"[:1900]))
        names = [item.get("id") for item in (data.get("data") or []) if item.get("id")]
        if not names:
            return await ctx.send(embed=self.embed(
                f"{INFO} No Models", "The endpoint returned an empty model list."))
        body = "\n".join(f"• `{name}`" for name in names[:40])
        await ctx.send(embed=self.embed(
            f"{ZAI} Models ({len(names)})", body[:3900]))

    @aikeys.command(name="reload", help="Re-read .env and report the new settings.")
    @commands.is_owner()
    async def reload(self, ctx):
        freellm.reload_env()
        await ctx.send(embed=self.embed(
            f"{TICK} Settings Reloaded", self._status_text()))


async def setup(bot):
    await bot.add_cog(AIKeys(bot))
