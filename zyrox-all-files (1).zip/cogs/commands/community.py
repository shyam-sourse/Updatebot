# ╔══════════════════════════════════════════════════════════════════╗
# ║   Community  ──  server goals, schedules, timed roles, threads     ║
# ║   goal • schedule • temprole • threads • csat                      ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Community goals, scheduled announcements, timed roles, thread tools and ratings."""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import premium
from utils.emoji import CROSS, INFO, MONEY, NOTE, SPARKLE, TICK, TIMER

ECO_DB = "db/economy.db"
DB = "db/community.db"
COLOR = 0xFF0000

TIME_RE = re.compile(r"(\d+)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|"
                     r"h|hr|hrs|hour|hours|d|day|days)", re.IGNORECASE)
UNIT_SECONDS = {"s": 1, "m": 60, "h": 3600, "d": 86400}
MAX_DAYS = 90

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS community_goals (
        guild_id INTEGER PRIMARY KEY,
        kind TEXT NOT NULL,
        target INTEGER NOT NULL,
        progress INTEGER NOT NULL DEFAULT 0,
        reward INTEGER NOT NULL DEFAULT 0,
        channel_id INTEGER,
        created_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS goal_contrib (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS scheduled_messages (
        schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL,
        author_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        due_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS temp_roles (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role_id INTEGER NOT NULL,
        expires_at TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id, role_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS thread_channels (
        guild_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL,
        PRIMARY KEY (guild_id, channel_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS csat_ratings (
        rating_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        stars INTEGER NOT NULL,
        created_at TEXT
    )
    """,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _seconds(raw: str) -> int | None:
    if not raw:
        return None
    text = raw.strip().lower().replace(" ", "")
    total = 0
    found = False
    for amount, unit in TIME_RE.findall(text):
        found = True
        total += int(amount) * UNIT_SECONDS[unit[0]]
    if not found or total <= 0:
        return None
    return min(total, MAX_DAYS * 86400)


class RatingView(discord.ui.View):
    """Five star buttons for a support rating."""

    def __init__(self, cog: "Community", guild_id: int, staff_id: int, user_id: int):
        super().__init__(timeout=300)
        self.cog = cog
        self.guild_id = guild_id
        self.staff_id = staff_id
        self.user_id = user_id
        self.done = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.staff_id:
            await interaction.response.send_message(
                "You cannot rate yourself.", ephemeral=True)
            return False
        return True

    async def _rate(self, interaction: discord.Interaction, stars: int):
        if self.done:
            return await interaction.response.send_message(
                "This rating is already submitted.", ephemeral=True)
        self.done = True
        await self.cog.save_rating(self.guild_id, self.staff_id,
                                   interaction.user.id, stars)
        for child in self.children:
            child.disabled = True
        self.stop()
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{TICK} Thanks!",
            f"You rated <@{self.staff_id}> **{stars}/5** stars."), view=self)

    @discord.ui.button(label="1")
    async def one(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 1)

    @discord.ui.button(label="2")
    async def two(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 2)

    @discord.ui.button(label="3")
    async def three(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 3)

    @discord.ui.button(label="4")
    async def four(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 4)

    @discord.ui.button(label="5", style=discord.ButtonStyle.success)
    async def five(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 5)


class Community(commands.Cog):
    """Server goals, schedules, timed roles, thread tools and ratings."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False
        self._goal_guilds: set[int] = set()
        self._thread_channels: set[int] = set()

    @staticmethod
    def help_custom():
        return (SPARKLE, "Community", "Goals, schedules, timed roles and ratings.")

    async def cog_load(self):
        await self._refresh_caches()
        self.timer_watch.start()

    def cog_unload(self):
        self.timer_watch.cancel()

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _refresh_caches(self):
        """Keep per-message listeners cheap by caching enabled ids."""
        db = await self._connect()
        try:
            async with db.execute("SELECT guild_id FROM community_goals") as cur:
                self._goal_guilds = {int(r["guild_id"]) for r in await cur.fetchall()}
            async with db.execute("SELECT channel_id FROM thread_channels") as cur:
                self._thread_channels = {int(r["channel_id"]) for r in await cur.fetchall()}
        finally:
            await db.close()

    async def _add_coins(self, guild_id: int, user_id: int, amount: int):
        os.makedirs("db", exist_ok=True)
        db = await aiosqlite.connect(ECO_DB)
        try:
            await db.execute(
                "CREATE TABLE IF NOT EXISTS eco_users ("
                "guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, "
                "coins INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, "
                "streak INTEGER NOT NULL DEFAULT 0, last_daily TEXT, last_work TEXT, "
                "PRIMARY KEY (guild_id, user_id))")
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, user_id))
            await db.commit()
        finally:
            await db.close()

    # ── goals ────────────────────────────────────────────────────────
    @commands.group(name="goal", aliases=["servergoal"], invoke_without_command=True,
                    help="Show the current community goal.")
    @commands.guild_only()
    async def goal(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM community_goals WHERE guild_id = ?", (ctx.guild.id,)
            ) as cur:
                row = await cur.fetchone()
        finally:
            await db.close()
        p = ctx.clean_prefix
        if row is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Goal",
                f"Set one with `{p}goal set messages 10000 25` "
                f"(kind, target, coins per contributor)."))
        percent = min(100, int(int(row["progress"]) * 100 / max(1, int(row["target"]))))
        bar = "█" * (percent // 10) + "░" * (10 - percent // 10)
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} {ctx.guild.name} Goal · {row['kind']}",
            f"`{bar}` {percent}%\n"
            f"**Progress:** {row['progress']}/{row['target']}\n"
            f"**Reward pool:** {money(row['reward'])} coins per contributor share"),
            mention_author=False)

    @goal.command(name="set")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def goal_set(self, ctx, kind: str = None, target: str = None,
                       reward: int = 0):
        kind = (kind or "").lower()
        if kind not in ("messages", "voice"):
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}goal set messages 10000 25` — "
                f"kinds: `messages`, `voice`."))
        if not target or not target.isdigit() or int(target) < 10:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Target", "Give a target of at least 10."))
        reward = max(0, min(reward, 10_000))
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO community_goals "
                "(guild_id, kind, target, progress, reward, channel_id, created_at) "
                "VALUES (?, ?, ?, 0, ?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET "
                "kind = excluded.kind, target = excluded.target, progress = 0, "
                "reward = excluded.reward, channel_id = excluded.channel_id",
                (ctx.guild.id, kind, int(target), reward, ctx.channel.id,
                 _now().isoformat()))
            await db.execute(
                "DELETE FROM goal_contrib WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
        finally:
            await db.close()
        self._goal_guilds.add(ctx.guild.id)
        await ctx.reply(embed=self.embed(
            f"{TICK} Goal Set",
            f"Target: **{target} {kind}** · reward **{money(reward)} coins** "
            f"per contributor share."), mention_author=False)

    @goal.command(name="clear")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def goal_clear(self, ctx):
        db = await self._connect()
        try:
            cur = await db.execute(
                "DELETE FROM community_goals WHERE guild_id = ?", (ctx.guild.id,))
            await db.execute(
                "DELETE FROM goal_contrib WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
            removed = cur.rowcount
        finally:
            await db.close()
        if not removed:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Goal", "There is no active goal to clear."))
        self._goal_guilds.discard(ctx.guild.id)
        await ctx.reply(embed=self.embed(
            f"{TICK} Goal Cleared", "The community goal was removed."), mention_author=False)

    async def _goal_progress(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        if message.guild.id not in self._goal_guilds:
            return
        if len((message.content or "").strip()) < 3:
            return
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM community_goals WHERE guild_id = ?", (message.guild.id,)
            ) as cur:
                goal = await cur.fetchone()
            if goal is None or goal["kind"] != "messages":
                return
            await db.execute(
                "INSERT INTO goal_contrib (guild_id, user_id, amount) VALUES (?, ?, 1) "
                "ON CONFLICT(guild_id, user_id) DO UPDATE SET amount = amount + 1",
                (message.guild.id, message.author.id))
            await db.execute(
                "UPDATE community_goals SET progress = progress + 1 WHERE guild_id = ?",
                (message.guild.id,))
            await db.commit()
            async with db.execute(
                "SELECT progress, target, reward, channel_id FROM community_goals "
                "WHERE guild_id = ?", (message.guild.id,)
            ) as cur:
                row = await cur.fetchone()
            async with db.execute(
                "SELECT user_id, amount FROM goal_contrib WHERE guild_id = ?",
                (message.guild.id,)
            ) as cur:
                contributors = await cur.fetchall()
        except Exception:
            return
        finally:
            await db.close()
        if row is None or int(row["progress"]) < int(row["target"]):
            return
        reward = int(row["reward"])
        total = sum(int(c["amount"]) for c in contributors) or 1
        for contributor in contributors:
            share = int(reward * int(contributor["amount"]) / total)
            if share > 0:
                await self._add_coins(message.guild.id, int(contributor["user_id"]), share)
        db = await self._connect()
        try:
            await db.execute(
                "DELETE FROM community_goals WHERE guild_id = ?", (message.guild.id,))
            await db.execute(
                "DELETE FROM goal_contrib WHERE guild_id = ?", (message.guild.id,))
            await db.commit()
        finally:
            await db.close()
        self._goal_guilds.discard(message.guild.id)
        channel = message.guild.get_channel(int(row["channel_id"])) if row["channel_id"] else None
        if channel:
            try:
                await channel.send(embed=self.embed(
                    f"{TICK} Goal Reached!",
                    f"The community hit **{row['target']} messages** — "
                    f"**{money(reward)} coins** were shared between "
                    f"{len(contributors)} members."))
            except discord.HTTPException:
                pass

    # ── scheduled messages ───────────────────────────────────────────
    @commands.command(name="schedule", aliases=["schedulemsg"],
                      help="Post a message later, e.g. `schedule 2h event starts`.")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def schedule(self, ctx, duration: str = None, *, text: str = None):
        seconds = _seconds(duration or "")
        if seconds is None or not text:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}schedule 2h Event starts in 2h!`"))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) FROM scheduled_messages WHERE guild_id = ?", (ctx.guild.id,)
            ) as cur:
                count = int((await cur.fetchone())[0])
            if count >= 25:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Too Many", "You already have 25 scheduled messages."))
            due = _now() + timedelta(seconds=seconds)
            await db.execute(
                "INSERT INTO scheduled_messages "
                "(guild_id, channel_id, author_id, text, due_at) VALUES (?, ?, ?, ?, ?)",
                (ctx.guild.id, ctx.channel.id, ctx.author.id, text.strip()[:1500],
                 due.isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TIMER} Scheduled",
            f"I will post this <t:{int(due.timestamp())}:R> in {ctx.channel.mention}."),
            mention_author=False)

    @commands.command(name="schedules", aliases=["scheduled"],
                      help="List scheduled messages.")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def schedules(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT schedule_id, text, due_at, channel_id FROM scheduled_messages "
                "WHERE guild_id = ? ORDER BY due_at LIMIT 20", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Nothing Scheduled", "No messages are waiting to be posted."))
        lines = []
        for row in rows:
            try:
                stamp = int(datetime.fromisoformat(row["due_at"]).timestamp())
            except ValueError:
                stamp = 0
            lines.append(f"`#{int(row['schedule_id'])}` <#{int(row['channel_id'])}> "
                         f"<t:{stamp}:R> — {row['text'][:60]}")
        await ctx.reply(embed=self.embed(f"{TIMER} Scheduled Messages", "\n".join(lines)),
                        mention_author=False)

    @commands.command(name="delschedule", aliases=["cancelschedule"],
                      help="Cancel a scheduled message.")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def delschedule(self, ctx, schedule_id: int = None):
        if schedule_id is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}delschedule 3`"))
        db = await self._connect()
        try:
            cur = await db.execute(
                "DELETE FROM scheduled_messages WHERE schedule_id = ? AND guild_id = ?",
                (schedule_id, ctx.guild.id))
            await db.commit()
            removed = cur.rowcount
        finally:
            await db.close()
        if not removed:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Found", f"No scheduled message `#{schedule_id}`."))
        await ctx.reply(embed=self.embed(
            f"{TICK} Cancelled", f"Scheduled message `#{schedule_id}` removed."),
            mention_author=False)

    # ── timed roles ──────────────────────────────────────────────────
    @commands.command(name="temprole", aliases=["trole"],
                      help="Give a role for a limited time, e.g. `temprole @user 7d @VIP`.")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    async def temprole(self, ctx, member: discord.Member = None, duration: str = None,
                       role: discord.Role = None):
        if member is None or role is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}temprole @user 7d @Role`"))
        seconds = _seconds(duration or "")
        if seconds is None:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Time", "Use something like `30m`, `12h` or `7d`."))
        if role >= ctx.guild.me.top_role:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Role Too High",
                "That role is above mine — move my role higher first."))
        try:
            await member.add_roles(role, reason=f"Timed role by {ctx.author}")
        except discord.HTTPException:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Failed", "I could not add that role."))
        expires = _now() + timedelta(seconds=seconds)
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO temp_roles (guild_id, user_id, role_id, expires_at) "
                "VALUES (?, ?, ?, ?) ON CONFLICT(guild_id, user_id, role_id) "
                "DO UPDATE SET expires_at = excluded.expires_at",
                (ctx.guild.id, member.id, role.id, expires.isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Timed Role",
            f"{member.mention} got {role.mention} until "
            f"<t:{int(expires.timestamp())}:F>."), mention_author=False)

    @commands.command(name="temproles", aliases=["troles"],
                      help="List active timed roles.")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    async def temproles(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT user_id, role_id, expires_at FROM temp_roles "
                "WHERE guild_id = ? ORDER BY expires_at LIMIT 20", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Timed Roles", "Nothing is expiring right now."))
        lines = []
        for row in rows:
            try:
                stamp = int(datetime.fromisoformat(row["expires_at"]).timestamp())
            except ValueError:
                stamp = 0
            lines.append(f"<@{int(row['user_id'])}> · <@&{int(row['role_id'])}> — "
                         f"ends <t:{stamp}:R>")
        await ctx.reply(embed=self.embed(f"{TIMER} Timed Roles", "\n".join(lines)),
                        mention_author=False)

    # ── threads ──────────────────────────────────────────────────────
    @commands.group(name="threads", aliases=["thread"], invoke_without_command=True,
                    help="Auto-thread channels and archive old threads.")
    @commands.guild_only()
    async def threads(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT channel_id FROM thread_channels WHERE guild_id = ?", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        channels = ", ".join(f"<#{int(r['channel_id'])}>" for r in rows) or "none"
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{INFO} Thread Tools",
            f"**Auto-thread channels:** {channels}\n\n"
            f"`{p}threads setup #channel` · `{p}threads off #channel` · "
            f"`{p}threads archive 24`"), mention_author=False)

    @threads.command(name="setup", aliases=["add"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def threads_setup(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        db = await self._connect()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO thread_channels (guild_id, channel_id) VALUES (?, ?)",
                (ctx.guild.id, channel.id))
            await db.commit()
        finally:
            await db.close()
        self._thread_channels.add(channel.id)
        await ctx.reply(embed=self.embed(
            f"{TICK} Auto-Thread On",
            f"Every new message in {channel.mention} will open a thread."),
            mention_author=False)

    @threads.command(name="off", aliases=["remove"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def threads_off(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        db = await self._connect()
        try:
            cur = await db.execute(
                "DELETE FROM thread_channels WHERE guild_id = ? AND channel_id = ?",
                (ctx.guild.id, channel.id))
            await db.commit()
            removed = cur.rowcount
        finally:
            await db.close()
        if not removed:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Enabled", f"{channel.mention} was not auto-threading."))
        self._thread_channels.discard(channel.id)
        await ctx.reply(embed=self.embed(
            f"{TICK} Auto-Thread Off", f"{channel.mention} will stay quiet."),
            mention_author=False)

    @threads.command(name="archive", aliases=["clean"])
    @commands.guild_only()
    @commands.has_permissions(manage_threads=True)
    async def threads_archive(self, ctx, hours: int = 24):
        hours = max(1, min(hours, 168))
        cutoff = _now() - timedelta(hours=hours)
        archived = 0
        for thread in ctx.channel.threads:
            last = thread.last_message_id
            if last is None:
                continue
            if discord.utils.snowflake_time(last) < cutoff:
                try:
                    await thread.edit(archived=True)
                    archived += 1
                except discord.HTTPException:
                    pass
        await ctx.reply(embed=self.embed(
            f"{TICK} Threads Archived",
            f"Archived **{archived}** inactive thread(s) older than {hours}h."),
            mention_author=False)

    async def _auto_thread(self, message: discord.Message):
        if not message.guild or message.author.bot or isinstance(message.channel, discord.Thread):
            return
        if message.channel.id not in self._thread_channels:
            return
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT 1 FROM thread_channels WHERE guild_id = ? AND channel_id = ?",
                (message.guild.id, message.channel.id)
            ) as cur:
                enabled = await cur.fetchone()
        except Exception:
            enabled = None
        finally:
            await db.close()
        if not enabled:
            return
        try:
            name = (message.content or "thread").strip().replace("\n", " ")[:60] or "thread"
            thread = await message.create_thread(name=name)
            await thread.send(embed=self.embed(
                f"{NOTE} Thread opened",
                f"Talk about this message here. Original: {message.jump_url}"))
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        await self._goal_progress(message)
        await self._auto_thread(message)

    # ── support ratings ──────────────────────────────────────────────
    @commands.command(name="csat", aliases=["ratestaff"],
                      help="Ask the channel for a 1-5 rating of a staff member.")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def csat(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}csat @staff`"))
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} How did we do?",
            f"Please rate the support from {member.mention} from 1 to 5 stars."),
            view=RatingView(self, ctx.guild.id, member.id, ctx.author.id),
            mention_author=False)

    async def save_rating(self, guild_id: int, staff_id: int, user_id: int, stars: int):
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO csat_ratings (guild_id, staff_id, user_id, stars, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (guild_id, staff_id, user_id, stars, _now().isoformat()))
            await db.commit()
        finally:
            await db.close()

    @commands.command(name="csatstats", aliases=["ratings"],
                      help="Average support rating for a staff member.")
    @commands.guild_only()
    async def csatstats(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) AS n, AVG(stars) AS avg FROM csat_ratings "
                "WHERE guild_id = ? AND staff_id = ?", (ctx.guild.id, member.id)
            ) as cur:
                row = await cur.fetchone()
        finally:
            await db.close()
        if not row or not int(row["n"]):
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Ratings", f"{member.display_name} has no ratings yet."))
        avg = float(row["avg"] or 0)
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} {member.display_name}'s Rating",
            f"**{avg:.2f}/5** from **{int(row['n'])}** rating(s)."),
            mention_author=False)

    # ── loops ────────────────────────────────────────────────────────
    @tasks.loop(seconds=30)
    async def timer_watch(self):
        await self.bot.wait_until_ready()
        now = _now()
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM scheduled_messages WHERE due_at <= ? LIMIT 15",
                (now.isoformat(),)
            ) as cur:
                due = await cur.fetchall()
            for row in due:
                await db.execute(
                    "DELETE FROM scheduled_messages WHERE schedule_id = ?",
                    (int(row["schedule_id"]),))
            async with db.execute(
                "SELECT * FROM temp_roles WHERE expires_at <= ? LIMIT 30",
                (now.isoformat(),)
            ) as cur:
                expired = await cur.fetchall()
            for row in expired:
                await db.execute(
                    "DELETE FROM temp_roles WHERE guild_id = ? AND user_id = ? AND role_id = ?",
                    (int(row["guild_id"]), int(row["user_id"]), int(row["role_id"])))
            await db.commit()
        finally:
            await db.close()
        for row in due:
            channel = self.bot.get_channel(int(row["channel_id"]))
            if channel is None:
                continue
            try:
                await channel.send(content=row["text"][:1900])
            except discord.HTTPException:
                pass
        for row in expired:
            guild = self.bot.get_guild(int(row["guild_id"]))
            if guild is None:
                continue
            member = guild.get_member(int(row["user_id"]))
            role = guild.get_role(int(row["role_id"]))
            if member is None or role is None:
                continue
            try:
                await member.remove_roles(role, reason="Timed role expired")
            except discord.HTTPException:
                pass


async def setup(bot):
    await bot.add_cog(Community(bot))
