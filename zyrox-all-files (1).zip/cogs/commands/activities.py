# ╔══════════════════════════════════════════════════════════════════╗
# ║   Activities  ──  fishing, digging, loot selling, lottery, heist   ║
# ║   fish • dig • bag • sell • lottery • heist                        ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Collectable mini games plus a lottery and a multiplayer heist."""

from __future__ import annotations

import asyncio
import os
import random
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import premium
from utils.emoji import CROSS, INFO, MONEY, SPARKLE, TICK, WARNING

from .economy import money

ECO_DB = "db/economy.db"
DB = "db/activities.db"
COLOR = 0xFF0000

FISH_COOLDOWN = timedelta(minutes=30)
DIG_COOLDOWN = timedelta(minutes=20)
LOTTERY_TICKET = 100
LOTTERY_LENGTH = timedelta(days=7)
HEIST_ENTRY = 100
HEIST_WINDOW = 60

# (item, sell price, weight, premium only)
FISH_LOOT = (
    ("sardine", 25, 34, False),
    ("trout", 45, 26, False),
    ("salmon", 70, 18, False),
    ("tuna", 120, 12, False),
    ("golden koi", 400, 6, False),
    ("ancient relic", 900, 3, True),
    ("old boot", 5, 1, False),
)
DIG_LOOT = (
    ("pebble", 15, 30, False),
    ("copper ore", 40, 25, False),
    ("iron ore", 75, 20, False),
    ("emerald", 180, 13, False),
    ("diamond", 500, 8, False),
    ("meteor shard", 1200, 4, True),
)

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS act_inventory (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        item TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, item)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS act_cooldowns (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        kind TEXT NOT NULL,
        used_at TEXT,
        PRIMARY KEY (guild_id, user_id, kind)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS lottery_state (
        guild_id INTEGER PRIMARY KEY,
        round INTEGER NOT NULL DEFAULT 1,
        jackpot INTEGER NOT NULL DEFAULT 0,
        channel_id INTEGER,
        ends_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS lottery_tickets (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        round INTEGER NOT NULL,
        tickets INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, round)
    )
    """,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _price(item: str) -> int:
    for name, price, _weight, _prem in FISH_LOOT + DIG_LOOT:
        if name == item:
            return price
    return 0


class HeistView(discord.ui.View):
    """Join button for an active heist."""

    def __init__(self, cog: "Activities", guild_id: int, leader_id: int):
        super().__init__(timeout=HEIST_WINDOW)
        self.cog = cog
        self.guild_id = guild_id
        self.leader_id = leader_id
        self.players: list[int] = [leader_id]

    @discord.ui.button(label="Join Heist", style=discord.ButtonStyle.success, emoji="🕵️")
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id in self.players:
            return await interaction.response.send_message(
                "You are already in this heist.", ephemeral=True)
        if len(self.players) >= 5:
            return await interaction.response.send_message(
                "The crew is full (5 members).", ephemeral=True)
        paid = await self.cog.take_coins(
            self.guild_id, interaction.user.id, HEIST_ENTRY)
        if not paid:
            return await interaction.response.send_message(
                f"You need **{money(HEIST_ENTRY)} coins** in cash to join.",
                ephemeral=True)
        self.players.append(interaction.user.id)
        await interaction.response.send_message(
            f"You joined the crew ({len(self.players)}/5).", ephemeral=True)

    async def on_timeout(self):
        self.stop()


class Activities(commands.Cog):
    """Fishing, digging, loot selling, lottery and heists."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (SPARKLE, "Activities", "Fishing, digging, lottery and heists.")

    def cog_load(self):
        self.lottery_watch.start()

    def cog_unload(self):
        self.lottery_watch.cancel()

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _eco(self):
        os.makedirs("db", exist_ok=True)
        db = await aiosqlite.connect(ECO_DB)
        db.row_factory = aiosqlite.Row
        await db.execute(
            "CREATE TABLE IF NOT EXISTS eco_users ("
            "guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, "
            "coins INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, "
            "streak INTEGER NOT NULL DEFAULT 0, last_daily TEXT, last_work TEXT, "
            "PRIMARY KEY (guild_id, user_id))")
        await db.commit()
        return db

    async def add_coins(self, guild_id: int, user_id: int, amount: int):
        db = await self._eco()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, user_id))
            await db.commit()
        finally:
            await db.close()

    async def take_coins(self, guild_id: int, user_id: int, amount: int) -> bool:
        db = await self._eco()
        try:
            await db.execute(
                "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
                (guild_id, user_id))
            async with db.execute(
                "SELECT coins FROM eco_users WHERE guild_id = ? AND user_id = ?",
                (guild_id, user_id)
            ) as cur:
                row = await cur.fetchone()
            if not row or int(row["coins"]) < amount:
                return False
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, user_id))
            await db.commit()
        finally:
            await db.close()
        return True

    async def _cooldown(self, guild_id: int, user_id: int, kind: str,
                        window: timedelta) -> datetime | None:
        """Return the ready time when still cooling down."""
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT used_at FROM act_cooldowns WHERE guild_id = ? AND user_id = ? "
                "AND kind = ?", (guild_id, user_id, kind)
            ) as cur:
                row = await cur.fetchone()
            if row and row["used_at"]:
                try:
                    last = datetime.fromisoformat(row["used_at"])
                except ValueError:
                    last = None
                if last and _now() < last + window:
                    return last + window
            await db.execute(
                "INSERT INTO act_cooldowns (guild_id, user_id, kind, used_at) "
                "VALUES (?, ?, ?, ?) ON CONFLICT(guild_id, user_id, kind) "
                "DO UPDATE SET used_at = excluded.used_at",
                (guild_id, user_id, kind, _now().isoformat()))
            await db.commit()
        finally:
            await db.close()
        return None

    async def _add_item(self, guild_id: int, user_id: int, item: str, amount: int = 1):
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO act_inventory (guild_id, user_id, item, amount) "
                "VALUES (?, ?, ?, ?) ON CONFLICT(guild_id, user_id, item) "
                "DO UPDATE SET amount = amount + ?",
                (guild_id, user_id, item, amount, amount))
            await db.commit()
        finally:
            await db.close()

    def _roll(self, table, paid: bool):
        pool = []
        for item, price, weight, premium_only in table:
            if premium_only and not paid:
                weight = max(0, weight - 2)
            pool.append((item, price, max(weight, 1)))
        total = sum(weight for _i, _p, weight in pool)
        pick = random.uniform(0, total)
        upto = 0
        for item, price, weight in pool:
            upto += weight
            if pick <= upto:
                return item, price
        item, price, _weight = pool[-1]
        return item, price

    # ── fishing / digging ────────────────────────────────────────────
    @commands.command(name="fish", aliases=["fishing"],
                      help="Go fishing for sellable loot (30 min cooldown).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def fish(self, ctx):
        ready = await self._cooldown(ctx.guild.id, ctx.author.id, "fish", FISH_COOLDOWN)
        if ready:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Resting",
                f"The fish need time — cast again <t:{int(ready.timestamp())}:R>."))
        paid = await premium.is_paid(ctx.guild.id)
        item, price = self._roll(FISH_LOOT, paid)
        await self._add_item(ctx.guild.id, ctx.author.id, item)
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Catch!",
            f"You pulled out **{item}** (worth ~{money(price)} coins).\n"
            f"Sell it with `{ctx.clean_prefix}sell {item}`."), mention_author=False)

    @commands.command(name="dig", aliases=["digging"],
                      help="Dig for ore and gems (20 min cooldown).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def dig(self, ctx):
        ready = await self._cooldown(ctx.guild.id, ctx.author.id, "dig", DIG_COOLDOWN)
        if ready:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Tired Arms",
                f"You can dig again <t:{int(ready.timestamp())}:R>."))
        paid = await premium.is_paid(ctx.guild.id)
        item, price = self._roll(DIG_LOOT, paid)
        await self._add_item(ctx.guild.id, ctx.author.id, item)
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Dug Up",
            f"You found **{item}** (worth ~{money(price)} coins).\n"
            f"Sell it with `{ctx.clean_prefix}sell {item}`."), mention_author=False)

    @commands.command(name="bag", aliases=["actinv", "loot"],
                      help="Show the loot you collected.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def bag(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT item, amount FROM act_inventory WHERE guild_id = ? AND user_id = ? "
                "AND amount > 0 ORDER BY item", (ctx.guild.id, member.id)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Empty Bag",
                f"Nothing collected yet. Try `{ctx.clean_prefix}fish`."))
        lines = [f"**{row['item']}** × {int(row['amount'])} "
                 f"(~{money(_price(row['item']))} each)" for row in rows]
        embed = self.embed(f"{MONEY} {member.display_name}'s Loot", "\n".join(lines))
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="sell", aliases=["sellloot"],
                      help="Sell loot from your bag for coins.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def sell(self, ctx, *, item: str = None):
        if not item:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}sell trout` or `{ctx.clean_prefix}sell all`."))
        key = item.strip().lower()
        db = await self._connect()
        try:
            if key == "all":
                async with db.execute(
                    "SELECT item, amount FROM act_inventory "
                    "WHERE guild_id = ? AND user_id = ? AND amount > 0",
                    (ctx.guild.id, ctx.author.id)
                ) as cur:
                    rows = await cur.fetchall()
                if not rows:
                    return await ctx.reply(embed=self.embed(
                        f"{INFO} Nothing To Sell", "Your bag is empty."))
                total = sum(_price(row["item"]) * int(row["amount"]) for row in rows)
                await db.execute(
                    "DELETE FROM act_inventory WHERE guild_id = ? AND user_id = ?",
                    (ctx.guild.id, ctx.author.id))
                await db.commit()
                await self.add_coins(ctx.guild.id, ctx.author.id, total)
                return await ctx.reply(embed=self.embed(
                    f"{TICK} Sold Everything",
                    f"You sold **{len(rows)}** item stacks for **{money(total)} coins**."),
                    mention_author=False)
            async with db.execute(
                "SELECT amount FROM act_inventory WHERE guild_id = ? AND user_id = ? "
                "AND LOWER(item) = ?", (ctx.guild.id, ctx.author.id, key)
            ) as cur:
                row = await cur.fetchone()
            if not row or int(row["amount"]) < 1:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not In Bag", f"You have no **{key}** to sell."))
            price = _price(key)
            count = int(row["amount"])
            await db.execute(
                "DELETE FROM act_inventory WHERE guild_id = ? AND user_id = ? AND item = ?",
                (ctx.guild.id, ctx.author.id, key))
            await db.commit()
        finally:
            await db.close()
        total = price * count
        await self.add_coins(ctx.guild.id, ctx.author.id, total)
        await ctx.reply(embed=self.embed(
            f"{TICK} Sold",
            f"**{key}** × {count} → **{money(total)} coins**."), mention_author=False)

    # ── lottery ──────────────────────────────────────────────────────
    async def _lottery_state(self, guild_id: int):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM lottery_state WHERE guild_id = ?", (guild_id,)
            ) as cur:
                row = await cur.fetchone()
            if row is None:
                ends = _now() + LOTTERY_LENGTH
                await db.execute(
                    "INSERT INTO lottery_state (guild_id, round, jackpot, ends_at) "
                    "VALUES (?, 1, 0, ?)", (guild_id, ends.isoformat()))
                await db.commit()
                async with db.execute(
                    "SELECT * FROM lottery_state WHERE guild_id = ?", (guild_id,)
                ) as cur:
                    row = await cur.fetchone()
            return row
        finally:
            await db.close()

    @commands.group(name="lottery", aliases=["lotto"], invoke_without_command=True,
                    help="Weekly coin lottery — buy tickets to enter.")
    @commands.guild_only()
    async def lottery(self, ctx):
        state = await self._lottery_state(ctx.guild.id)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT SUM(tickets) FROM lottery_tickets WHERE guild_id = ? AND round = ?",
                (ctx.guild.id, int(state["round"]))
            ) as cur:
                sold = int((await cur.fetchone())[0] or 0)
            async with db.execute(
                "SELECT tickets FROM lottery_tickets WHERE guild_id = ? AND user_id = ? "
                "AND round = ?", (ctx.guild.id, ctx.author.id, int(state["round"]))
            ) as cur:
                mine = await cur.fetchone()
        finally:
            await db.close()
        try:
            ends = int(datetime.fromisoformat(state["ends_at"]).timestamp())
        except (TypeError, ValueError):
            ends = 0
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{MONEY} Lottery · Round {int(state['round'])}",
            f"**Jackpot:** {money(state['jackpot'])} coins\n"
            f"**Tickets sold:** {sold}\n"
            f"**Your tickets:** {int(mine['tickets']) if mine else 0}\n"
            f"**Draw:** <t:{ends}:R>\n\n"
            f"`{p}lottery buy [tickets]` — {money(LOTTERY_TICKET)} coins each.\n"
            f"One ticket = one chance; if nobody bought tickets the jackpot rolls over."),
            mention_author=False)

    @lottery.command(name="channel", aliases=["announce"],
                     help="Set the channel for lottery results (staff).")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def lottery_channel(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        await self._lottery_state(ctx.guild.id)
        db = await self._connect()
        try:
            await db.execute(
                "UPDATE lottery_state SET channel_id = ? WHERE guild_id = ?",
                (channel.id, ctx.guild.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Lottery Channel Set",
            f"Winners and rollovers will be announced in {channel.mention}."),
            mention_author=False)

    @lottery.command(name="buy", aliases=["ticket", "enter"])
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def lottery_buy(self, ctx, tickets: int = 1):
        if tickets < 1 or tickets > 50:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Amount", "Buy between **1** and **50** tickets."))
        cost = tickets * LOTTERY_TICKET
        if not await self.take_coins(ctx.guild.id, ctx.author.id, cost):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Enough Cash",
                f"{tickets} ticket(s) cost **{money(cost)} coins**."))
        state = await self._lottery_state(ctx.guild.id)
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO lottery_tickets (guild_id, user_id, round, tickets) "
                "VALUES (?, ?, ?, ?) ON CONFLICT(guild_id, user_id, round) "
                "DO UPDATE SET tickets = tickets + ?",
                (ctx.guild.id, ctx.author.id, int(state["round"]), tickets, tickets))
            await db.execute(
                "UPDATE lottery_state SET jackpot = jackpot + ? WHERE guild_id = ?",
                (cost, ctx.guild.id))
            await db.commit()
            async with db.execute(
                "SELECT jackpot FROM lottery_state WHERE guild_id = ?", (ctx.guild.id,)
            ) as cur:
                jackpot = int((await cur.fetchone())["jackpot"])
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Tickets Bought",
            f"You bought **{tickets}** ticket(s) for **{money(cost)} coins**.\n"
            f"Jackpot is now **{money(jackpot)}** coins. Good luck!"), mention_author=False)

    @tasks.loop(minutes=5)
    async def lottery_watch(self):
        await self.bot.wait_until_ready()
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM lottery_state WHERE ends_at IS NOT NULL AND ends_at <= ?",
                (_now().isoformat(),)
            ) as cur:
                states = await cur.fetchall()
        finally:
            await db.close()
        for state in states:
            await self._draw(state)

    async def _draw(self, state):
        guild_id = int(state["guild_id"])
        round_no = int(state["round"])
        jackpot = int(state["jackpot"])
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT user_id, tickets FROM lottery_tickets "
                "WHERE guild_id = ? AND round = ? AND tickets > 0",
                (guild_id, round_no)
            ) as cur:
                rows = await cur.fetchall()
            entries = [(int(r["user_id"]), int(r["tickets"])) for r in rows]
            winner = None
            if entries:
                total = sum(t for _u, t in entries)
                pick = random.uniform(0, total)
                upto = 0
                for user_id, tickets in entries:
                    upto += tickets
                    if pick <= upto:
                        winner = user_id
                        break
            new_round = round_no + 1
            new_jackpot = 0 if winner else jackpot
            await db.execute(
                "UPDATE lottery_state SET round = ?, jackpot = ?, ends_at = ? "
                "WHERE guild_id = ?",
                (new_round, new_jackpot, (_now() + LOTTERY_LENGTH).isoformat(), guild_id))
            await db.commit()
        finally:
            await db.close()
        channel = None
        guild = self.bot.get_guild(guild_id)
        if guild and state["channel_id"]:
            channel = guild.get_channel(int(state["channel_id"]))
        if winner:
            await self.add_coins(guild_id, winner, jackpot)
            if channel:
                try:
                    await channel.send(embed=self.embed(
                        f"{TICK} Lottery Winner",
                        f"<@{winner}> won **{money(jackpot)} coins** in round {round_no}!"))
                except discord.HTTPException:
                    pass
        else:
            if channel:
                try:
                    await channel.send(embed=self.embed(
                        f"{INFO} Lottery Rolled Over",
                        f"Nobody entered round {round_no}, so the jackpot "
                        f"({money(jackpot)} coins) carried over."))
                except discord.HTTPException:
                    pass

    # ── heist ────────────────────────────────────────────────────────
    @commands.command(name="heist", aliases=["crew"],
                      help="Start a group heist — 2 to 5 members needed.")
    @commands.guild_only()
    @commands.cooldown(1, 300, commands.BucketType.channel)
    async def heist(self, ctx):
        if not await self.take_coins(ctx.guild.id, ctx.author.id, HEIST_ENTRY):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Need Entry Fee",
                f"A heist costs **{money(HEIST_ENTRY)} coins** in cash to join."))
        view = HeistView(self, ctx.guild.id, ctx.author.id)
        message = await ctx.reply(
            embed=self.embed(
                f"{WARNING} Heist Starting",
                f"{ctx.author.mention} is planning a heist!\n"
                f"Entry: **{money(HEIST_ENTRY)} coins** · Crew max 5\n"
                f"Press **Join Heist** within {HEIST_WINDOW} seconds."),
            view=view, mention_author=False)
        await asyncio.sleep(HEIST_WINDOW + 1)
        view.stop()
        players = view.players
        for child in view.children:
            child.disabled = True
        if len(players) < 2:
            await self.add_coins(ctx.guild.id, ctx.author.id, HEIST_ENTRY)
            try:
                await message.edit(embed=self.embed(
                    f"{CROSS} Heist Aborted",
                    "Not enough crew members joined, so your entry fee was refunded."),
                    view=view)
            except discord.HTTPException:
                pass
            return
        paid = await premium.is_paid(ctx.guild.id)
        chance = min(0.85, 0.45 + 0.07 * len(players) + (0.05 if paid else 0))
        pot = HEIST_ENTRY * len(players)
        if random.random() < chance:
            loot = int(pot * random.uniform(1.5, 2.6))
            share = loot // len(players)
            for user_id in players:
                await self.add_coins(ctx.guild.id, user_id, share)
            result = (f"{TICK} Heist Successful",
                      f"The crew escaped with **{money(loot)} coins**!\n"
                      f"Each member got **{money(share)} coins**.")
        else:
            result = (f"{CROSS} Heist Failed",
                      "The alarm tripped and everybody lost their entry fee.")
        try:
            await message.edit(embed=self.embed(*result), view=view)
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(Activities(bot))
