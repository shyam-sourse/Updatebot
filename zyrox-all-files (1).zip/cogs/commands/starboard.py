# ╔══════════════════════════════════════════════════════════════════╗
# ║   Starboard  ──  highlight the best messages with reactions        ║
# ║   starboard setup • threshold • emoji • toggle • status            ║
# ╚══════════════════════════════════════════════════════════════════╝
"""A classic starboard: messages that reach a reaction threshold get posted
to a highlights channel, and the count updates as reactions change.

Free servers get one board with the ⭐ emoji and a fixed threshold of 3.
Premium unlocks a custom threshold, a custom emoji and bot/self-star rules.
"""

from __future__ import annotations

import os

import aiosqlite
import discord
from discord.ext import commands

from utils import premium
from utils.emoji import CROSS, INFO, SPARKLE, STAR, TICK, WARNING

DB = "db/starboard.db"
COLOR = 0xFFD700
DEFAULT_EMOJI = "⭐"

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS boards (
        guild_id INTEGER PRIMARY KEY,
        channel_id INTEGER,
        emoji TEXT DEFAULT '⭐',
        threshold INTEGER NOT NULL DEFAULT 3,
        enabled INTEGER NOT NULL DEFAULT 1,
        self_star INTEGER NOT NULL DEFAULT 0,
        bots INTEGER NOT NULL DEFAULT 0
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS posts (
        guild_id INTEGER NOT NULL,
        message_id INTEGER NOT NULL,
        board_message_id INTEGER,
        channel_id INTEGER,
        author_id INTEGER,
        stars INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, message_id)
    )
    """,
)


class Starboard(commands.Cog):
    """Turn popular messages into a highlights feed."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (STAR, "Starboard", "Highlight the most reacted messages in a channel.")

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _board(self, guild_id: int):
        await self._ensure()
        db = await self._connect()
        try:
            async with db.execute("SELECT * FROM boards WHERE guild_id = ?", (guild_id,)) as cur:
                return await cur.fetchone()
        finally:
            await db.close()

    async def _paid(self, ctx) -> bool:
        plan = await premium.get_plan_key(ctx.guild.id)
        if plan != premium.FREE:
            return True
        await ctx.reply(embed=self.embed(
            f"{CROSS} Premium Feature",
            f"Custom starboard settings are **Premium**.\n"
            f"Free servers keep the ⭐ emoji with a threshold of **3**.\n"
            f"Run `{ctx.clean_prefix}premium` to upgrade."), mention_author=False)
        return False

    # ── listeners ────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        await self._update(payload)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        await self._update(payload)

    async def _count_stars(self, message, board) -> int:
        for reaction in message.reactions:
            if str(reaction.emoji) != (board["emoji"] or DEFAULT_EMOJI):
                continue
            try:
                users = [user async for user in reaction.users()]
            except discord.HTTPException:
                return 0
            count = 0
            for user in users:
                if user.id == message.author.id and not board["self_star"]:
                    continue
                if user.bot and not board["bots"]:
                    continue
                count += 1
            return count
        return 0

    def _build(self, message, stars, emoji):
        content = (message.content or "").strip()[:1500]
        description = (content + "\n\n" if content else "") + f"[Jump to message]({message.jump_url})"
        embed = discord.Embed(description=description, color=COLOR, timestamp=message.created_at)
        embed.set_author(name=message.author.display_name,
                         icon_url=message.author.display_avatar.url)
        for attachment in message.attachments:
            content_type = attachment.content_type or ""
            if content_type.startswith("image"):
                embed.set_image(url=attachment.url)
                break
        embed.set_footer(text=f"{emoji} {stars} · #{getattr(message.channel, 'name', 'channel')}")
        return embed

    async def _update(self, payload: discord.RawReactionActionEvent):
        if payload.guild_id is None:
            return
        board = await self._board(payload.guild_id)
        if not board or not board["enabled"] or not board["channel_id"]:
            return
        emoji = board["emoji"] or DEFAULT_EMOJI
        if str(payload.emoji) != emoji:
            return
        if payload.channel_id == int(board["channel_id"]):
            return
        source = self.bot.get_channel(payload.channel_id)
        target = self.bot.get_channel(int(board["channel_id"]))
        if source is None or target is None:
            return
        try:
            message = await source.fetch_message(payload.message_id)
        except discord.HTTPException:
            return
        if message.author.bot and not board["bots"]:
            return
        if message.author.id == payload.user_id and not board["self_star"]:
            return

        stars = await self._count_stars(message, board)
        threshold = max(1, int(board["threshold"] or 3))

        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM posts WHERE guild_id = ? AND message_id = ?",
                (payload.guild_id, payload.message_id)
            ) as cur:
                post = await cur.fetchone()

            if stars < threshold:
                if post and post["board_message_id"]:
                    try:
                        old = await target.fetch_message(int(post["board_message_id"]))
                        await old.delete()
                    except discord.HTTPException:
                        pass
                    await db.execute(
                        "DELETE FROM posts WHERE guild_id = ? AND message_id = ?",
                        (payload.guild_id, payload.message_id))
                    await db.commit()
                return

            embed = self._build(message, stars, emoji)
            if post and post["board_message_id"]:
                try:
                    old = await target.fetch_message(int(post["board_message_id"]))
                    await old.edit(embed=embed)
                    await db.execute(
                        "UPDATE posts SET stars = ? WHERE guild_id = ? AND message_id = ?",
                        (stars, payload.guild_id, payload.message_id))
                    await db.commit()
                    return
                except discord.HTTPException:
                    pass

            sent = await target.send(embed=embed)
            await db.execute(
                "INSERT INTO posts (guild_id, message_id, board_message_id, channel_id, "
                "author_id, stars) VALUES (?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(guild_id, message_id) DO UPDATE SET "
                "board_message_id = excluded.board_message_id, stars = excluded.stars",
                (payload.guild_id, payload.message_id, sent.id, payload.channel_id,
                 message.author.id, stars))
            await db.commit()
        finally:
            await db.close()

    # ── commands ─────────────────────────────────────────────────────
    @commands.group(name="starboard", aliases=["starrow", "sboard"],
                    invoke_without_command=True, help="Set up the starboard.")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def starboard(self, ctx):
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{STAR} Starboard",
            f"`{p}starboard setup #channel` — turn it on\n"
            f"`{p}starboard toggle` — on / off\n"
            f"`{p}starboard threshold 3` — reactions needed (premium)\n"
            f"`{p}starboard emoji ⭐` — reaction emoji (premium)\n"
            f"`{p}starboard status` — current settings"), mention_author=False)

    @starboard.command(name="setup")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    @commands.bot_has_permissions(send_messages=True, embed_links=True)
    async def starboard_setup(self, ctx, channel: discord.TextChannel = None,
                              threshold: int = None):
        if channel is None:
            current = await self._board(ctx.guild.id)
            channel = self.bot.get_channel(int(current["channel_id"])) if current and current["channel_id"] else None
            if channel is None:
                return await ctx.reply(embed=self.embed(
                    f"{INFO} Usage", f"`{ctx.clean_prefix}starboard setup #highlights`"))
        plan = await premium.get_plan_key(ctx.guild.id)
        if threshold is None:
            threshold = 3
        minimum = 3
        if plan != premium.FREE:
            minimum = await premium.limit_for(ctx.guild.id, "starboard_threshold") or 1
        if threshold < minimum:
            if plan == premium.FREE:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Free Threshold Is 3",
                    f"Free servers use a threshold of **3**. Custom thresholds are "
                    f"**Premium** — run `{ctx.clean_prefix}premium`."), mention_author=False)
            threshold = minimum
        if threshold > 25:
            threshold = 25
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO boards (guild_id, channel_id, emoji, threshold, enabled) "
                "VALUES (?, ?, ?, ?, 1) ON CONFLICT(guild_id) DO UPDATE SET "
                "channel_id = excluded.channel_id, threshold = excluded.threshold, "
                "enabled = 1",
                (ctx.guild.id, channel.id, DEFAULT_EMOJI, threshold))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Starboard Enabled",
            f"Popular messages will be posted in {channel.mention}.\n"
            f"**Threshold:** {threshold} reactions"), mention_author=False)

    @starboard.command(name="threshold")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def starboard_threshold(self, ctx, value: int = None):
        if not await self._paid(ctx):
            return
        if value is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}starboard threshold 3`"))
        minimum = await premium.limit_for(ctx.guild.id, "starboard_threshold") or 1
        value = max(int(minimum), min(value, 25))
        db = await self._connect()
        try:
            cur = await db.execute(
                "UPDATE boards SET threshold = ? WHERE guild_id = ?", (value, ctx.guild.id))
            await db.commit()
            if not cur.rowcount:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Set Up",
                    f"Run `{ctx.clean_prefix}starboard setup #channel` first."))
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Threshold Updated", f"Messages now need **{value}** reactions."),
            mention_author=False)

    @starboard.command(name="emoji")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def starboard_emoji(self, ctx, emoji: str = None):
        if not await self._paid(ctx):
            return
        if not emoji:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}starboard emoji ⭐`"))
        emoji = emoji.strip()[:80]
        db = await self._connect()
        try:
            cur = await db.execute(
                "UPDATE boards SET emoji = ? WHERE guild_id = ?", (emoji, ctx.guild.id))
            await db.commit()
            if not cur.rowcount:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Set Up",
                    f"Run `{ctx.clean_prefix}starboard setup #channel` first."))
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Emoji Updated", f"Using {emoji} for the starboard."), mention_author=False)

    @starboard.command(name="toggle")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def starboard_toggle(self, ctx):
        board = await self._board(ctx.guild.id)
        if not board:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Set Up",
                f"Run `{ctx.clean_prefix}starboard setup #channel` first."))
        new_state = 0 if board["enabled"] else 1
        db = await self._connect()
        try:
            await db.execute(
                "UPDATE boards SET enabled = ? WHERE guild_id = ?", (new_state, ctx.guild.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Starboard {'Enabled' if new_state else 'Disabled'}",
            "Reactions will be tracked again." if new_state else "Reactions are ignored now."),
            mention_author=False)

    @starboard.command(name="status")
    @commands.guild_only()
    async def starboard_status(self, ctx):
        board = await self._board(ctx.guild.id)
        if not board:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Configured",
                f"Run `{ctx.clean_prefix}starboard setup #channel` to enable it."))
        channel = self.bot.get_channel(int(board["channel_id"])) if board["channel_id"] else None
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) FROM posts WHERE guild_id = ?", (ctx.guild.id,)
            ) as cur:
                total = int((await cur.fetchone())[0])
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Starboard Status",
            f"**Channel:** {channel.mention if channel else '`deleted`'}\n"
            f"**Enabled:** {'yes' if board['enabled'] else 'no'}\n"
            f"**Emoji:** {board['emoji']}\n"
            f"**Threshold:** {int(board['threshold'])}\n"
            f"**Posts:** {total}"), mention_author=False)


async def setup(bot):
    await bot.add_cog(Starboard(bot))
