"""AI-analyzed moderation change log.

Every server picks one log channel with ``modlog set #channel``. Channel,
role, server, ban, kick, timeout and bot changes are posted there, and the
bot asks FreeLLMAPI for a short analysis (what changed, risk, next step).

Config lives in ``db/modchangelog.db``:

* ``modlog_config`` – guild_id → channel_id + ``ai_enabled`` flag
"""

from __future__ import annotations

import asyncio
import os
import time
from datetime import datetime, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils import ai_utils
from utils.config import BRAND_NAME, OWNER_IDS

DB_PATH = os.path.join("db", "modchangelog.db")

COLOR = 0xE67E22
GREEN = 0x2ECC71
GREY = 0x95A5A6

AI_SYSTEM = (
    "You are a Discord server security analyst. Given one server change, reply "
    "with at most 3 short bullet lines:\n"
    "• Summary: what changed, in one line\n"
    "• Risk: Low / Medium / High and one short reason\n"
    "• Next step: one concrete suggestion for the admins\n"
    "No preamble, no headings, no markdown bold."
)

AI_EVENTS = {
    "channel_delete",
    "role_delete",
    "ban",
    "kick",
    "unban",
    "timeout",
    "bot_add",
    "guild_update",
    "permissions",
}

AI_MIN_GAP = 8.0  # seconds between AI calls per guild


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


async def init_db() -> None:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS modlog_config (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER NOT NULL,
                ai_enabled INTEGER NOT NULL DEFAULT 1,
                updated_at TEXT
            )
            """
        )
        await db.commit()


async def get_config(guild_id: int) -> dict | None:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT guild_id, channel_id, ai_enabled FROM modlog_config WHERE guild_id = ?",
                (guild_id,),
            ) as cursor:
                row = await cursor.fetchone()
    except aiosqlite.Error:
        return None
    return dict(row) if row else None


async def set_config(guild_id: int, channel_id: int, ai_enabled: bool = True) -> None:
    await init_db()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO modlog_config (guild_id, channel_id, ai_enabled, updated_at) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET "
            "channel_id = excluded.channel_id, ai_enabled = excluded.ai_enabled, "
            "updated_at = excluded.updated_at",
            (guild_id, channel_id, 1 if ai_enabled else 0, _utcnow().isoformat()),
        )
        await db.commit()


async def set_ai(guild_id: int, enabled: bool) -> bool:
    await init_db()
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "UPDATE modlog_config SET ai_enabled = ?, updated_at = ? WHERE guild_id = ?",
            (1 if enabled else 0, _utcnow().isoformat(), guild_id),
        )
        await db.commit()
        return cursor.rowcount > 0


async def clear_config(guild_id: int) -> bool:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("DELETE FROM modlog_config WHERE guild_id = ?", (guild_id,))
            await db.commit()
            return cursor.rowcount > 0
    except aiosqlite.Error:
        return False


def is_staff(member: discord.Member | None) -> bool:
    if member is None:
        return False
    if member.id in OWNER_IDS:
        return True
    perms = getattr(member, "guild_permissions", None)
    return bool(perms is not None and (perms.administrator or perms.manage_guild))


async def _reply(ctx, message: str | None = None, ephemeral: bool = False, embed=None):
    kwargs: dict = {}
    if message is not None:
        kwargs["content"] = message
    if embed is not None:
        kwargs["embed"] = embed
    if ctx.interaction is not None:
        kwargs["ephemeral"] = ephemeral
        if ctx.interaction.response.is_done():
            return await ctx.interaction.followup.send(**kwargs)
        return await ctx.interaction.response.send_message(**kwargs)
    return await ctx.send(**kwargs)


async def find_audit(
    guild: discord.Guild,
    action: discord.AuditLogAction,
    target_id: int | None = None,
    max_age: int = 25,
):
    """Newest audit entry for this action/target, or None."""
    try:
        async for entry in guild.audit_logs(limit=6, action=action):
            if target_id is not None and getattr(entry.target, "id", None) != target_id:
                continue
            if entry.created_at is not None:
                age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if age > max_age:
                    return None
            return entry
    except (discord.Forbidden, discord.HTTPException):
        return None
    except Exception:
        return None
    return None


def _actor_line(entry, fallback: str = "Unknown (audit log unavailable)") -> str:
    if entry is None:
        return f"**By:** {fallback}"
    user = entry.user
    name = f"{user.mention} (`{user.id}`)" if user is not None else "Unknown"
    line = f"**By:** {name}"
    if entry.reason:
        line += f"\n**Reason:** {entry.reason[:300]}"
    return line


def _changes(pairs: list[tuple[str, object, object]]) -> list[str]:
    lines = []
    for label, before, after in pairs:
        if before == after:
            continue
        lines.append(f"**{label}:** `{before}` → `{after}`")
    return lines


class ModChangeLog(commands.Cog, name="ModChangeLog"):
    def __init__(self, bot):
        self.bot = bot
        self._ai_last: dict[int, float] = {}
        bot.loop.create_task(init_db())

    def help_custom(self):
        return "🛡️", "Mod Change Log", "AI-analyzed channel, role and mod changes"

    # ── core posting ────────────────────────────────────────────────────────
    async def _analyze(self, guild: discord.Guild, kind: str, facts: list[str]) -> str | None:
        if kind not in AI_EVENTS:
            return None
        if not ai_utils.is_configured():
            return "AI analysis unavailable — FREELLM_API_KEY is not set."
        last = self._ai_last.get(guild.id, 0.0)
        if time.monotonic() - last < AI_MIN_GAP:
            return "AI analysis skipped (too many changes at once)."
        self._ai_last[guild.id] = time.monotonic()
        prompt = (
            f"Server: {guild.name} (id {guild.id})\n"
            f"Change type: {kind}\n"
            + "\n".join(facts)
        )
        try:
            text = await asyncio.wait_for(
                ai_utils.ask_ai(prompt, system=AI_SYSTEM, max_tokens=220),
                timeout=25,
            )
        except Exception:
            return "AI analysis failed for this event."
        text = (text or "").strip()
        return text[:1000] or None

    async def _post(
        self,
        guild: discord.Guild,
        title: str,
        lines: list[str],
        kind: str,
        facts: list[str] | None = None,
        force: bool = False,
    ) -> bool:
        config = await get_config(guild.id)
        if config is None and not force:
            return False
        channel_id = config["channel_id"] if config else 0
        channel = guild.get_channel(channel_id) if channel_id else None
        if channel is None:
            return False

        analysis = None
        ai_enabled = bool(config["ai_enabled"]) if config else True
        if ai_enabled:
            analysis = await self._analyze(guild, kind, facts or lines)

        embed = discord.Embed(
            title=title,
            description="\n".join(lines)[:3500],
            color=COLOR,
            timestamp=discord.utils.utcnow(),
        )
        if analysis:
            embed.add_field(name="🤖 AI Analysis", value=analysis[:1020], inline=False)
        embed.set_footer(text=f"{BRAND_NAME} · Mod Change Log")
        try:
            await channel.send(embed=embed)
            return True
        except (discord.Forbidden, discord.HTTPException):
            return False

    # ── channel events ──────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        entry = await find_audit(guild, discord.AuditLogAction.channel_create, channel.id)
        lines = [
            f"**Channel:** {channel.mention} (`{channel.id}`)",
            f"**Type:** {str(channel.type).replace('_', ' ').title()}",
        ]
        if getattr(channel, "category", None):
            lines.append(f"**Category:** {channel.category.name}")
        lines.append(_actor_line(entry))
        await self._post(
            guild, "📁 Channel Created", lines, "channel_create",
            facts=[f"Channel created: #{channel.name} ({channel.type})"],
        )

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        entry = await find_audit(guild, discord.AuditLogAction.channel_delete, channel.id)
        lines = [
            f"**Channel:** `#{channel.name}` (`{channel.id}`)",
            f"**Type:** {str(channel.type).replace('_', ' ').title()}",
        ]
        if getattr(channel, "category", None):
            lines.append(f"**Category:** {channel.category.name}")
        lines.append(_actor_line(entry))
        await self._post(
            guild, "🗑️ Channel Deleted", lines, "channel_delete",
            facts=[f"Channel deleted: #{channel.name} (type {channel.type})"],
        )
        config = await get_config(guild.id)
        if config and config["channel_id"] == channel.id:
            await clear_config(guild.id)

    @commands.Cog.listener()
    async def on_guild_channel_update(
        self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel
    ):
        lines = _changes(
            [
                ("Name", before.name, after.name),
                ("Topic", getattr(before, "topic", None), getattr(after, "topic", None)),
                ("Slowmode", getattr(before, "slowmode_delay", None), getattr(after, "slowmode_delay", None)),
                ("NSFW", getattr(before, "nsfw", None), getattr(after, "nsfw", None)),
                (
                    "Category",
                    getattr(getattr(before, "category", None), "name", None),
                    getattr(getattr(after, "category", None), "name", None),
                ),
            ]
        )
        if not lines:
            return
        guild = after.guild
        entry = await find_audit(guild, discord.AuditLogAction.channel_update, after.id)
        body = [f"**Channel:** {after.mention} (`{after.id}`)", *lines, _actor_line(entry)]
        await self._post(
            guild, "✏️ Channel Updated", body, "channel_update",
            facts=[f"Channel #{after.name} updated: " + "; ".join(l.replace("**", "") for l in lines)],
        )

    # ── role events ─────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        guild = role.guild
        entry = await find_audit(guild, discord.AuditLogAction.role_create, role.id)
        lines = [
            f"**Role:** {role.mention} (`{role.id}`)",
            f"**Colour:** `{role.colour}`",
            f"**Administrator:** {'Yes' if role.permissions.administrator else 'No'}",
            _actor_line(entry),
        ]
        await self._post(
            guild, "🎭 Role Created", lines, "role_create",
            facts=[f"Role created: {role.name}"],
        )

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        guild = role.guild
        entry = await find_audit(guild, discord.AuditLogAction.role_delete, role.id)
        lines = [
            f"**Role:** `{role.name}` (`{role.id}`)",
            f"**Members had it:** {len(role.members)}",
            f"**Dangerous perms:** {'Yes' if (role.permissions.administrator or role.permissions.manage_guild) else 'No'}",
            _actor_line(entry),
        ]
        await self._post(
            guild, "🗑️ Role Deleted", lines, "role_delete",
            facts=[
                f"Role deleted: {role.name}; members affected: {len(role.members)}; "
                f"administrator={role.permissions.administrator}"
            ],
        )

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        changes = _changes(
            [
                ("Name", before.name, after.name),
                ("Colour", before.colour, after.colour),
                ("Hoist", before.hoist, after.hoist),
                ("Mentionable", before.mentionable, after.mentionable),
            ]
        )
        perms_changed = before.permissions != after.permissions
        if perms_changed:
            changes.append("**Permissions:** changed")
        if not changes:
            return
        guild = after.guild
        entry = await find_audit(guild, discord.AuditLogAction.role_update, after.id)
        body = [f"**Role:** {after.mention} (`{after.id}`)", *changes, _actor_line(entry)]
        await self._post(
            guild, "⚠️ Role Updated", body, "permissions" if perms_changed else "role_update",
            facts=[f"Role {after.name} updated: " + "; ".join(c.replace("**", "") for c in changes)],
        )

    # ── server changes ──────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild):
        changes = _changes(
            [
                ("Name", before.name, after.name),
                ("Verification", before.verification_level, after.verification_level),
                ("Content filter", before.explicit_content_filter, after.explicit_content_filter),
                ("Icon", "old" if before.icon else None, "new" if after.icon else None),
            ]
        )
        if not changes:
            return
        entry = await find_audit(after, discord.AuditLogAction.guild_update)
        body = [*changes, _actor_line(entry)]
        await self._post(
            after, "🏠 Server Updated", body, "guild_update",
            facts=["Server settings changed: " + "; ".join(c.replace("**", "") for c in changes)],
        )

    # ── member moderation ───────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User | discord.Member):
        entry = await find_audit(guild, discord.AuditLogAction.ban, user.id)
        lines = [
            f"**User:** {user.mention} (`{user.id}`)",
            f"**Account created:** {discord.utils.format_dt(user.created_at, 'D')}",
            f"**Joined:** {discord.utils.format_dt(user.joined_at, 'D') if getattr(user, 'joined_at', None) else 'Unknown'}",
            _actor_line(entry),
        ]
        await self._post(guild, "🔨 Member Banned", lines, "ban", facts=[f"User banned: {user} ({user.id})"])

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        entry = await find_audit(guild, discord.AuditLogAction.unban, user.id)
        lines = [f"**User:** {user.mention} (`{user.id}`)", _actor_line(entry)]
        await self._post(guild, "♻️ Member Unbanned", lines, "unban", facts=[f"User unbanned: {user} ({user.id})"])

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not member.bot:
            return
        entry = await find_audit(member.guild, discord.AuditLogAction.bot_add, member.id)
        lines = [
            f"**Bot:** {member.mention} (`{member.id}`)",
            f"**Created:** {discord.utils.format_dt(member.created_at, 'D')}",
            _actor_line(entry),
        ]
        await self._post(member.guild, "🤖 Bot Added", lines, "bot_add", facts=[f"Bot added: {member} ({member.id})"])

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if member.bot:
            return
        await asyncio.sleep(1)
        entry = await find_audit(member.guild, discord.AuditLogAction.kick, member.id)
        if entry is None:
            return  # normal leave, not a mod action
        lines = [
            f"**User:** {member.mention} (`{member.id}`)",
            f"**Joined:** {discord.utils.format_dt(member.joined_at, 'D') if member.joined_at else 'Unknown'}",
            _actor_line(entry),
        ]
        await self._post(member.guild, "👢 Member Kicked", lines, "kick", facts=[f"User kicked: {member} ({member.id})"])

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        guild = after.guild

        # Timeout added / removed
        if before.timed_out_until != after.timed_out_until:
            entry = await find_audit(guild, discord.AuditLogAction.member_update, after.id)
            if entry is not None and entry.user is not None and entry.user.id == self.bot.user.id:
                return
            if after.timed_out_until is None:
                title, kind = "🔊 Timeout Removed", "timeout"
                lines = [f"**User:** {after.mention} (`{after.id}`)"]
            else:
                title, kind = "🔇 Member Timed Out", "timeout"
                lines = [
                    f"**User:** {after.mention} (`{after.id}`)",
                    f"**Until:** {discord.utils.format_dt(after.timed_out_until, 'F')}",
                ]
            lines.append(_actor_line(entry))
            await self._post(guild, title, lines, kind, facts=[f"Timeout change for {after} ({after.id})"])
            return

        if before.roles == after.roles:
            return
        added = [role for role in after.roles if role not in before.roles]
        removed = [role for role in before.roles if role not in after.roles]
        entry = await find_audit(guild, discord.AuditLogAction.member_role_update, after.id)
        if entry is None:
            return
        if entry.user is not None and entry.user.id == self.bot.user.id:
            return  # autorole / level rewards / reaction roles
        lines = [f"**User:** {after.mention} (`{after.id}`)"]
        if added:
            lines.append("**Added:** " + ", ".join(role.mention for role in added))
        if removed:
            lines.append("**Removed:** " + ", ".join(role.mention for role in removed))
        dangerous = any(
            role.permissions.administrator or role.permissions.manage_guild for role in added
        )
        lines.append(_actor_line(entry))
        await self._post(
            guild,
            "🛡️ Member Roles Changed",
            lines,
            "permissions" if dangerous else "member_roles",
            facts=[
                f"Roles changed for {after} ({after.id}): "
                + "; ".join(
                    filter(
                        None,
                        [
                            "added " + ", ".join(r.name for r in added) if added else "",
                            "removed " + ", ".join(r.name for r in removed) if removed else "",
                        ],
                    )
                )
                + f"; dangerous role given: {dangerous}"
            ],
        )

    # ── commands ────────────────────────────────────────────────────────────
    @commands.hybrid_group(
        name="modlog",
        invoke_without_command=True,
        description="AI-analyzed moderation change log for this server.",
    )
    async def modlog(self, ctx):
        await ctx.send_help(ctx.command)

    @modlog.command(name="set", description="Choose the channel for mod change logs (admin).")
    async def set_channel(self, ctx, channel: discord.TextChannel, ai: bool = True):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can set the mod log channel.", ephemeral=True)
        await set_config(ctx.guild.id, channel.id, ai_enabled=ai)
        await _reply(
            ctx,
            f"✅ Mod change log channel set to {channel.mention}.\n"
            f"**AI analysis:** {'on' if ai else 'off'}",
            ephemeral=True,
        )

    @modlog.command(name="off", description="Stop mod change logging in this server.")
    async def off(self, ctx):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can change mod log settings.", ephemeral=True)
        removed = await clear_config(ctx.guild.id)
        await _reply(
            ctx,
            "🗑️ Mod change log turned off." if removed else "Mod change log was not enabled.",
            ephemeral=True,
        )

    @modlog.command(name="ai", description="Turn AI analysis on or off for mod logs.")
    async def ai_toggle(self, ctx, state: str):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can change mod log settings.", ephemeral=True)
        value = state.strip().lower()
        if value not in ("on", "off", "true", "false", "enable", "disable"):
            return await _reply(ctx, "Use `modlog ai on` or `modlog ai off`.", ephemeral=True)
        enabled = value in ("on", "true", "enable")
        if not await set_ai(ctx.guild.id, enabled):
            return await _reply(ctx, "Set a channel first with `modlog set #channel`.", ephemeral=True)
        await _reply(ctx, f"🤖 AI analysis is now **{'on' if enabled else 'off'}**.", ephemeral=True)

    @modlog.command(name="status", description="Show the current mod log settings.")
    async def status(self, ctx):
        config = await get_config(ctx.guild.id)
        if not config:
            return await _reply(
                ctx,
                "Mod change log is **off**. Enable it with `modlog set #channel`.",
                ephemeral=True,
            )
        channel = ctx.guild.get_channel(config["channel_id"])
        embed = discord.Embed(
            title="🛡️ Mod Change Log",
            description=(
                f"**Channel:** {channel.mention if channel else 'missing (deleted?)'}\n"
                f"**AI analysis:** {'on' if config['ai_enabled'] else 'off'}\n"
                f"**AI backend:** {'ready' if ai_utils.is_configured() else 'not configured'}"
            ),
            color=GREEN if channel else GREY,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text=f"{BRAND_NAME} · Mod Change Log")
        await _reply(ctx, embed=embed, ephemeral=True)

    @modlog.command(name="test", description="Send a sample AI-analyzed entry to the log channel.")
    async def test(self, ctx):
        if not is_staff(ctx.author):
            return await _reply(ctx, "Only admins can test the mod log.", ephemeral=True)
        config = await get_config(ctx.guild.id)
        if not config:
            return await _reply(ctx, "Set a channel first with `modlog set #channel`.", ephemeral=True)
        await _reply(ctx, "🧪 Sending a test entry…", ephemeral=True)
        sent = await self._post(
            ctx.guild,
            "🧪 Test Entry",
            [
                f"**Event:** this is a test mod change log entry",
                f"**Requested by:** {ctx.author.mention}",
                _actor_line(None, fallback=str(ctx.author)),
            ],
            "channel_delete",
            facts=["Test entry requested by an admin; a channel '#example' was deleted."],
            force=True,
        )
        if not sent:
            await ctx.send("❌ Could not post to the configured channel. Check my permissions.")


async def setup(bot):
    await bot.add_cog(ModChangeLog(bot))
