# ╔══════════════════════════════════════════════════════════════════╗
# ║   ModMail  ──  members DM the bot, staff answer in threads         ║
# ║   modmail setup • modmail close • modmail list • modmail disable    ║
# ╚══════════════════════════════════════════════════════════════════╝
"""DM based modmail: a member DMs the bot and a private thread opens for staff.

Staff reply by typing in the thread; the reply is forwarded to the member's DMs.
"""

from __future__ import annotations

import io
import os
from datetime import datetime, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils.emoji import CROSS, INFO, MESSAGE, TICK

DB = "db/modmail.db"
COLOR = 0xFF0000


def _now() -> datetime:
    return datetime.now(timezone.utc)


SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS modmail_config (
        guild_id INTEGER PRIMARY KEY,
        channel_id INTEGER NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS modmail_threads (
        thread_id INTEGER PRIMARY KEY,
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'open',
        created_at TEXT
    )
    """,
)


class ModMail(commands.Cog):
    """DM modmail with private staff threads."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (MESSAGE, "ModMail", "Members DM the bot and staff reply in threads.")

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description, colour=None):
        return discord.Embed(title=title, description=description, color=colour or COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _config(self, guild_id: int):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM modmail_config WHERE guild_id = ?", (guild_id,)
            ) as cur:
                return await cur.fetchone()
        finally:
            await db.close()

    async def _thread_for(self, thread_id: int):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM modmail_threads WHERE thread_id = ?", (thread_id,)
            ) as cur:
                return await cur.fetchone()
        finally:
            await db.close()

    async def _config_for_user(self, user_id: int):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM modmail_config WHERE enabled = 1 ORDER BY guild_id"
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return None
        for row in rows:
            guild = self.bot.get_guild(int(row["guild_id"]))
            if guild and guild.get_member(user_id):
                return row
        return rows[0]

    # ── relaying ─────────────────────────────────────────────────────
    def _format(self, message: discord.Message) -> tuple[discord.Embed, list[discord.File]]:
        body = message.content or "(no text)"
        embed = discord.Embed(description=body[:3900], color=COLOR, timestamp=_now())
        if message.attachments:
            links = [f"[{a.filename}]({a.url})" for a in message.attachments]
            embed.add_field(name="Attachments", value="\n".join(links)[:1000], inline=False)
        return embed, []

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return
        # member → bot (DM)
        if message.guild is None:
            await self._handle_dm(message)
            return
        # staff → member (inside a modmail thread)
        if isinstance(message.channel, discord.Thread):
            await self._handle_staff_reply(message)

    async def _handle_dm(self, message: discord.Message):
        row = await self._config_for_user(message.author.id)
        if row is None:
            return
        guild = self.bot.get_guild(int(row["guild_id"]))
        channel = guild.get_channel(int(row["channel_id"])) if guild else None
        if channel is None:
            return
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM modmail_threads WHERE guild_id = ? AND user_id = ? "
                "AND status = 'open' ORDER BY created_at DESC LIMIT 1",
                (int(row["guild_id"]), message.author.id)
            ) as cur:
                existing = await cur.fetchone()
        finally:
            await db.close()
        embed, files = self._format(message)
        if existing is not None:
            thread = guild.get_thread(int(existing["thread_id"]))
            if thread is not None:
                embed.set_author(name=message.author.display_name,
                                 icon_url=message.author.display_avatar.url)
                try:
                    await thread.send(embed=embed)
                    await message.add_reaction("📨")
                    return
                except discord.HTTPException:
                    pass
        try:
            thread = await channel.create_thread(
                name=f"mail-{message.author.name}"[:95],
                type=discord.ChannelType.public_thread,
                auto_archive_duration=1440,
                reason=f"Modmail from {message.author}")
        except discord.HTTPException:
            try:
                await message.author.send(embed=self.embed(
                    f"{CROSS} Modmail Unavailable",
                    "Staff cannot open a mail thread right now. Try again later."))
            except discord.HTTPException:
                pass
            return
        db = await self._connect()
        try:
            await db.execute(
                "INSERT OR REPLACE INTO modmail_threads "
                "(thread_id, guild_id, user_id, channel_id, status, created_at) "
                "VALUES (?, ?, ?, ?, 'open', ?)",
                (thread.id, int(row["guild_id"]), message.author.id, channel.id,
                 _now().isoformat()))
            await db.commit()
        finally:
            await db.close()
        embed.set_author(name=f"{message.author} · {message.author.id}",
                         icon_url=message.author.display_avatar.url)
        try:
            await thread.send(
                content=f"<@{message.author.id}> opened a modmail. "
                        f"Reply here to answer them, or run `modmail close` to finish.",
                embed=embed)
            await message.add_reaction("📨")
        except discord.HTTPException:
            pass

    async def _handle_staff_reply(self, message: discord.Message):
        row = await self._thread_for(message.channel.id)
        if row is None or row["status"] != "open":
            return
        if message.author.id == int(row["user_id"]):
            return
        guild = self.bot.get_guild(int(row["guild_id"]))
        try:
            user = self.bot.get_user(int(row["user_id"])) or await self.bot.fetch_user(
                int(row["user_id"]))
        except discord.HTTPException:
            user = None
        if user is None:
            return
        embed, _ = self._format(message)
        embed.title = f"Staff reply · {guild.name if guild else 'Server'}"
        embed.color = 0x00B894
        embed.set_footer(text="Reply to this DM to answer back")
        try:
            await user.send(embed=embed)
        except discord.HTTPException:
            try:
                await message.channel.send(embed=self.embed(
                    f"{CROSS} Delivery Failed",
                    "That member has DMs closed, so the reply could not be sent."))
            except discord.HTTPException:
                pass

    # ── commands ─────────────────────────────────────────────────────
    @commands.group(name="modmail", aliases=["mail"], invoke_without_command=True,
                    help="DM based modmail for this server.")
    @commands.guild_only()
    async def modmail(self, ctx):
        config = await self._config(ctx.guild.id)
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) FROM modmail_threads WHERE guild_id = ? AND status = 'open'",
                (ctx.guild.id,)
            ) as cur:
                open_mails = int((await cur.fetchone())[0])
        finally:
            await db.close()
        p = ctx.clean_prefix
        channel = f"<#{int(config['channel_id'])}>" if config else "not set"
        await ctx.reply(embed=self.embed(
            f"{MESSAGE} ModMail",
            f"**Mail channel:** {channel}\n**Open threads:** {open_mails}\n\n"
            f"`{p}modmail setup #channel` · `{p}modmail close` · `{p}modmail list`\n"
            f"Members just DM the bot to open a mail."), mention_author=False)

    @modmail.command(name="setup")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def modmail_setup(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        db = await self._connect()
        try:
            await db.execute(
                "INSERT INTO modmail_config (guild_id, channel_id, enabled) "
                "VALUES (?, ?, 1) ON CONFLICT(guild_id) DO UPDATE SET "
                "channel_id = excluded.channel_id, enabled = 1",
                (ctx.guild.id, channel.id))
            await db.commit()
        finally:
            await db.close()
        warn = ""
        if not channel.permissions_for(ctx.guild.me).create_public_threads:
            warn = "\n⚠️ I need **Create Public Threads** in that channel."
        await ctx.reply(embed=self.embed(
            f"{TICK} ModMail Enabled",
            f"Member DMs will open threads in {channel.mention}.{warn}"),
            mention_author=False)

    @modmail.command(name="disable")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def modmail_disable(self, ctx):
        db = await self._connect()
        try:
            cur = await db.execute(
                "UPDATE modmail_config SET enabled = 0 WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
            changed = cur.rowcount
        finally:
            await db.close()
        if not changed:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Configured",
                f"Run `{ctx.clean_prefix}modmail setup #channel` first."))
        await ctx.reply(embed=self.embed(
            f"{TICK} ModMail Disabled", "New DMs will be ignored."), mention_author=False)

    @modmail.command(name="list")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def modmail_list(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT user_id, thread_id, created_at FROM modmail_threads "
                "WHERE guild_id = ? AND status = 'open' ORDER BY created_at DESC LIMIT 15",
                (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Open Mail", "Every modmail thread is closed."))
        lines = [f"<@{int(row['user_id'])}> — <#{int(row['thread_id'])}>"
                 for row in rows]
        await ctx.reply(embed=self.embed(f"{MESSAGE} Open Modmail", "\n".join(lines)),
                        mention_author=False)

    @modmail.command(name="close", aliases=["done"])
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def modmail_close(self, ctx, *, reason: str = ""):
        if not isinstance(ctx.channel, discord.Thread):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not In A Mail",
                "Run this inside the modmail thread you want to close."))
        row = await self._thread_for(ctx.channel.id)
        if row is None or row["status"] != "open":
            return await ctx.reply(embed=self.embed(
                f"{INFO} Not Tracked", "This thread is not an open modmail."))
        transcript = []
        async for old in ctx.channel.history(limit=400, oldest_first=True):
            stamp = old.created_at.strftime("%Y-%m-%d %H:%M")
            transcript.append(f"[{stamp}] {old.author}: {old.content or '(embed/attachment)'}")
        db = await self._connect()
        try:
            await db.execute(
                "UPDATE modmail_threads SET status = 'closed' WHERE thread_id = ?",
                (ctx.channel.id,))
            await db.commit()
            await db.execute(
                "INSERT OR IGNORE INTO modmail_threads "
                "(thread_id, guild_id, user_id, channel_id, status, created_at) "
                "SELECT thread_id, guild_id, user_id, channel_id, 'closed', created_at "
                "FROM modmail_threads WHERE thread_id = ?", (ctx.channel.id,))
            await db.commit()
        finally:
            await db.close()
        user = self.bot.get_user(int(row["user_id"]))
        payload = ("\n".join(transcript) or "empty transcript").encode()
        try:
            if user is not None:
                await user.send(
                    embed=self.embed(
                        f"{TICK} Modmail Closed",
                        f"Your mail on **{ctx.guild.name}** was closed"
                        + (f": {reason}" if reason else "."),
                        colour=0x00B894),
                    file=discord.File(io.BytesIO(payload), filename="transcript.txt"))
        except discord.HTTPException:
            pass
        await ctx.reply(embed=self.embed(
            f"{TICK} Modmail Closed",
            f"Transcript saved{(' · ' + reason) if reason else ''}."), mention_author=False)
        try:
            await ctx.channel.edit(archived=True, locked=True)
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(ModMail(bot))
