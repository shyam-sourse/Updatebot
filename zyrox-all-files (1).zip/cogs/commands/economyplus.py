# ╔══════════════════════════════════════════════════════════════════╗
# ║   Economy Plus  ──  robbing, bank, quests, achievements, bounty    ║
# ║   rob • bank • quests • achievements • bounty • trade • auction    ║
# ║   crash • roulette • dice                                          ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Extra economy layers on top of ``db/economy.db``.

Free servers get the core loop; Premium raises rob success, bank interest,
quest rewards and unlocks player auctions.
"""

from __future__ import annotations

import os
import random
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import premium
from utils.emoji import CROSS, GAMES, INFO, KING, MONEY, SPARKLE, TICK, WARNING

from .economy import money, parse_amount

ECO_DB = "db/economy.db"
DB = "db/economyplus.db"
COLOR = 0xFF0000

QUEST_TARGETS = {"messages": 25, "work": 1, "gamble": 3, "daily": 1}
QUEST_LABELS = {
    "messages": "Send 25 messages",
    "work": "Work one shift",
    "gamble": "Gamble 3 times",
    "daily": "Claim your daily",
}
QUEST_REWARD = 150

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS eco_users (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        coins INTEGER NOT NULL DEFAULT 0,
        bank INTEGER NOT NULL DEFAULT 0,
        streak INTEGER NOT NULL DEFAULT 0,
        last_daily TEXT,
        last_work TEXT,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS quest_progress (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        day TEXT NOT NULL,
        kind TEXT NOT NULL,
        progress INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, day, kind)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS quest_claims (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        day TEXT NOT NULL,
        kind TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id, day, kind)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS eco_bounty (
        bounty_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        placed_by INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        claimed_by INTEGER,
        claimed_at TEXT,
        created_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS eco_bank_log (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        day TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id, day)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS eco_auctions (
        auction_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL,
        seller_id INTEGER NOT NULL,
        item TEXT NOT NULL,
        price INTEGER NOT NULL,
        highest_bid INTEGER NOT NULL DEFAULT 0,
        highest_bidder INTEGER,
        ends_at TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1
    )
    """,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _today() -> str:
    return _now().strftime("%Y-%m-%d")


class TradeView(discord.ui.View):
    """Accept / decline a coin (and optional item) trade."""

    def __init__(self, cog: "EconomyPlus", guild_id: int, sender_id: int,
                 target_id: int, coins: int, item: str | None):
        super().__init__(timeout=120)
        self.cog = cog
        self.guild_id = guild_id
        self.sender_id = sender_id
        self.target_id = target_id
        self.coins = coins
        self.item = item

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.target_id:
            await interaction.response.send_message(
                "This trade is not for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success, emoji="✅")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        error = await self.cog.complete_trade(
            self.guild_id, self.sender_id, self.target_id, self.coins, self.item)
        self.stop()
        if error:
            return await interaction.response.edit_message(
                embed=self.cog.embed(f"{CROSS} Trade Failed", error), view=None)
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{TICK} Trade Complete",
            f"<@{self.sender_id}> → <@{self.target_id}> · "
            f"**{money(self.coins)} coins**"
            + (f" and **{self.item}**" if self.item else "")), view=None)

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.secondary, emoji="✖️")
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        await interaction.response.edit_message(embed=self.cog.embed(
            f"{CROSS} Trade Declined", "Nothing was moved."), view=None)


class EconomyPlus(commands.Cog):
    """Rob, bank, quests, achievements, bounties, trading, auctions and casino."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (GAMES, "Economy+", "Rob, bank interest, quests, achievements and casino.")

    def cog_load(self):
        self.auction_watch.start()

    def cog_unload(self):
        self.auction_watch.cancel()

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _account(self, db, guild_id: int, user_id: int):
        await db.execute(
            "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id))
        async with db.execute(
            "SELECT * FROM eco_users WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ) as cur:
            return await cur.fetchone()

    async def _cash(self, guild_id: int, user_id: int) -> int:
        db = await self._connect()
        try:
            row = await self._account(db, guild_id, user_id)
            return int(row["coins"])
        finally:
            await db.close()

    # ── quest progress hooks (called from economy.py) ────────────────
    async def add_progress(self, guild_id: int, user_id: int, kind: str):
        target = QUEST_TARGETS.get(kind)
        if not target:
            return
        db = await self._connect()
        try:
            await self._account(db, guild_id, user_id)
            await db.execute(
                "INSERT OR IGNORE INTO quest_progress "
                "(guild_id, user_id, day, kind, progress) VALUES (?, ?, ?, ?, 0)",
                (guild_id, user_id, _today(), kind))
            await db.execute(
                "UPDATE quest_progress SET progress = MIN(progress + 1, ?) "
                "WHERE guild_id = ? AND user_id = ? AND day = ? AND kind = ?",
                (target, guild_id, user_id, _today(), kind))
            await db.commit()
        finally:
            await db.close()

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        text = (message.content or "").strip()
        if len(text) < 5 or text.startswith((">", "!", "/", ".", "?", "$", "-")):
            return
        try:
            await self.add_progress(message.guild.id, message.author.id, "messages")
        except Exception:
            pass

    # ── robbing ──────────────────────────────────────────────────────
    @commands.command(name="rob", aliases=["stealcoins", "robcash"],
                      help="Try to rob another member's cash.")
    @commands.guild_only()
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def rob(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}rob @member` — 30 min cooldown."))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Rob another human member."))
        db = await self._connect()
        try:
            robber = await self._account(db, ctx.guild.id, ctx.author.id)
            victim = await self._account(db, ctx.guild.id, member.id)
            victim_cash = int(victim["coins"])
            if victim_cash < 50:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Worth It",
                    f"{member.display_name} has less than 50 coins in cash."))
            paid = await premium.is_paid(ctx.guild.id)
            chance = 0.45 if paid else 0.30
            if random.random() < chance:
                stolen = random.randint(10, max(11, int(victim_cash * 0.15)))
                stolen = min(stolen, victim_cash)
                await db.execute(
                    "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                    (stolen, ctx.guild.id, member.id))
                await db.execute(
                    "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                    (stolen, ctx.guild.id, ctx.author.id))
                await db.commit()
                return await ctx.reply(embed=self.embed(
                    f"{TICK} Robbery Successful",
                    f"You slipped away with **{money(stolen)} coins** from "
                    f"{member.mention}.\nYour cash: **{money(int(robber['coins']) + stolen)}**"),
                    mention_author=False)
            penalty = min(int(robber["coins"]), random.randint(20, 120))
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (penalty, ctx.guild.id, ctx.author.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{CROSS} Caught",
            f"{member.mention} caught you and you paid a **{money(penalty)} coin** fine."),
            mention_author=False)

    # ── bank ─────────────────────────────────────────────────────────
    @commands.group(name="bank", invoke_without_command=True,
                    help="Deposit, withdraw and collect bank interest.")
    @commands.guild_only()
    async def bank(self, ctx):
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
        finally:
            await db.close()
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{MONEY} Your Bank",
            f"**Cash:** {money(row['coins'])} coins\n"
            f"**Bank:** {money(row['bank'])} coins\n\n"
            f"`{p}bank deposit <amount>` · `{p}bank withdraw <amount>` · "
            f"`{p}bank interest`\nBank coins cannot be robbed."),
            mention_author=False)

    @bank.command(name="deposit", aliases=["dep", "put"])
    @commands.guild_only()
    async def bank_deposit(self, ctx, amount: str = None):
        value = parse_amount(amount)
        if value is None or value == 0 or value < -1:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}bank deposit 500` or `all`."))
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            cash = int(row["coins"])
            if value == -1:
                value = cash
            if value <= 0 or cash < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Cash",
                    f"You only have **{money(cash)}** coins in cash."))
            await db.execute(
                "UPDATE eco_users SET coins = coins - ?, bank = bank + ? "
                "WHERE guild_id = ? AND user_id = ?",
                (value, value, ctx.guild.id, ctx.author.id))
            await db.commit()
            row = await self._account(db, ctx.guild.id, ctx.author.id)
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Deposited",
            f"Moved **{money(value)} coins** into the bank.\n"
            f"Bank balance: **{money(row['bank'])}**"), mention_author=False)

    @bank.command(name="withdraw", aliases=["with", "take"])
    @commands.guild_only()
    async def bank_withdraw(self, ctx, amount: str = None):
        value = parse_amount(amount)
        if value is None or value == 0 or value < -1:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}bank withdraw 500` or `all`."))
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            held = int(row["bank"])
            if value == -1:
                value = held
            if value <= 0 or held < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough In Bank",
                    f"Your bank holds **{money(held)}** coins."))
            await db.execute(
                "UPDATE eco_users SET coins = coins + ?, bank = bank - ? "
                "WHERE guild_id = ? AND user_id = ?",
                (value, value, ctx.guild.id, ctx.author.id))
            await db.commit()
            row = await self._account(db, ctx.guild.id, ctx.author.id)
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Withdrawn",
            f"Took **{money(value)} coins** out of the bank.\n"
            f"Cash: **{money(row['coins'])}**"), mention_author=False)

    @bank.command(name="interest", aliases=["collect"])
    @commands.guild_only()
    async def bank_interest(self, ctx):
        paid = await premium.is_paid(ctx.guild.id)
        rate = 0.03 if paid else 0.02
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            async with db.execute(
                "SELECT 1 FROM eco_bank_log WHERE guild_id = ? AND user_id = ? AND day = ?",
                (ctx.guild.id, ctx.author.id, _today())
            ) as cur:
                claimed = await cur.fetchone()
            if claimed:
                return await ctx.reply(embed=self.embed(
                    f"{INFO} Already Collected",
                    "You already collected interest today. Come back tomorrow."))
            held = int(row["bank"])
            gain = int(held * rate)
            if gain <= 0:
                return await ctx.reply(embed=self.embed(
                    f"{INFO} Nothing To Earn",
                    f"Keep at least **{int(1 / rate)}** coins in the bank to earn interest."))
            await db.execute(
                "UPDATE eco_users SET bank = bank + ? WHERE guild_id = ? AND user_id = ?",
                (gain, ctx.guild.id, ctx.author.id))
            await db.execute(
                "INSERT OR REPLACE INTO eco_bank_log (guild_id, user_id, day) VALUES (?, ?, ?)",
                (ctx.guild.id, ctx.author.id, _today()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Interest Collected",
            f"**+{money(gain)} coins** added to your bank ({int(rate * 100)}% daily)."),
            mention_author=False)

    # ── quests ───────────────────────────────────────────────────────
    @commands.group(name="quests", aliases=["quest", "missions"],
                    invoke_without_command=True,
                    help="Daily quests — finish them for bonus coins.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def quests(self, ctx):
        db = await self._connect()
        try:
            await self._account(db, ctx.guild.id, ctx.author.id)
            async with db.execute(
                "SELECT kind, progress FROM quest_progress "
                "WHERE guild_id = ? AND user_id = ? AND day = ?",
                (ctx.guild.id, ctx.author.id, _today())
            ) as cur:
                progress = {row["kind"]: int(row["progress"]) for row in await cur.fetchall()}
            async with db.execute(
                "SELECT kind FROM quest_claims WHERE guild_id = ? AND user_id = ? AND day = ?",
                (ctx.guild.id, ctx.author.id, _today())
            ) as cur:
                claimed = {row["kind"] for row in await cur.fetchall()}
        finally:
            await db.close()
        plan = await premium.get_plan_key(ctx.guild.id)
        mult = 1 if plan == premium.FREE else (2 if plan == premium.PREMIUM else 3)
        reward = QUEST_REWARD * mult
        lines = []
        for kind, target in QUEST_TARGETS.items():
            done = min(progress.get(kind, 0), target)
            state = f"{TICK} claimed" if kind in claimed else (
                "ready — `claim`" if done >= target else f"{done}/{target}")
            lines.append(f"**{QUEST_LABELS[kind]}** — {state}")
        await ctx.reply(embed=self.embed(
            f"{MONEY} Daily Quests · {reward} coins each",
            "\n".join(lines) + f"\n\nClaim with `{ctx.clean_prefix}quests claim <name>` "
            f"(messages / work / gamble / daily)."), mention_author=False)

    @quests.command(name="claim")
    @commands.guild_only()
    async def quests_claim(self, ctx, kind: str = None):
        kind = (kind or "").strip().lower()
        if kind not in QUEST_TARGETS:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Pick A Quest",
                "Choose one of: `messages`, `work`, `gamble`, `daily`."))
        target = QUEST_TARGETS[kind]
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT progress FROM quest_progress "
                "WHERE guild_id = ? AND user_id = ? AND day = ? AND kind = ?",
                (ctx.guild.id, ctx.author.id, _today(), kind)
            ) as cur:
                row = await cur.fetchone()
            if not row or int(row["progress"]) < target:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Finished",
                    f"**{QUEST_LABELS[kind]}** is not complete yet."))
            async with db.execute(
                "SELECT 1 FROM quest_claims "
                "WHERE guild_id = ? AND user_id = ? AND day = ? AND kind = ?",
                (ctx.guild.id, ctx.author.id, _today(), kind)
            ) as cur:
                if await cur.fetchone():
                    return await ctx.reply(embed=self.embed(
                        f"{INFO} Already Claimed", "This quest reward is already yours today."))
            plan = await premium.get_plan_key(ctx.guild.id)
            mult = 1 if plan == premium.FREE else (2 if plan == premium.PREMIUM else 3)
            reward = QUEST_REWARD * mult
            await self._account(db, ctx.guild.id, ctx.author.id)
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (reward, ctx.guild.id, ctx.author.id))
            await db.execute(
                "INSERT OR REPLACE INTO quest_claims (guild_id, user_id, day, kind) "
                "VALUES (?, ?, ?, ?)", (ctx.guild.id, ctx.author.id, _today(), kind))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Quest Reward",
            f"**{QUEST_LABELS[kind]}** complete — **+{money(reward)} coins**."),
            mention_author=False)

    # ── achievements ─────────────────────────────────────────────────
    @commands.command(name="achievements", aliases=["achieve", "badges"],
                      help="Show the economy achievements you unlocked.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def achievements(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        total = await premium.count_rows(
            ECO_DB, "SELECT coins + bank FROM eco_users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id))
        streak = await premium.count_rows(
            ECO_DB, "SELECT streak FROM eco_users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id))
        rep = await premium.count_rows(
            "db/social.db", "SELECT rep FROM social_users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id))
        married = await premium.count_rows(
            "db/social.db",
            "SELECT COUNT(*) FROM social_users WHERE guild_id = ? AND user_id = ? "
            "AND married_to IS NOT NULL", (ctx.guild.id, member.id))
        level = await premium.count_rows(
            "db/leveling.db", "SELECT level FROM users WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, member.id)) or 1
        checks = [
            ("First Coins", total >= 1),
            ("Saver", total >= 1_000),
            ("Rich", total >= 10_000),
            ("Tycoon", total >= 100_000),
            ("Streak Keeper", streak >= 7),
            ("Level 10", level >= 10),
            ("Popular", rep >= 10),
            ("Married", married > 0),
        ]
        unlocked = sum(1 for _, ok in checks if ok)
        lines = [f"{TICK if ok else '▫️'} **{name}**" for name, ok in checks]
        embed = self.embed(
            f"{KING} {member.display_name} · {unlocked}/{len(checks)} unlocked",
            "\n".join(lines))
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    # ── bounty ───────────────────────────────────────────────────────
    @commands.group(name="bounty", aliases=["bounties"], invoke_without_command=True,
                    help="Put a coin bounty on a member, or list open bounties.")
    @commands.guild_only()
    async def bounty(self, ctx, member: discord.Member = None, amount: str = None):
        if member is not None and amount is not None:
            return await self._place_bounty(ctx, member, amount)
        if member is not None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}bounty @member 500`"))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT target_id, SUM(amount) AS total, COUNT(*) AS n FROM eco_bounty "
                "WHERE guild_id = ? AND claimed_by IS NULL GROUP BY target_id "
                "ORDER BY total DESC LIMIT 10", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Open Bounties",
                f"Place one with `{ctx.clean_prefix}bounty @member 500`."))
        lines = []
        for index, row in enumerate(rows, start=1):
            target = ctx.guild.get_member(int(row["target_id"]))
            name = target.mention if target else f"`{row['target_id']}`"
            lines.append(f"`#{index}` {name} — **{money(row['total'])} coins** "
                         f"({int(row['n'])} bounty)")
        await ctx.reply(embed=self.embed(f"{MONEY} Open Bounties", "\n".join(lines)),
                        mention_author=False)

    async def _place_bounty(self, ctx, member: discord.Member, amount: str):
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Pick another human member."))
        value = parse_amount(amount)
        if value is None or value < 100:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Minimum 100", "Bounties start at **100 coins**."))
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            if int(row["coins"]) < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Cash",
                    f"You only have **{money(row['coins'])}** coins."))
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, ctx.author.id))
            await db.execute(
                "INSERT INTO eco_bounty (guild_id, target_id, placed_by, amount, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (ctx.guild.id, member.id, ctx.author.id, value, _now().isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TARGET_ICON} Bounty Placed",
            f"**{money(value)} coins** are now on {member.mention}'s head.\n"
            f"Staff can pay it out with `{ctx.clean_prefix}bounty claim @member`."),
            mention_author=False)

    @bounty.command(name="claim", aliases=["pay"])
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def bounty_claim(self, ctx, claimer: discord.Member = None,
                           target: discord.Member = None):
        if claimer is None or target is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}bounty claim @claimer @target`"))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT bounty_id, SUM(amount) AS total FROM eco_bounty "
                "WHERE guild_id = ? AND target_id = ? AND claimed_by IS NULL",
                (ctx.guild.id, target.id)
            ) as cur:
                row = await cur.fetchone()
            if not row or not row["total"]:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} No Bounty", f"There is no open bounty on {target.mention}."))
            total = int(row["total"])
            await db.execute(
                "UPDATE eco_bounty SET claimed_by = ?, claimed_at = ? "
                "WHERE guild_id = ? AND target_id = ? AND claimed_by IS NULL",
                (claimer.id, _now().isoformat(), ctx.guild.id, target.id))
            await self._account(db, ctx.guild.id, claimer.id)
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (total, ctx.guild.id, claimer.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Bounty Paid",
            f"{claimer.mention} collected **{money(total)} coins** for {target.mention}."),
            mention_author=False)

    # ── trading ──────────────────────────────────────────────────────
    @commands.command(name="trade", aliases=["offer"],
                      help="Trade coins (and an optional item) with a member.")
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def trade(self, ctx, member: discord.Member = None, amount: str = None,
                    *, item: str = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}trade @member 500 [item]`"))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Possible", "Trade with another human member."))
        value = parse_amount(amount)
        if value is None or value < 0:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Amount", "Give me a number like `500` or `0`."))
        item_key = (item or "").strip().lower()[:60] or None
        if value == 0 and not item_key:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Empty Trade", "Offer some coins or an item."))
        if value > 0 and await self._cash(ctx.guild.id, ctx.author.id) < value:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Enough Cash",
                f"You only have **{money(await self._cash(ctx.guild.id, ctx.author.id))}** coins."))
        await ctx.reply(
            content=member.mention,
            embed=self.embed(
                f"{MONEY} Trade Offer",
                f"{ctx.author.mention} offers {member.mention}:\n"
                f"**{money(value)} coins**" + (f"\n**{item_key}**" if item_key else "")
                + "\n\nAccept or decline within 2 minutes."),
            view=TradeView(self, ctx.guild.id, ctx.author.id, member.id, value, item_key),
            mention_author=False)

    async def complete_trade(self, guild_id: int, sender_id: int, target_id: int,
                             coins: int, item: str | None) -> str | None:
        db = await self._connect()
        try:
            sender = await self._account(db, guild_id, sender_id)
            if coins and int(sender["coins"]) < coins:
                return "The sender no longer has enough cash."
            if item:
                async with db.execute(
                    "SELECT amount FROM eco_inventory WHERE guild_id = ? AND user_id = ? "
                    "AND item = ?", (guild_id, sender_id, item)
                ) as cur:
                    row = await cur.fetchone()
                if not row or int(row["amount"]) < 1:
                    return f"The sender no longer owns **{item}**."
                await db.execute(
                    "UPDATE eco_inventory SET amount = amount - 1 WHERE guild_id = ? "
                    "AND user_id = ? AND item = ?", (guild_id, sender_id, item))
                await self._account(db, guild_id, target_id)
                await db.execute(
                    "INSERT INTO eco_inventory (guild_id, user_id, item, amount) "
                    "VALUES (?, ?, ?, 1) ON CONFLICT(guild_id, user_id, item) "
                    "DO UPDATE SET amount = amount + 1", (guild_id, target_id, item))
            if coins:
                await db.execute(
                    "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                    (coins, guild_id, sender_id))
                await self._account(db, guild_id, target_id)
                await db.execute(
                    "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                    (coins, guild_id, target_id))
            await db.commit()
        finally:
            await db.close()
        return None

    # ── auctions (premium) ───────────────────────────────────────────
    @commands.group(name="auction", aliases=["auctions"], invoke_without_command=True,
                    help="Auction shop items to the highest bidder (premium).")
    @commands.guild_only()
    async def auction(self, ctx):
        if not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature",
                "Player auctions are **Premium**.\n"
                f"Run `{ctx.clean_prefix}premium` to unlock them."))
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT item, price, highest_bid, seller_id, ends_at FROM eco_auctions "
                "WHERE guild_id = ? AND active = 1 ORDER BY auction_id", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        p = ctx.clean_prefix
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Live Auctions",
                f"Start one with `{p}auction start <item> <price>`."))
        lines = []
        for row in rows:
            top = int(row["highest_bid"]) or int(row["price"])
            lines.append(f"**{row['item']}** — top bid **{money(top)}** coins "
                         f"(seller <@{int(row['seller_id'])}>)")
        await ctx.reply(embed=self.embed(
            f"{MONEY} Live Auctions",
            "\n".join(lines) + f"\n\nBid with `{p}auction bid <item> <amount>`."),
            mention_author=False)

    @auction.command(name="start")
    @commands.guild_only()
    async def auction_start(self, ctx, item: str = None, price: str = None):
        if not await premium.is_paid(ctx.guild.id):
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Premium Feature", "Player auctions are **Premium**."))
        value = parse_amount(price)
        if not item or value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}auction start <item> <price>`"))
        key = item.strip().lower()[:60]
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT amount FROM eco_inventory WHERE guild_id = ? AND user_id = ? "
                "AND item = ?", (ctx.guild.id, ctx.author.id, key)
            ) as cur:
                row = await cur.fetchone()
            if not row or int(row["amount"]) < 1:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Item Missing", f"You do not own **{key}**."))
            await db.execute(
                "UPDATE eco_inventory SET amount = amount - 1 WHERE guild_id = ? "
                "AND user_id = ? AND item = ?", (ctx.guild.id, ctx.author.id, key))
            ends = _now() + timedelta(hours=1)
            await db.execute(
                "INSERT INTO eco_auctions (guild_id, channel_id, seller_id, item, price, ends_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (ctx.guild.id, ctx.channel.id, ctx.author.id, key, value, ends.isoformat()))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{MONEY} Auction Started",
            f"**{key}** is up for auction at **{money(value)} coins**.\n"
            f"Ends <t:{int(ends.timestamp())}:R>. Bid with "
            f"`{ctx.clean_prefix}auction bid {key} <amount>`."), mention_author=False)

    @auction.command(name="bid")
    @commands.guild_only()
    async def auction_bid(self, ctx, item: str = None, amount: str = None):
        value = parse_amount(amount)
        if not item or value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}auction bid <item> <amount>`"))
        key = item.strip().lower()[:60]
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM eco_auctions WHERE guild_id = ? AND item = ? AND active = 1",
                (ctx.guild.id, key)
            ) as cur:
                row = await cur.fetchone()
            if not row:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} No Auction", f"No live auction for **{key}**."))
            if int(row["seller_id"]) == ctx.author.id:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Allowed", "You cannot bid on your own auction."))
            minimum = max(int(row["highest_bid"]) + 1, int(row["price"]))
            if value < minimum:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Bid Too Low", f"The next bid must be at least **{money(minimum)}**."))
            if await self._cash(ctx.guild.id, ctx.author.id) < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Cash",
                    f"You only have **{money(await self._cash(ctx.guild.id, ctx.author.id))}** coins."))
            await db.execute(
                "UPDATE eco_auctions SET highest_bid = ?, highest_bidder = ? "
                "WHERE auction_id = ?", (value, ctx.author.id, int(row["auction_id"])))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Bid Placed",
            f"{ctx.author.mention} is now the top bidder for **{key}** at "
            f"**{money(value)} coins**."), mention_author=False)

    @auction.command(name="cancel")
    @commands.guild_only()
    async def auction_cancel(self, ctx, item: str = None):
        if not item:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}auction cancel <item>`"))
        key = item.strip().lower()[:60]
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM eco_auctions WHERE guild_id = ? AND item = ? AND active = 1",
                (ctx.guild.id, key)
            ) as cur:
                row = await cur.fetchone()
            if not row:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} No Auction", f"No live auction for **{key}**."))
            if int(row["seller_id"]) != ctx.author.id and not ctx.author.guild_permissions.manage_guild:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Yours", "Only the seller or an admin can cancel it."))
            await db.execute(
                "UPDATE eco_auctions SET active = 0 WHERE auction_id = ?",
                (int(row["auction_id"]),))
            await self._account(db, ctx.guild.id, int(row["seller_id"]))
            await db.execute(
                "INSERT INTO eco_inventory (guild_id, user_id, item, amount) "
                "VALUES (?, ?, ?, 1) ON CONFLICT(guild_id, user_id, item) "
                "DO UPDATE SET amount = amount + 1",
                (ctx.guild.id, int(row["seller_id"]), key))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Auction Cancelled", f"**{key}** was returned to the seller."),
            mention_author=False)

    @tasks.loop(seconds=60)
    async def auction_watch(self):
        await self.bot.wait_until_ready()
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM eco_auctions WHERE active = 1 AND ends_at <= ?",
                (_now().isoformat(),)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        for row in rows:
            await self._finish_auction(row)

    async def _finish_auction(self, row):
        auction_id = int(row["auction_id"])
        guild = self.bot.get_guild(int(row["guild_id"]))
        channel = guild.get_channel(int(row["channel_id"])) if guild else None
        item = row["item"]
        seller_id = int(row["seller_id"])
        bidder = int(row["highest_bidder"]) if row["highest_bidder"] else None
        amount = int(row["highest_bid"])
        db = await self._connect()
        try:
            await db.execute(
                "UPDATE eco_auctions SET active = 0 WHERE auction_id = ?", (auction_id,))
            if bidder and amount > 0:
                buyer = await self._account(db, int(row["guild_id"]), bidder)
                if int(buyer["coins"]) >= amount:
                    await db.execute(
                        "UPDATE eco_users SET coins = coins - ? "
                        "WHERE guild_id = ? AND user_id = ?",
                        (amount, int(row["guild_id"]), bidder))
                    await self._account(db, int(row["guild_id"]), seller_id)
                    await db.execute(
                        "UPDATE eco_users SET coins = coins + ? "
                        "WHERE guild_id = ? AND user_id = ?",
                        (amount, int(row["guild_id"]), seller_id))
                    await db.execute(
                        "INSERT INTO eco_inventory (guild_id, user_id, item, amount) "
                        "VALUES (?, ?, ?, 1) ON CONFLICT(guild_id, user_id, item) "
                        "DO UPDATE SET amount = amount + 1",
                        (int(row["guild_id"]), bidder, item))
                    await db.commit()
                    if channel:
                        try:
                            await channel.send(embed=self.embed(
                                f"{TICK} Auction Won",
                                f"<@{bidder}> won **{item}** for **{money(amount)} coins**."))
                        except discord.HTTPException:
                            pass
                    return
            await db.execute(
                "INSERT INTO eco_inventory (guild_id, user_id, item, amount) "
                "VALUES (?, ?, ?, 1) ON CONFLICT(guild_id, user_id, item) "
                "DO UPDATE SET amount = amount + 1",
                (int(row["guild_id"]), seller_id, item))
            await db.commit()
        finally:
            await db.close()
        if channel:
            try:
                await channel.send(embed=self.embed(
                    f"{INFO} Auction Ended",
                    f"No valid bid for **{item}** — returned to <@{seller_id}>."))
            except discord.HTTPException:
                pass

    # ── casino ───────────────────────────────────────────────────────
    async def _bet(self, ctx, amount: str):
        """Validate a bet and return (value, cash, row) or send an error."""
        value = parse_amount(amount)
        if value is None or value == 0 or value < -1:
            await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}{ctx.command.name} 100`"))
            return None
        cash = await self._cash(ctx.guild.id, ctx.author.id)
        if value == -1:
            value = cash
        if value <= 0:
            await ctx.reply(embed=self.embed(
                f"{CROSS} Nothing To Bet", "You have no coins. Try `daily` or `work`."))
            return None
        if cash < value:
            await ctx.reply(embed=self.embed(
                f"{CROSS} Not Enough Coins", f"You only have **{money(cash)}** coins."))
            return None
        return value

    async def _settle(self, ctx, value: int, won: bool, multiplier: float):
        db = await self._connect()
        try:
            delta = int(value * (multiplier - 1)) if won else -value
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (delta, ctx.guild.id, ctx.author.id))
            await db.commit()
            row = await self._account(db, ctx.guild.id, ctx.author.id)
        finally:
            await db.close()
        return delta, int(row["coins"])

    @commands.command(name="crash", help="Cash out before the multiplier crashes.")
    @commands.guild_only()
    @commands.cooldown(1, 8, commands.BucketType.user)
    async def crash(self, ctx, amount: str = None):
        value = await self._bet(ctx, amount)
        if value is None:
            return
        paid = await premium.is_paid(ctx.guild.id)
        chance = 0.50 if paid else 0.42
        won = random.random() < chance
        delta, cash = await self._settle(ctx, value, won, 1.8)
        if won:
            await ctx.reply(embed=self.embed(
                f"{TICK} Cashed Out",
                f"You cashed out at **1.8×** — **+{money(delta)} coins**.\n"
                f"Wallet: {money(cash)}"), mention_author=False)
        else:
            await ctx.reply(embed=self.embed(
                f"{CROSS} Crashed",
                f"The multiplier crashed at **1.0×** — **-{money(value)} coins**.\n"
                f"Wallet: {money(cash)}"), mention_author=False)

    @commands.command(name="roulette", aliases=["roul"],
                      help="Bet on red, black or green (green pays 14x).")
    @commands.guild_only()
    @commands.cooldown(1, 8, commands.BucketType.user)
    async def roulette(self, ctx, amount: str = None, colour: str = None):
        value = await self._bet(ctx, amount)
        if value is None:
            return
        pick = (colour or "").strip().lower()
        if pick not in ("red", "black", "green", "r", "b", "g"):
            return await ctx.reply(embed=self.embed(
                f"{INFO} Pick A Colour",
                f"`{ctx.clean_prefix}roulette 100 red` — red, black or green."))
        pick = {"r": "red", "b": "black", "g": "green"}.get(pick, pick)
        roll = random.randint(0, 36)
        if roll == 0:
            landed = "green"
        else:
            landed = "red" if roll <= 18 else "black"
        if pick == landed:
            multiplier = 14.0 if landed == "green" else 2.0
            delta, cash = await self._settle(ctx, value, True, multiplier)
            await ctx.reply(embed=self.embed(
                f"{TICK} {landed.title()} · {roll}",
                f"You won **+{money(delta)} coins**. Wallet: {money(cash)}"),
                mention_author=False)
        else:
            delta, cash = await self._settle(ctx, value, False, 1.0)
            await ctx.reply(embed=self.embed(
                f"{CROSS} {landed.title()} · {roll}",
                f"**-{money(value)} coins**. Wallet: {money(cash)}"),
                mention_author=False)

    @commands.command(name="dicebet", aliases=["rollbet", "betdice"],
                      help="Roll a die against the house; higher roll wins 2x.")
    @commands.guild_only()
    @commands.cooldown(1, 8, commands.BucketType.user)
    async def dice(self, ctx, amount: str = None):
        value = await self._bet(ctx, amount)
        if value is None:
            return
        mine, house = random.randint(1, 6), random.randint(1, 6)
        if mine > house:
            delta, cash = await self._settle(ctx, value, True, 2.0)
            title = f"{TICK} You Win"
        elif mine == house:
            delta, cash = await self._settle(ctx, value, True, 1.0)
            title = f"{INFO} Tie — Bet Returned"
        else:
            delta, cash = await self._settle(ctx, value, False, 1.0)
            title = f"{CROSS} You Lose"
        await ctx.reply(embed=self.embed(
            title,
            f"You rolled **{mine}** · house rolled **{house}**\n"
            f"Change: **{'+' if delta >= 0 else ''}{money(delta)} coins** · "
            f"Wallet: {money(cash)}"), mention_author=False)


# Unicode fallback kept local so emoji module stays untouched.
TARGET_ICON = "🎯"


async def setup(bot):
    await bot.add_cog(EconomyPlus(bot))
