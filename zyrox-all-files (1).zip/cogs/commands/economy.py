# ╔══════════════════════════════════════════════════════════════════╗
# ║   Economy  ──  coins, daily rewards, shop, inventory, gambling    ║
# ║   balance • daily • work • pay • shop • buy • inventory • gamble  ║
# ║   baltop • economy shop add/remove • economy give/reset           ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Server coin economy backed by ``db/economy.db``.

Free servers get 100 coins a day plus streak bonus and up to 5 shop items.
Premium raises the daily reward and the shop size (see ``utils/premium.py``).
"""

from __future__ import annotations

import os
import random
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands

from utils import premium
from utils.emoji import CROSS, INFO, KING, MONEY, SPARKLE, TICK, WARNING
from utils.premium_ui import send_limit

DB = "db/economy.db"
COLOR = 0xFF0000

DAILY_BASE = {premium.FREE: 100, premium.PREMIUM: 250, premium.PREMIUM_PLUS: 500}
STREAK_BONUS = 10
STREAK_CAP = 10
WORK_MIN, WORK_MAX = 20, 60
WORK_COOLDOWN = timedelta(hours=1)
WIN_CHANCE = 0.48

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS eco_users (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        coins INTEGER NOT NULL DEFAULT 0,
        bank INTEGER NOT NULL DEFAULT 0,
        streak INTEGER NOT NULL DEFAULT 0,
        last_daily TEXT,
        last_work TEXT,
        PRIMARY KEY (guild_id, user_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS eco_shop (
        guild_id INTEGER NOT NULL,
        item TEXT NOT NULL,
        price INTEGER NOT NULL DEFAULT 0,
        role_id INTEGER,
        description TEXT,
        PRIMARY KEY (guild_id, item)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS eco_inventory (
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        item TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (guild_id, user_id, item)
    )
    """,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def money(amount) -> str:
    try:
        return f"{int(amount or 0):,}"
    except (TypeError, ValueError):
        return "0"


def parse_amount(raw):
    """``1k`` → 1000, ``2m`` → 2000000, ``all`` → -1, anything else → None."""
    if raw is None:
        return None
    text = str(raw).strip().lower().replace(",", "").replace("_", "")
    if not text:
        return None
    if text in ("all", "max"):
        return -1
    multiplier = 1
    if text.endswith("k"):
        multiplier, text = 1_000, text[:-1]
    elif text.endswith("m"):
        multiplier, text = 1_000_000, text[:-1]
    if not text.isdigit():
        return None
    return int(text) * multiplier


def _end_of_day(moment: datetime) -> str:
    nxt = datetime.combine(moment.date() + timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc)
    return f"<t:{int(nxt.timestamp())}:R>"


class Economy(commands.Cog):
    """Coins, daily rewards, a per-server shop and friendly gambling."""

    def __init__(self, bot):
        self.bot = bot
        self.color = COLOR
        self._ready = False

    @staticmethod
    def help_custom():
        return (MONEY, "Economy", "Coins, daily rewards, shop, inventory and leaderboards.")

    # ── storage ──────────────────────────────────────────────────────
    def embed(self, title, description):
        return discord.Embed(title=title, description=description, color=COLOR)

    async def _ensure(self):
        if self._ready:
            return
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            for statement in SCHEMA:
                await db.execute(statement)
            await db.commit()
        self._ready = True

    async def _connect(self):
        await self._ensure()
        db = await aiosqlite.connect(DB)
        db.row_factory = aiosqlite.Row
        return db

    async def _account(self, db, guild_id, user_id):
        await db.execute(
            "INSERT OR IGNORE INTO eco_users (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id),
        )
        async with db.execute(
            "SELECT * FROM eco_users WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        ) as cur:
            return await cur.fetchone()

    async def _quest(self, guild_id, user_id, kind):
        """Forward an action to the quest tracker when Economy+ is loaded."""
        cog = self.bot.get_cog("EconomyPlus")
        if cog is None:
            return
        try:
            await cog.add_progress(guild_id, user_id, kind)
        except Exception:
            pass

    # ── wallet ───────────────────────────────────────────────────────
    @commands.command(name="balance", aliases=["bal", "wallet", "coins"],
                      help="Show your coins (or someone else's).")
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def balance(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        if member.bot:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Bots Don't Earn", "Bots have no wallet here."))
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, member.id)
        finally:
            await db.close()
        total = int(row["coins"]) + int(row["bank"])
        embed = self.embed(
            f"{MONEY} {member.display_name}'s Wallet",
            f"**Cash:** {money(row['coins'])} coins\n"
            f"**Bank:** {money(row['bank'])} coins\n"
            f"**Total:** {money(total)} coins\n"
            f"**Daily streak:** {int(row['streak'])} day(s)")
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Requested by {ctx.author}")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="daily", aliases=["claim"],
                      help="Claim your daily coins (streak gives a bonus).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def daily(self, ctx):
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            now = _now()
            last = row["last_daily"]
            last_dt = None
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                except ValueError:
                    last_dt = None
            if last_dt and last_dt.date() == now.date():
                return await ctx.reply(embed=self.embed(
                    f"{INFO} Already Claimed",
                    f"You already claimed today's coins.\nNext claim {_end_of_day(now)}."))
            if last_dt and (now.date() - last_dt.date()).days == 1:
                streak = int(row["streak"]) + 1
            else:
                streak = 1
            plan = await premium.get_plan_key(ctx.guild.id)
            base = DAILY_BASE.get(plan, DAILY_BASE[premium.FREE])
            bonus = min(streak, STREAK_CAP) * STREAK_BONUS
            reward = base + bonus
            await db.execute(
                "UPDATE eco_users SET coins = coins + ?, streak = ?, last_daily = ? "
                "WHERE guild_id = ? AND user_id = ?",
                (reward, streak, now.isoformat(), ctx.guild.id, ctx.author.id),
            )
            await db.commit()
            total = int(row["coins"]) + reward
            plan_name = (await premium.get_plan(guild_id=ctx.guild.id))["name"]
        finally:
            await db.close()
        await self._quest(ctx.guild.id, ctx.author.id, "daily")
        embed = self.embed(
            f"{MONEY} Daily Claimed",
            f"**+{money(reward)} coins** ({money(base)} base + {money(bonus)} streak)\n"
            f"**Streak:** {streak} day(s)\n"
            f"**Wallet:** {money(total)} coins\n"
            f"**Plan:** {plan_name}")
        embed.set_footer(text="Come back tomorrow to keep the streak alive.")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="work", aliases=["shift"],
                      help="Work for some coins (1 hour cooldown).")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def work(self, ctx):
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            now = _now()
            last = row["last_work"]
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                except ValueError:
                    last_dt = None
                if last_dt and now < last_dt + WORK_COOLDOWN:
                    ready = last_dt + WORK_COOLDOWN
                    return await ctx.reply(embed=self.embed(
                        f"{INFO} Not Yet",
                        f"You are tired. Work again <t:{int(ready.timestamp())}:R>."))
            earned = random.randint(WORK_MIN, WORK_MAX)
            await db.execute(
                "UPDATE eco_users SET coins = coins + ?, last_work = ? "
                "WHERE guild_id = ? AND user_id = ?",
                (earned, now.isoformat(), ctx.guild.id, ctx.author.id),
            )
            await db.commit()
        finally:
            await db.close()
        await self._quest(ctx.guild.id, ctx.author.id, "work")
        await ctx.reply(embed=self.embed(
            f"{SPARKLE} Shift Complete",
            f"You worked a shift and earned **{money(earned)} coins**.\n"
            f"Next shift in about an hour."), mention_author=False)

    @commands.command(name="pay", aliases=["transfer", "givecoins"],
                      help="Send coins to another member.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def pay(self, ctx, member: discord.Member = None, amount: str = None):
        if member is None or amount is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}pay @member 500` — or use `all`."))
        if member.bot or member.id == ctx.author.id:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Allowed", "You can only pay other humans."))
        value = parse_amount(amount)
        if value == 0 or value is None or value < -1:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Amount", "Give me a positive number like `250` or `1k`."))
        db = await self._connect()
        try:
            payer = await self._account(db, ctx.guild.id, ctx.author.id)
            cash = int(payer["coins"])
            if value == -1:
                value = cash
            if value <= 0:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Nothing To Send", "Your wallet is empty. Try `daily` or `work`."))
            if cash < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Coins",
                    f"You have **{money(cash)}** coins but tried to send **{money(value)}**."))
            await self._account(db, ctx.guild.id, member.id)
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, ctx.author.id))
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, member.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Sent",
            f"{ctx.author.mention} sent **{money(value)} coins** to {member.mention}."),
            mention_author=False)

    # ── shop ─────────────────────────────────────────────────────────
    @commands.command(name="shop", aliases=["store"],
                      help="Browse this server's coin shop.")
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def shop(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT item, price, role_id, description FROM eco_shop "
                "WHERE guild_id = ? ORDER BY price", (ctx.guild.id,)
            ) as cur:
                items = await cur.fetchall()
            row = await self._account(db, ctx.guild.id, ctx.author.id)
        finally:
            await db.close()
        if not items:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Shop Is Empty",
                f"Nothing for sale yet.\nAdmins: `{ctx.clean_prefix}economy additem "
                f"<name> <price> [@role] [description]`."))
        lines = []
        for item in items:
            role = f" — grants <@&{item['role_id']}>" if item["role_id"] else ""
            note = f"\n  ↳ {item['description'][:120]}" if item["description"] else ""
            lines.append(f"**{item['item']}** — {money(item['price'])} coins{role}{note}")
        embed = self.embed(
            f"{MONEY} {ctx.guild.name} Shop",
            "\n".join(lines)[:3900] + f"\n\n**Your wallet:** {money(row['coins'])} coins\n"
            f"Buy with `{ctx.clean_prefix}buy <item>`.")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="buy", aliases=["purchase"],
                      help="Buy an item from the server shop.")
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def buy(self, ctx, *, item: str = None):
        if not item:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}buy <item name>` — see `shop`."))
        key = item.strip().lower()[:60]
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT * FROM eco_shop WHERE guild_id = ? AND item = ?",
                (ctx.guild.id, key)
            ) as cur:
                product = await cur.fetchone()
            if not product:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Unknown Item", f"There is no **{item}** in the shop."))
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            price = int(product["price"])
            if int(row["coins"]) < price:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Coins",
                    f"**{product['item']}** costs **{money(price)}** coins, "
                    f"you have **{money(row['coins'])}**."))
            await db.execute(
                "UPDATE eco_users SET coins = coins - ? WHERE guild_id = ? AND user_id = ?",
                (price, ctx.guild.id, ctx.author.id))
            await db.execute(
                "INSERT INTO eco_inventory (guild_id, user_id, item, amount) "
                "VALUES (?, ?, ?, 1) ON CONFLICT(guild_id, user_id, item) "
                "DO UPDATE SET amount = amount + 1",
                (ctx.guild.id, ctx.author.id, product["item"]))
            await db.commit()
        finally:
            await db.close()
        role_note = ""
        if product["role_id"]:
            role = ctx.guild.get_role(int(product["role_id"]))
            if role is None:
                role_note = "\n⚠️ The role for this item no longer exists."
            else:
                try:
                    await ctx.author.add_roles(role, reason=f"Shop purchase: {product['item']}")
                    role_note = f"\nRole given: {role.mention}"
                except discord.HTTPException:
                    role_note = "\n⚠️ I could not give the role — check my role position."
        await ctx.reply(embed=self.embed(
            f"{TICK} Purchased",
            f"You bought **{product['item']}** for **{money(price)} coins**.{role_note}"),
            mention_author=False)

    @commands.command(name="inventory", aliases=["inv", "items"],
                      help="Show the items you own.")
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def inventory(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT item, amount FROM eco_inventory "
                "WHERE guild_id = ? AND user_id = ? AND amount > 0 ORDER BY item",
                (ctx.guild.id, member.id)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Empty Inventory",
                f"{member.display_name} has not bought anything yet."))
        lines = [f"**{row['item']}** × {int(row['amount'])}" for row in rows]
        embed = self.embed(f"{MONEY} {member.display_name}'s Items", "\n".join(lines)[:3900])
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="gamble", aliases=["bet", "coinflip"],
                      help="Bet coins on a coin flip (48% win chance).")
    @commands.guild_only()
    @commands.cooldown(1, 6, commands.BucketType.user)
    async def gamble(self, ctx, amount: str = None):
        value = parse_amount(amount)
        if value is None or value == 0 or value < -1:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}gamble 100` or `{ctx.clean_prefix}gamble all`."))
        db = await self._connect()
        try:
            row = await self._account(db, ctx.guild.id, ctx.author.id)
            cash = int(row["coins"])
            if value == -1:
                value = cash
            if value <= 0:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Nothing To Bet", "You have no coins. Try `daily` or `work`."))
            if cash < value:
                return await ctx.reply(embed=self.embed(
                    f"{CROSS} Not Enough Coins",
                    f"You only have **{money(cash)}** coins."))
            won = random.random() < WIN_CHANCE
            delta = value if won else -value
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (delta, ctx.guild.id, ctx.author.id))
            await db.commit()
            new_cash = cash + delta
        finally:
            await db.close()
        await self._quest(ctx.guild.id, ctx.author.id, "gamble")
        if won:
            body = (f"The coin landed on **your side**.\n"
                    f"**+{money(value)} coins** → wallet: {money(new_cash)}")
            title = f"{TICK} You Won"
        else:
            body = (f"The coin landed on the other side.\n"
                    f"**-{money(value)} coins** → wallet: {money(new_cash)}")
            title = f"{CROSS} You Lost"
        await ctx.reply(embed=self.embed(title, body), mention_author=False)

    @commands.command(name="baltop", aliases=["richest", "ecotop"],
                      help="Richest members on this server.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def baltop(self, ctx):
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT user_id, coins + bank AS total FROM eco_users "
                "WHERE guild_id = ? ORDER BY total DESC LIMIT 10", (ctx.guild.id,)
            ) as cur:
                rows = await cur.fetchall()
        finally:
            await db.close()
        if not rows:
            return await ctx.reply(embed=self.embed(
                f"{INFO} No Coins Yet", "Nobody has earned coins on this server yet."))
        lines = []
        for index, row in enumerate(rows, start=1):
            member = ctx.guild.get_member(int(row["user_id"]))
            name = member.mention if member else f"`{row['user_id']}`"
            medal = KING if index == 1 else f"`#{index}`"
            lines.append(f"{medal} {name} — **{money(row['total'])}** coins")
        await ctx.reply(embed=self.embed(f"{MONEY} Richest Members", "\n".join(lines)),
                        mention_author=False)

    # ── admin ────────────────────────────────────────────────────────
    @commands.group(name="economy", aliases=["eco"], invoke_without_command=True,
                    help="Configure the coin economy.")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def economy(self, ctx):
        p = ctx.clean_prefix
        await ctx.reply(embed=self.embed(
            f"{MONEY} Economy Setup",
            f"`{p}economy additem <name> <price> [@role] [description]`\n"
            f"`{p}economy delitem <name>`\n"
            f"`{p}economy addcoins @member <amount>`\n"
            f"`{p}economy resetwallet @member`\n\n"
            f"Members use `{p}daily`, `{p}work`, `{p}pay`, `{p}shop`, `{p}buy` and "
            f"`{p}gamble`."), mention_author=False)

    @economy.command(name="additem")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def economy_shop_add(self, ctx, name: str = None, price: str = None,
                               role: discord.Role = None, *, description: str = ""):
        if not name or price is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage",
                f"`{ctx.clean_prefix}economy shop add VIP 5000 @VIP Role for buyers`"))
        value = parse_amount(price)
        if value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Invalid Price", "Price must be a number like `500` or `5k`."))
        key = name.strip().lower()[:60]
        db = await self._connect()
        try:
            async with db.execute(
                "SELECT COUNT(*) FROM eco_shop WHERE guild_id = ?", (ctx.guild.id,)
            ) as cur:
                used = int((await cur.fetchone())[0])
            limit = await premium.limit_for(ctx.guild.id, "shop_items")
            if limit is not None and used >= limit:
                return await send_limit(ctx, "shop_items", used, limit, guild_id=ctx.guild.id)
            await db.execute(
                "INSERT INTO eco_shop (guild_id, item, price, role_id, description) "
                "VALUES (?, ?, ?, ?, ?) ON CONFLICT(guild_id, item) DO UPDATE SET "
                "price = excluded.price, role_id = excluded.role_id, "
                "description = excluded.description",
                (ctx.guild.id, key, value, role.id if role else None, description or None))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Shop Item Saved",
            f"**{key}** — {money(value)} coins"
            + (f" · grants {role.mention}" if role else "")), mention_author=False)

    @economy.command(name="delitem", aliases=["removeitem"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def economy_shop_remove(self, ctx, *, name: str = None):
        if not name:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}economy shop remove <name>`"))
        key = name.strip().lower()[:60]
        db = await self._connect()
        try:
            cur = await db.execute(
                "DELETE FROM eco_shop WHERE guild_id = ? AND item = ?", (ctx.guild.id, key))
            await db.commit()
            removed = cur.rowcount
        finally:
            await db.close()
        if not removed:
            return await ctx.reply(embed=self.embed(
                f"{CROSS} Not Found", f"No shop item named **{name}**."))
        await ctx.reply(embed=self.embed(f"{TICK} Item Removed", f"**{key}** is no longer for sale."),
                        mention_author=False)

    @economy.command(name="addcoins")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def economy_give(self, ctx, member: discord.Member = None, amount: str = None):
        value = parse_amount(amount)
        if member is None or value is None or value <= 0:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}economy give @member 500`"))
        if member.bot:
            return await ctx.reply(embed=self.embed(f"{CROSS} Not A Human", "Bots have no wallet."))
        db = await self._connect()
        try:
            await self._account(db, ctx.guild.id, member.id)
            await db.execute(
                "UPDATE eco_users SET coins = coins + ? WHERE guild_id = ? AND user_id = ?",
                (value, ctx.guild.id, member.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Coins Added", f"Gave **{money(value)} coins** to {member.mention}."),
            mention_author=False)

    @economy.command(name="resetwallet")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def economy_reset(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.reply(embed=self.embed(
                f"{INFO} Usage", f"`{ctx.clean_prefix}economy reset @member`"))
        db = await self._connect()
        try:
            await self._account(db, ctx.guild.id, member.id)
            await db.execute(
                "UPDATE eco_users SET coins = 0, bank = 0, streak = 0 "
                "WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, member.id))
            await db.commit()
        finally:
            await db.close()
        await ctx.reply(embed=self.embed(
            f"{TICK} Wallet Reset", f"{member.mention}'s wallet is back to 0 coins."),
            mention_author=False)


async def setup(bot):
    await bot.add_cog(Economy(bot))
