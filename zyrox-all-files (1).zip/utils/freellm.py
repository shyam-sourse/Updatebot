# ╔══════════════════════════════════════════════════════════════════╗
# ║   FreeLLMAPI backend  ──  any OpenAI-compatible endpoint         ║
# ║   FREELLM_API_URL • FREELLM_API_KEY • FREELLM_MODEL              ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Free LLM API transport — the bot's ONLY AI backend.

The bot's AI helpers (chat, code, explain, summarize, image analysis and the
whole AI Staff suite) all go through ``utils.ai_utils``, and every request is
sent here. There is no second provider or fallback any more: whatever
``FREELLM_API_URL`` points at is the one and only model endpoint.

Configuration lives in ``.env``::

    FREELLM_API_URL=https://your-freellmapi-host/v1
    FREELLM_API_KEY=your_key
    FREELLM_MODEL=your_model_name

``FREELLM_API_URL`` may be either the base URL (``.../v1``) or the full
``.../v1/chat/completions`` endpoint - both work.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os

import aiohttp

logger = logging.getLogger("discord")

# canonical names, plus a typo-tolerant alias for each
URL_VARS = ("FREELLM_API_URL", "FREELM_API_URL")
KEY_VARS = ("FREELLM_API_KEY", "FREELM_API_KEY")
MODEL_VARS = ("FREELLM_MODEL", "FREELM_MODEL")

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_TIMEOUT = 180

_PLACEHOLDERS = ("your_", "your-", "changeme", "change_me", "<", "insert_", "xxx")


def _read(names, default=""):
    """First non-empty, non-placeholder value among ``names``."""
    for name in names:
        raw = os.getenv(name)
        if raw is None:
            continue
        raw = raw.strip().strip('"').strip("'")
        if not raw:
            continue
        if raw.lower().startswith(_PLACEHOLDERS):
            continue
        return raw
    return default


def config():
    """Current settings as ``{"url", "key", "model"}`` (empty when unset)."""
    return {
        "url": _read(URL_VARS),
        "key": _read(KEY_VARS),
        "model": _read(MODEL_VARS),
    }


def reload_env():
    """Re-read the project ``.env`` so owner commands pick up changes live."""
    try:
        from dotenv import load_dotenv
        load_dotenv(override=True)
    except Exception as exc:  # pragma: no cover - dotenv is optional
        logger.warning(f"[FreeLLM] could not reload .env: {exc}")
    return config()


def is_configured():
    """True when a FreeLLMAPI endpoint is set, so the bot should use it."""
    return bool(config()["url"])


def model_for(requested=None):
    """FREELLM_MODEL when set, else the caller's model, else a safe default."""
    return config()["model"] or requested or DEFAULT_MODEL


def endpoint(url=None):
    """Normalise the configured value into a full chat-completions URL."""
    url = (url if url is not None else config()["url"]).rstrip("/")
    if not url:
        return ""
    if url.endswith("/chat/completions"):
        return url
    return url + "/chat/completions"


# ────────────────────────────────────────────────────────────────────
#  Errors
# ────────────────────────────────────────────────────────────────────
_MESSAGES = {
    "no_keys": (
        "🔑 **No AI configured.**\n"
        "Ask the bot owner to add `FREELLM_API_URL`, `FREELLM_API_KEY` and "
        "`FREELLM_MODEL` to the `.env` file, then restart the bot."
    ),
    "quota": (
        "⏳ **AI limit reached.** The free LLM API has used up its quota. "
        "Please try again later."
    ),
    "rate_limit": (
        "🚦 **Too many requests.** The AI API is rate limited right now. "
        "Give it a minute and try again."
    ),
    "invalid": (
        "🔑 **Invalid FreeLLMAPI key.** Check `FREELLM_API_KEY` in the bot's "
        "`.env` file."
    ),
    "model": (
        "🤖 **Model unavailable.** Check `FREELLM_MODEL` in the bot's `.env` "
        "file — the API does not seem to serve that model."
    ),
    "safety": (
        "🛡️ **Blocked response.** The AI refused to answer that (safety "
        "filter). Try rephrasing your message."
    ),
    "server": (
        "🌐 **The AI server is having issues** right now. Please try again "
        "in a moment."
    ),
    "network": "📡 **Network error** while contacting the AI. Please try again.",
    "unknown": "⚠️ **The AI request failed.** Please try again in a moment.",
}


#: public alias so other modules can reuse the wording
MESSAGES = _MESSAGES


def message_for(reason):
    """User facing text for a reason code (unknown codes fall back)."""
    return _MESSAGES.get(reason or "unknown", _MESSAGES["unknown"])


class FreeLLMError(Exception):
    """A failed FreeLLMAPI call (carries a user-facing reason)."""

    def __init__(self, reason: str, message: str = "", status=None):
        self.reason = reason if reason in _MESSAGES else "unknown"
        self.message = message or ""
        self.status = status
        super().__init__(f"[{status}] {self.message}" if status else self.message)

    @property
    def user_message(self) -> str:
        return _MESSAGES[self.reason]


def classify(status, message):
    """Map an HTTP failure onto one of the shared reason codes."""
    msg = (message or "").lower()
    if status == 429 or "rate limit" in msg or "too many requests" in msg:
        if "quota" in msg or "per day" in msg or "daily" in msg or "exceeded" in msg:
            return "quota"
        return "rate_limit"
    if status in (401, 403) or "invalid api key" in msg or "unauthorized" in msg:
        return "invalid"
    if status == 404 or (("model" in msg) and ("not found" in msg or "does not exist" in msg)):
        return "model"
    if "content_filter" in msg or "safety" in msg or "blocked" in msg or "flagged" in msg:
        return "safety"
    if status is not None and 500 <= int(status) < 600:
        return "server"
    if "timeout" in msg or "timed out" in msg or "connection" in msg:
        return "network"
    return "unknown"


# ────────────────────────────────────────────────────────────────────
#  Transport
# ────────────────────────────────────────────────────────────────────
async def chat(payload, timeout=DEFAULT_TIMEOUT):
    """POST a chat payload (``messages`` + optional model/params) and return
    the parsed OpenAI-style JSON. Raises :class:`FreeLLMError` on failure."""
    cfg = config()
    url = endpoint(cfg["url"])
    if not url:
        raise FreeLLMError("no_keys", "FREELLM_API_URL is not set")

    body = {"messages": payload.get("messages") or []}
    for key, value in (payload or {}).items():
        if key != "messages":
            body[key] = value
    body.setdefault("model", model_for())

    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if cfg["key"]:
        headers["Authorization"] = f"Bearer {cfg['key']}"

    try:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            async with session.post(url, headers=headers, json=body) as resp:
                raw = await resp.text()
                if resp.status != 200:
                    detail = raw
                    try:
                        parsed = json.loads(raw)
                        err = parsed.get("error")
                        if isinstance(err, dict):
                            detail = err.get("message") or err.get("code") or raw
                        elif isinstance(err, str):
                            detail = err
                    except (ValueError, AttributeError):
                        pass
                    detail = str(detail)[:500]
                    raise FreeLLMError(
                        classify(resp.status, detail), detail, resp.status
                    )
                try:
                    return json.loads(raw)
                except ValueError as exc:
                    raise FreeLLMError(
                        "unknown", f"non-JSON response: {raw[:200]}", resp.status
                    ) from exc
    except FreeLLMError:
        raise
    except asyncio.TimeoutError as exc:
        raise FreeLLMError("network", f"timeout: {exc}") from exc
    except aiohttp.ClientError as exc:
        raise FreeLLMError("network", str(exc)) from exc
    except OSError as exc:
        raise FreeLLMError("network", str(exc)) from exc


def message_text(message):
    """Text of a response message, including reasoning-only replies."""
    for field in ("content", "reasoning", "reasoning_content"):
        value = message.get(field)
        if isinstance(value, list):
            value = "".join(
                part.get("text", "") for part in value if isinstance(part, dict)
            )
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def status_line():
    """One-line summary for logs / owner commands."""
    cfg = config()
    if not cfg["url"]:
        return "FreeLLMAPI: not configured"
    host = cfg["url"].split("://", 1)[-1].split("/", 1)[0]
    return (
        f"FreeLLMAPI: {host} • model={cfg['model'] or '(caller default)'} • "
        f"key={'set' if cfg['key'] else 'none'}"
    )
