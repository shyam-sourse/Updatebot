# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 CodeX Devs — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://discord.gg/34thSTQ2Sp                      ║
# ║   youtube  ──  https://youtube.com/@CodeXDevs                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

"""Generic round-robin key rotation helper.

The AI backend no longer rotates keys (FreeLLMAPI uses a single key), so this
is only kept for any caller that still wants a simple rotator."""

import itertools


def _parse_keys(raw):
    if not raw:
        return []
    return [key.strip() for key in raw.split(",") if key.strip()]


class KeyRotator:
    """Round-robin key rotation with failover support."""

    def __init__(self, keys):
        self._keys = list(keys)
        self._cycle = itertools.cycle(range(len(self._keys))) if self._keys else iter(())

    @property
    def keys(self):
        return self._keys

    def next_key(self):
        """Return the next key in the rotation (None if no keys configured)."""
        if not self._keys:
            return None
        return self._keys[next(self._cycle)]

