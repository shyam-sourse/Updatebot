# ╔══════════════════════════════════════════════════════════════════╗
# ║   Compatibility shim — the bot runs on FreeLLMAPI only.          ║
# ║   Groq support has been removed.                                 ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Old imports (`key_manager`, `GroqError`, `error_message`, ...) kept alive.

There is no Groq backend any more: every AI request goes to the single
OpenAI-compatible endpoint configured by ``FREELLM_API_URL`` /
``FREELLM_API_KEY`` / ``FREELLM_MODEL`` (see :mod:`utils.freellm`).

Nothing here stores or rotates keys — the endpoint has exactly one key.
"""

from __future__ import annotations

from utils import freellm

#: one error type for every AI failure
GroqError = freellm.FreeLLMError
GroqAPIError = freellm.FreeLLMError
GeminiError = GroqError

#: reason -> user facing message
ERROR_MESSAGES = freellm.MESSAGES


def classify_error(status, message=""):
    """Map an HTTP failure onto a shared reason code."""
    return freellm.classify(status, message)


def error_message(reason):
    """Readable message for a failure reason (``no_keys``, ``quota``, ...)."""
    return freellm.message_for(reason)


def mask_key(key):
    """``abcd…wxyz`` style preview of a key (safe to show in Discord)."""
    if not key:
        return "(none)"
    key = str(key)
    if len(key) <= 8:
        return "*" * len(key)
    return f"{key[:4]}…{key[-4:]}"


def load_keys():
    """There is only one configured key now; kept for old callers."""
    key = freellm.config()["key"]
    return [key] if key else []


class FreeLLMKeyManager:
    """Status-only stand-in for the old Groq key manager."""

    @property
    def keys(self):
        return load_keys()

    @property
    def has_keys(self):
        """True when ``FREELLM_API_URL`` is configured."""
        return freellm.is_configured()

    @property
    def has_groq_keys(self):
        """Always False — the Groq backend was removed."""
        return False

    def info(self):
        """No key pool to list any more."""
        return []

    def status(self):
        """One-line summary used by owner commands."""
        return [freellm.status_line()]

    def reload(self):
        """Re-read ``.env`` and report how many keys the endpoint has."""
        freellm.reload_env()
        return len(self.keys)

    async def run(self, func, models=None):
        """Single-endpoint fallback used by any leftover caller."""
        last = None
        for model in (models or [None]):
            try:
                return await func(self.keys[0] if self.keys else "", model)
            except Exception as exc:  # noqa: BLE001 - re-raised below
                last = exc
        raise GroqError(getattr(last, "reason", "unknown"), str(last))


GroqKeyManager = FreeLLMKeyManager
GeminiKeyManager = FreeLLMKeyManager

#: module level singleton, exactly like the old ``key_manager``
key_manager = FreeLLMKeyManager()

__all__ = [
    "key_manager",
    "error_message",
    "classify_error",
    "load_keys",
    "mask_key",
    "ERROR_MESSAGES",
    "GroqError",
    "GroqAPIError",
    "GroqKeyManager",
    "FreeLLMKeyManager",
    "GeminiError",
    "GeminiKeyManager",
]
