"""No-prefix trial storage.

A member can claim prefix-free commands **once** from a panel button. The
trial lives in ``db/np.db`` next to the permanent ``np`` table so
``core/zyrox.py`` can resolve both from one file.

* ``np_trials`` – one row per member: claim time and expiry time
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

import aiosqlite

DB_PATH = os.path.join("db", "np.db")
TABLE = "np_trials"


def _env_days() -> int:
    raw = (os.getenv("NP_TRIAL_DAYS") or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else 7


TRIAL_DAYS = _env_days()


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse(raw) -> datetime | None:
    if not raw:
        return None
    try:
        value = datetime.fromisoformat(str(raw))
    except ValueError:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value


async def init() -> None:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {TABLE} (
                user_id INTEGER PRIMARY KEY,
                guild_id INTEGER,
                claimed_at TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )
            """
        )
        await db.commit()


async def get_trial(user_id: int) -> dict | None:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                f"SELECT user_id, guild_id, claimed_at, expires_at FROM {TABLE} WHERE user_id = ?",
                (user_id,),
            ) as cursor:
                row = await cursor.fetchone()
    except aiosqlite.Error:
        return None
    return dict(row) if row else None


async def is_active(user_id: int) -> bool:
    trial = await get_trial(user_id)
    if not trial:
        return False
    expires = _parse(trial.get("expires_at"))
    return expires is not None and expires > _utcnow()


async def has_permanent(user_id: int) -> bool:
    """True when the member is already on the permanent no-prefix list."""
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(
                "SELECT expiry_time FROM np WHERE id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
    except aiosqlite.Error:
        return False
    if not row:
        return False
    expiry = row[0]
    if not expiry or str(expiry).strip().lower() in ("null", "none", "lifetime"):
        return True
    parsed = _parse(str(expiry))
    return parsed is None or parsed > _utcnow()


async def claim(user_id: int, guild_id: int | None) -> tuple[str, dict | None]:
    """Claim the trial.

    Returns ``("ok" | "claimed" | "error", trial_row_or_None)``. A row is kept
    forever after the first claim so nobody can claim twice, even later.
    """
    await init()
    now = _utcnow()
    expires = now + timedelta(days=TRIAL_DAYS)
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                f"INSERT INTO {TABLE} (user_id, guild_id, claimed_at, expires_at) "
                "VALUES (?, ?, ?, ?)",
                (user_id, guild_id, now.isoformat(), expires.isoformat()),
            )
            await db.commit()
    except aiosqlite.IntegrityError:
        return "claimed", await get_trial(user_id)
    except aiosqlite.Error:
        return "error", None
    return "ok", await get_trial(user_id)


async def remove(user_id: int) -> bool:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute(f"DELETE FROM {TABLE} WHERE user_id = ?", (user_id,))
            await db.commit()
            return cursor.rowcount > 0
    except aiosqlite.Error:
        return False


async def active_count() -> int:
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(f"SELECT COUNT(*) FROM {TABLE}") as cursor:
                row = await cursor.fetchone()
    except aiosqlite.Error:
        return 0
    return int(row[0]) if row else 0
