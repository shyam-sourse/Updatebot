# ╔══════════════════════════════════════════════════════════════════╗
# ║   Global Bot Log  ──  one channel for everything the bot does     ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Owner-selected log channel for the whole bot.

The bot owner picks one channel with ``>botlog set #channel`` (or
``>botlog here``). After that every notable thing the bot does is posted
there as a compact embed:

    * commands run (who, where, which command)
    * AI calls (provider, model, prompt size, time taken)
    * ticket events (opened, claimed, locked, closed)
    * bot events (online, joined/left a server)
    * command errors

Design notes
------------
* :func:`log` is **synchronous** and only puts an embed on a queue, so a
  caller can never be slowed down or crashed by logging.
* A background worker sends at most one message every ``MIN_SEND_INTERVAL``
  seconds, which keeps Discord's per-channel rate limit happy even during a
  burst of AI calls.
* The channel id lives in ``data/botlog.json`` so it survives restarts.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from datetime import datetime, timezone

import discord

STORE_PATH = os.path.join("data", "botlog.json")
MIN_SEND_INTERVAL = 1.2      # seconds between two log messages (rate-limit safe)
QUEUE_MAX = 500              # events buffered before we start dropping

COLORS = {
    "command": 0x5865F2,
    "ai": 0x00A67E,
    "ticket": 0xF1C40F,
    "event": 0x2ECC71,
    "error": 0xE74C3C,
    "general": 0xFF0000,
}

# ── state ────────────────────────────────────────────────────────────
_settings = {"channel_id": None, "paused": False}
_stats = {"sent": 0, "dropped": 0, "failed": 0}
_bot = None
_queue: asyncio.Queue | None = None
_worker: asyncio.Task | None = None
_loaded = False


# ── settings file ────────────────────────────────────────────────────
def _load() -> None:
    global _loaded
    if _loaded:
        return
    _loaded = True
    try:
        with open(STORE_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        cid = data.get("channel_id")
        _settings["channel_id"] = int(cid) if cid else None
        _settings["paused"] = bool(data.get("paused", False))
    except (OSError, ValueError, TypeError):
        pass


def _save() -> None:
    try:
        os.makedirs(os.path.dirname(STORE_PATH), exist_ok=True)
        with open(STORE_PATH, "w", encoding="utf-8") as fh:
            json.dump(_settings, fh)
    except OSError as exc:
        print(f"[botlog] could not save settings: {exc}")


# ── public config api ────────────────────────────────────────────────
def bind(bot) -> None:
    """Give the logger the bot instance (called from ``on_ready``)."""
    global _bot
    _bot = bot
    _load()


def channel_id():
    _load()
    return _settings["channel_id"]


def set_channel(channel_id_value) -> None:
    _load()
    _settings["channel_id"] = int(channel_id_value) if channel_id_value else None
    _settings["paused"] = False
    _save()


def clear_channel() -> None:
    _load()
    _settings["channel_id"] = None
    _save()


def paused() -> bool:
    _load()
    return bool(_settings["paused"])


def set_paused(flag: bool) -> None:
    _load()
    _settings["paused"] = bool(flag)
    _save()


def is_active() -> bool:
    return channel_id() is not None and not paused()


def stats() -> dict:
    data = dict(_stats)
    data["queued"] = _queue.qsize() if _queue is not None else 0
    data["channel_id"] = channel_id()
    data["paused"] = paused()
    return data


# ── queue + worker ───────────────────────────────────────────────────
def _ensure_worker() -> bool:
    """Create the send loop on the running bot loop. False = no loop."""
    global _queue, _worker
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return False
    if _queue is None:
        _queue = asyncio.Queue(maxsize=QUEUE_MAX)
    if _worker is None or _worker.done():
        _worker = loop.create_task(_dispatcher())
    return True


async def _dispatcher() -> None:
    while True:
        event = await _queue.get()
        try:
            await _deliver(event)
        except asyncio.CancelledError:
            raise
        except Exception as exc:            # never let the loop die
            _stats["failed"] += 1
            print(f"[botlog] send failed: {exc}")
        finally:
            _queue.task_done()
        await asyncio.sleep(MIN_SEND_INTERVAL)


async def _deliver(event: dict) -> None:
    if _bot is None:
        _stats["failed"] += 1
        return
    cid = channel_id()
    if cid is None:
        _stats["failed"] += 1
        return
    channel = _bot.get_channel(cid)
    if channel is None:
        try:
            channel = await _bot.fetch_channel(cid)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            _stats["failed"] += 1
            print(f"[botlog] channel {cid} is gone or not visible; logging paused")
            set_paused(True)
            return
    try:
        await channel.send(embed=event["embed"])
        _stats["sent"] += 1
    except discord.HTTPException as exc:
        _stats["failed"] += 1
        print(f"[botlog] HTTP {exc.status} while sending: {exc.text[:200]}")


# ── embed building ───────────────────────────────────────────────────
def _embed(title, description=None, category="general", fields=None,
           color=None, footer=None) -> discord.Embed:
    embed = discord.Embed(
        title=str(title)[:250],
        description=(str(description) if description else None),
        color=color if color is not None else COLORS.get(category, COLORS["general"]),
        timestamp=datetime.now(timezone.utc),
    )
    for name, value, inline in (fields or []):
        if value is None:
            continue
        embed.add_field(name=str(name)[:250], value=str(value)[:1000] or "—",
                        inline=bool(inline))
    embed.set_footer(text=footer or f"Bot Log • {category}")
    return embed


def log(title, description=None, *, category="general", fields=None,
        color=None, footer=None) -> bool:
    """Queue one log embed. Safe to call from any async command/listener."""
    if not is_active():
        return False
    if not _ensure_worker():
        return False
    embed = _embed(title, description, category, fields, color, footer)
    try:
        _queue.put_nowait({"embed": embed})
        return True
    except asyncio.QueueFull:
        _stats["dropped"] += 1
        return False


# ── ready-made events ────────────────────────────────────────────────
def command_used(ctx) -> bool:
    """Log a completed command run (prefix or slash)."""
    guild = getattr(ctx, "guild", None)
    channel = getattr(ctx, "channel", None)
    command = getattr(ctx, "command", None)
    name = getattr(command, "qualified_name", None) or "unknown"
    author = getattr(ctx, "author", None)
    fields = [
        ("User", f"{author.mention} (`{author.id}`)" if author else "—", False),
        ("Server", f"{guild.name} (`{guild.id}`)" if guild else "Direct message", False),
        ("Channel", f"{getattr(channel, 'mention', '#unknown')}", False),
    ]
    return log(f"⌨️ Command: {name}", category="command", fields=fields)


def ai_call(provider, model, prompt_chars, elapsed, ok=True, note=None) -> bool:
    """Log one AI request (chat / vision / image / ticket answer)."""
    status = "ok" if ok else "failed"
    fields = [
        ("Provider", provider or "—", True),
        ("Model", model or "—", True),
        ("Prompt", f"{prompt_chars} chars", True),
        ("Time", f"{elapsed:.1f}s" if elapsed is not None else "—", True),
        ("Status", status, True),
    ]
    if note:
        fields.append(("Note", note, False))
    color = COLORS["ai"] if ok else COLORS["error"]
    return log("🤖 AI Call", category="ai", fields=fields, color=color)


def ticket_event(action, guild=None, user=None, detail=None) -> bool:
    fields = [
        ("Action", action, True),
        ("Server", f"{guild.name} (`{guild.id}`)" if guild else "—", False),
        ("User", f"{user.mention} (`{user.id}`)" if user else "—", False),
    ]
    if detail:
        fields.append(("Details", detail, False))
    return log(f"🎫 Ticket {action}", category="ticket", fields=fields)


def bot_event(name, detail=None, ok=True) -> bool:
    return log(name, detail, category="event",
               color=COLORS["event"] if ok else COLORS["error"])


def error(where, exc) -> bool:
    text = f"```{type(exc).__name__}: {str(exc)[:700]}```"
    return log(f"⚠️ Error in {where}", text, category="error")
