﻿# â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
# â•‘                                                                  â•‘
# â•‘   â–‘â–ˆâ–€â–€â–‘â–ˆâ–€â–ˆâ–‘â–ˆâ–€â–„â–‘â–ˆâ–€â–€â–‘â–ˆâ–‘â–ˆ   â–‘â–ˆâ–€â–„â–‘â–ˆâ–€â–€â–‘â–ˆâ–‘â–ˆâ–‘â–ˆâ–€â–€                     â•‘
# â•‘   â–‘â–ˆâ–‘â–‘â–‘â–ˆâ–‘â–ˆâ–‘â–ˆâ–‘â–ˆâ–‘â–ˆâ–€â–€â–‘â–„â–€â–„   â–‘â–ˆâ–‘â–ˆâ–‘â–ˆâ–€â–€â–‘â–€â–„â–€â–‘â–€â–€â–ˆ                     â•‘
# â•‘   â–‘â–€â–€â–€â–‘â–€â–€â–€â–‘â–€â–€â–‘â–‘â–€â–€â–€â–‘â–€â–‘â–€   â–‘â–€â–€â–‘â–‘â–€â–€â–€â–‘â–‘â–€â–‘â–‘â–€â–€â–€                     â•‘
# â•‘                                                                  â•‘
# â•‘            Â© 2026 CodeX Devs â€” All Rights Reserved              â•‘
# â•‘                                                                  â•‘
# â•‘   discord  â”€â”€  https://discord.gg/34thSTQ2Sp                      â•‘
# â•‘   youtube  â”€â”€  https://youtube.com/@CodeXDevs                   â•‘
# â•‘   github   â”€â”€  https://github.com/RayExo                        â•‘
# â•‘                                                                  â•‘
# â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

"""
HTTPS Tunnel for the ZyroX API â€” Cloudflare Tunnel via pycloudflared.

Zero manual installs. Just:
  1. pip install pycloudflared  (already in requirements.txt)
  2. Get your tunnel token from the Cloudflare dashboard (browser only, no CLI)
  3. Set CF_TUNNEL_TOKEN in .env

That's it. The cloudflared binary is downloaded automatically on first run.

â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
How to get your CF_TUNNEL_TOKEN (browser only, no CLI needed)
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
1. Go to https://one.dash.cloudflare.com
2. Networks â†’ Tunnels â†’ Create a tunnel
3. Choose "Cloudflared" as connector type
4. Give it a name (e.g. zyrox-api) and click Save
5. On the "Install connector" step, find the token in the command shown:
      cloudflared tunnel run --token <YOUR_TOKEN_HERE>
   Copy just the token string.
6. Go to "Published Application Routes" tab â†’ Add a Published Application Routes:
      Subdomain: zyrox-api   Domain: yourdomain.com   Service: http://localhost:8000
   (Or use any domain you have on Cloudflare)
7. Paste the token into your .env:
      CF_TUNNEL_TOKEN = "eyJhIjoiX..."
      CF_TUNNEL_URL   = "https://zyrox-api.yourdomain.com"

That's the permanent URL â€” never changes between restarts.
Unlimited bandwidth, unlimited requests, free.
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
"""

import os
import time
import threading
import subprocess

# â”€â”€ env vars â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
TUNNEL_ENABLED = os.getenv("TUNNEL_ENABLED", "true").strip().lower() == "true"
CF_TUNNEL_TOKEN = os.getenv("CF_TUNNEL_TOKEN", "").strip()   # token from Cloudflare dashboard
CF_TUNNEL_URL   = os.getenv("CF_TUNNEL_URL", "").strip()     # e.g. https://api.yourdomain.com
API_PORT        = int(os.getenv("API_PORT", "8000"))

# â”€â”€ colours â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_CYAN   = "\033[36m"
_GREEN  = "\033[32m"
_YELLOW = "\033[33m"
_RED    = "\033[31m"
_RESET  = "\033[0m"


def _ensure_pycloudflared() -> bool:
    """Install pycloudflared via pip if it's not available. Returns True on success."""
    try:
        import pycloudflared  # noqa: F401
        return True
    except ImportError:
        pass

    print(f"{_YELLOW}â—ˆ Tunnel: pycloudflared not found â€” installing via pipâ€¦{_RESET}")
    try:
        result = subprocess.run(
            [__import__("sys").executable, "-m", "pip", "install", "pycloudflared"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=120,
            text=True,
        )
        if result.returncode == 0:
            print(f"{_GREEN}â—ˆ Tunnel: pycloudflared installed successfully.{_RESET}")
            return True
        else:
            print(f"{_RED}â—ˆ Tunnel: pip install failed:\n{result.stdout}{_RESET}")
            return False
    except Exception as exc:
        print(f"{_RED}â—ˆ Tunnel: could not install pycloudflared â€” {exc}{_RESET}")
        return False


def _download_cloudflared_direct() -> str | None:
    """
    Last-resort: download the cloudflared binary directly from GitHub
    into a local ./bin/ directory. Works even if pycloudflared fails.
    """
    import platform
    import urllib.request
    import stat

    system  = platform.system().lower()   # linux / darwin / windows
    machine = platform.machine().lower()  # x86_64 / aarch64 / arm64

    # Map to Cloudflare's release naming
    if system == "linux":
        if machine in ("aarch64", "arm64"):
            asset = "cloudflared-linux-arm64"
        elif machine == "arm":
            asset = "cloudflared-linux-arm"
        else:
            asset = "cloudflared-linux-amd64"
    elif system == "darwin":
        asset = "cloudflared-darwin-amd64"
    elif system == "windows":
        asset = "cloudflared-windows-amd64.exe"
    else:
        print(f"{_RED}â—ˆ Tunnel: unsupported OS '{system}' for direct download.{_RESET}")
        return None

    url = f"https://github.com/cloudflare/cloudflared/releases/latest/download/{asset}"
    bin_dir = os.path.join(os.path.dirname(__file__), "..", "bin")
    os.makedirs(bin_dir, exist_ok=True)
    dest = os.path.join(bin_dir, asset)

    if os.path.isfile(dest):
        # Already downloaded â€” just ensure it's executable
        pass
    else:
        print(f"{_YELLOW}â—ˆ Tunnel: downloading cloudflared binary from GitHubâ€¦{_RESET}")
        try:
            urllib.request.urlretrieve(url, dest)
            print(f"{_GREEN}â—ˆ Tunnel: downloaded to {dest}{_RESET}")
        except Exception as exc:
            print(f"{_RED}â—ˆ Tunnel: direct download failed â€” {exc}{_RESET}")
            return None

    # Fix execute bit
    try:
        current = os.stat(dest).st_mode
        os.chmod(dest, current | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    except OSError:
        pass

    return dest


def _get_binary() -> str | None:
    """
    Return a working path to the cloudflared binary.
    Strategy (in order):
      1. pycloudflared package  (auto-installs package if missing, triggers binary download)
      2. System PATH
      3. Direct GitHub download into ./bin/
    """
    import shutil
    import stat

    # â”€â”€ Step 0: make sure pycloudflared is installed â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    _ensure_pycloudflared()

    candidates: list[str] = []

    # â”€â”€ Step 1: ask pycloudflared for the binary â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    try:
        import pycloudflared as _pcf

        # cloudflared_path attribute (set after first download)
        path = getattr(_pcf, "cloudflared_path", None)
        if path:
            candidates.append(str(path))

        # Walk the package directory for any cloudflared file
        pkg_dir = os.path.dirname(_pcf.__file__)
        for fname in os.listdir(pkg_dir):
            full = os.path.join(pkg_dir, fname)
            if "cloudflared" in fname.lower() and os.path.isfile(full):
                candidates.append(full)

        # pycloudflared â‰¥ 0.2 exposes a download() helper
        if not candidates or not any(os.path.isfile(c) for c in candidates):
            download_fn = getattr(_pcf, "download", None)
            if callable(download_fn):
                print(f"{_YELLOW}â—ˆ Tunnel: triggering pycloudflared binary downloadâ€¦{_RESET}")
                try:
                    downloaded = download_fn()
                    if downloaded:
                        candidates.append(str(downloaded))
                except Exception:
                    pass

    except ImportError:
        pass

    # â”€â”€ Step 2: system PATH â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    sys_path = shutil.which("cloudflared")
    if sys_path:
        candidates.append(sys_path)

    # â”€â”€ Step 3: validate each candidate â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    for candidate in candidates:
        if not os.path.isfile(candidate):
            continue
        # Fix execute bit (common issue in Pterodactyl containers)
        try:
            current = os.stat(candidate).st_mode
            if not (current & stat.S_IXUSR):
                os.chmod(candidate, current | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except OSError:
            pass
        # Smoke-test
        try:
            result = subprocess.run(
                [candidate, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=5,
            )
            if result.returncode == 0:
                return candidate
        except (OSError, subprocess.TimeoutExpired):
            continue

    # â”€â”€ Step 4: direct GitHub download as last resort â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print(f"{_YELLOW}â—ˆ Tunnel: no working binary found â€” attempting direct downloadâ€¦{_RESET}")
    direct = _download_cloudflared_direct()
    if direct and os.path.isfile(direct):
        try:
            result = subprocess.run(
                [direct, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=5,
            )
            if result.returncode == 0:
                return direct
        except (OSError, subprocess.TimeoutExpired):
            pass

    return None


def _run_tunnel(binary: str, token: str, port: int, public_url: str) -> None:
    """
    Blocking loop â€” runs:
      cloudflared tunnel --no-autoupdate run --token <token>
    Restarts automatically if the process exits.
    """
    cmd = [
        binary,
        "tunnel",
        "--no-autoupdate",
        "--url", f"http://localhost:{port}",
        "run",
        "--token", token,
    ]

    first_run = True
    while True:
        if first_run:
            print(f"{_CYAN}â—ˆ Tunnel: connecting to Cloudflareâ€¦{_RESET}")
            first_run = False
        else:
            print(f"{_YELLOW}â—ˆ Tunnel: reconnectingâ€¦{_RESET}")

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )

            announced = False
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue

                # Only surface important lines â€” suppress the noisy info spam
                low = line.lower()
                if any(k in low for k in ("error", "warn", "registered", "connected", "failed", "unable")):
                    print(f"{_CYAN}  [cloudflared] {line}{_RESET}")

                # Announce the live URL once the tunnel is up
                if not announced and ("registered tunnel connection" in low or "connection registered" in low):
                    announced = True
                    if public_url:
                        print(f"{_GREEN}â—ˆ Tunnel: API is live at  {public_url}{_RESET}")
                        print(f"{_CYAN}  â†³ NEXT_PUBLIC_API_URL = {public_url}/api/v1{_RESET}")
                    else:
                        print(f"{_GREEN}â—ˆ Tunnel: connected â€” check CF_TUNNEL_URL in .env for your public URL{_RESET}")

            proc.wait()
            code = proc.returncode

        except (FileNotFoundError, PermissionError) as exc:
            print(f"{_RED}â—ˆ Tunnel: failed to execute binary at '{binary}' â€” {exc}{_RESET}")
            print(f"{_RED}  Check: file exists, has execute permission, and matches the server OS/arch.{_RESET}")
            return
        except Exception as exc:
            print(f"{_RED}â—ˆ Tunnel: unexpected error â€” {exc}{_RESET}")
            code = -1

        print(f"{_YELLOW}â—ˆ Tunnel: exited (code {code}), restarting in 5 sâ€¦{_RESET}")
        time.sleep(5)


def start_tunnel() -> None:
    """
    Start the Cloudflare Tunnel in a background daemon thread.
    Called from CodeX.py after keep_alive().
    """
    if not TUNNEL_ENABLED:
        print(f"{_YELLOW}â—ˆ Tunnel: disabled via TUNNEL_ENABLED=false{_RESET}")
        return

    if not CF_TUNNEL_TOKEN:
        print(
            f"{_YELLOW}â—ˆ Tunnel: CF_TUNNEL_TOKEN is not set â€” tunnel skipped.\n"
            f"  Get your token from https://one.dash.cloudflare.com â†’ Networks â†’ Tunnels{_RESET}"
        )
        return

    binary = _get_binary()
    if not binary:
        print(
            f"{_RED}â—ˆ Tunnel: could not obtain a working cloudflared binary after all attempts.\n"
            f"  Tunnel will not start. Check your network or install manually:\n"
            f"  pip install pycloudflared{_RESET}"
        )
        return

    print(f"{_CYAN}â—ˆ Tunnel: cloudflared binary ready â€” starting tunnel on port {API_PORT}â€¦{_RESET}")
    t = threading.Thread(target=_run_tunnel, args=(binary, CF_TUNNEL_TOKEN, API_PORT, CF_TUNNEL_URL), daemon=True)
    t.start()

