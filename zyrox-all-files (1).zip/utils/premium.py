"""Tiered premium plans, plan limits, purchase orders and usage tracking.

Everything money related lives in ``db/premium.db``:

* ``guild_plans``   – the active plan of a guild (expiry included)
* ``premium_orders``– orders created by the /premium buy flow
* ``order_servers`` – extra servers covered by one Premium+ order
* ``premium_usage`` – counters for countable limits (embeds, ...)
* ``ai_daily``      – AI chat replies per guild per day
* ``referrals``     – successful Premium+ referrals (each gives one server slot)
* ``premium_keys``  – redeemable activation keys (plan, days, uses)
* ``premium_key_uses`` – which server redeemed which key
"""

from __future__ import annotations

import asyncio
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone

import aiosqlite

DB_PATH = os.path.join("db", "premium.db")

FREE = "free"
PREMIUM = "premium"
PREMIUM_PLUS = "premium_plus"
PLAN_ORDER = (FREE, PREMIUM, PREMIUM_PLUS)

SUBSCRIPTION_DAYS = 30


def _env_int(name: str, default: int = 0) -> int:
    raw = (os.getenv(name) or "").strip()
    return int(raw) if raw.lstrip("-").isdigit() else default


def _env_str(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()


# ── Payment / purchase configuration ─────────────────────────────────────────
# UPI_ID and UPI_QR_URL are shown on the checkout screen. SUPPORT_GUILD_ID,
# SALES_ROLE_ID and ORDERS_CATEGORY_ID decide where an order ticket is opened.
UPI_ID = _env_str("UPI_ID")
UPI_QR_URL = _env_str("UPI_QR_URL")
SUPPORT_GUILD_ID = _env_int("SUPPORT_GUILD_ID")
SALES_ROLE_ID = _env_int("SALES_ROLE_ID")
ORDERS_CATEGORY_ID = _env_int("ORDERS_CATEGORY_ID")
SUPPORT_INVITE = _env_str("SUPPORT_INVITE", "https://discord.gg/34thSTQ2Sp")


# ── Plan catalog ─────────────────────────────────────────────────────────────
# ``None`` means unlimited. The Premium+ numbers are the only hard caps on that
# plan: 5 panels and 4 server slots (+1 slot per successful referral).
PLANS = {
    FREE: {
        "key": FREE,
        "name": "Free",
        "price": 0,
        "limits": {
            "custom_commands": 10,
            "automod_rules": 5,
            "ticket_panels": 1,
            "giveaways": 1,
            "embeds": 5,
            "reminders": 10,
            "temp_voice": 3,
            "servers": 1,
            "ai_chat_per_day": 10,
            "ai_ticket_replies_per_month": 0,
            "shop_items": 5,
            "rep_per_day": 3,
            "starboard_threshold": 3,
            "tempban_days": 7,
            "pets": 1,
        },
        "perks": (
            "Core moderation & anti-nuke",
            "Basic AutoMod rules",
            "7-day logs",
            "FAQ auto-answers in tickets",
            "30-day transcripts",
            "~10 AI chat replies a day",
        ),
    },
    PREMIUM: {
        "key": PREMIUM,
        "name": "Premium",
        "price": 129,
        "limits": {
            "custom_commands": 100,
            "automod_rules": 30,
            "ticket_panels": 3,
            "giveaways": 10,
            "embeds": 50,
            "reminders": 100,
            "temp_voice": 25,
            "servers": 1,
            "ai_chat_per_day": 1000,
            "ai_ticket_replies_per_month": 300,
            "shop_items": 40,
            "rep_per_day": 10,
            "starboard_threshold": 2,
            "tempban_days": 30,
            "pets": 2,
        },
        "perks": (
            "Advanced logging (90 days)",
            "Advanced analytics",
            "Extra AutoMod rule types",
            "Suspicious-account rules",
            "CAPTCHA & giveaway requirements",
            "Custom branding & welcome images",
            "AI inside tickets, summaries & draft replies",
            "Music: 200-song queue, 24/7",
            "Permanent branded transcripts",
            "Dashboard editing",
        ),
    },
    PREMIUM_PLUS: {
        "key": PREMIUM_PLUS,
        "name": "Premium+",
        "price": 199,
        "limits": {
            "custom_commands": None,
            "automod_rules": None,
            "ticket_panels": 5,
            "giveaways": None,
            "embeds": None,
            "reminders": None,
            "temp_voice": None,
            "servers": 4,
            "ai_chat_per_day": None,
            "ai_ticket_replies_per_month": None,
            "shop_items": None,
            "rep_per_day": None,
            "starboard_threshold": 1,
            "tempban_days": None,
            "pets": 3,
        },
        "perks": (
            "Unlimited everything except 5 panels & 4 server slots",
            "One extra server slot per successful referral",
            "Unlimited AI tickets",
            "Activity analytics with charts",
            "Exclusive badge",
            "Early access to new features",
            "Priority support",
        ),
    },
}

PLAN_LABELS = {key: plan["name"] for key, plan in PLANS.items()}
PLAN_PRICES = {key: plan["price"] for key, plan in PLANS.items()}

LIMIT_LABELS = {
    "custom_commands": "Custom commands",
    "automod_rules": "AutoMod rules",
    "ticket_panels": "Ticket panels",
    "giveaways": "Giveaways",
    "embeds": "Embeds",
    "reminders": "Reminders",
    "temp_voice": "Temp voice",
    "servers": "Servers",
    "ai_chat_per_day": "AI chat replies / day",
    "ai_ticket_replies_per_month": "AI ticket replies / month",
    "shop_items": "Economy shop items",
    "rep_per_day": "Reputation given / day",
    "starboard_threshold": "Starboard threshold",
    "tempban_days": "Tempban length / days",
    "pets": "Pets per member",
}

_locks = asyncio.Lock()
_initialized = False
_ai_notified: set[tuple[int, str]] = set()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(moment: datetime | None = None) -> str:
    return (moment or _now()).isoformat()


def _today() -> str:
    return _now().strftime("%Y-%m-%d")


async def _connect() -> aiosqlite.Connection:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    db = await aiosqlite.connect(DB_PATH)
    db.row_factory = aiosqlite.Row
    return db


async def init() -> None:
    global _initialized
    if _initialized:
        return
    async with _locks:
        if _initialized:
            return
        db = await _connect()
        try:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS guild_plans (
                    guild_id INTEGER PRIMARY KEY,
                    plan TEXT NOT NULL DEFAULT 'free',
                    expires_at TEXT,
                    order_id TEXT,
                    updated_at TEXT
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS premium_orders (
                    order_id TEXT PRIMARY KEY,
                    guild_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    plan TEXT NOT NULL,
                    amount INTEGER NOT NULL,
                    method TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    screenshot_url TEXT,
                    note TEXT,
                    origin_channel_id INTEGER,
                    ticket_channel_id INTEGER,
                    created_at TEXT,
                    paid_at TEXT,
                    paid_by INTEGER
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS order_servers (
                    order_id TEXT NOT NULL,
                    guild_id INTEGER NOT NULL,
                    added_at TEXT,
                    PRIMARY KEY (order_id, guild_id)
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS premium_usage (
                    guild_id INTEGER NOT NULL,
                    feature TEXT NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT,
                    PRIMARY KEY (guild_id, feature)
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS ai_daily (
                    guild_id INTEGER NOT NULL,
                    day TEXT NOT NULL,
                    replies INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (guild_id, day)
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS premium_keys (
                    code TEXT PRIMARY KEY,
                    plan TEXT NOT NULL,
                    days INTEGER NOT NULL DEFAULT 30,
                    max_uses INTEGER NOT NULL DEFAULT 1,
                    uses INTEGER NOT NULL DEFAULT 0,
                    revoked INTEGER NOT NULL DEFAULT 0,
                    note TEXT,
                    created_by INTEGER,
                    created_at TEXT
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS premium_key_uses (
                    code TEXT NOT NULL,
                    guild_id INTEGER NOT NULL,
                    user_id INTEGER,
                    plan TEXT,
                    expires_at TEXT,
                    redeemed_at TEXT,
                    PRIMARY KEY (code, guild_id)
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS referrals (
                    guild_id INTEGER NOT NULL,
                    referrer_id INTEGER NOT NULL,
                    referred_guild_id INTEGER,
                    created_at TEXT,
                    PRIMARY KEY (guild_id, referrer_id)
                )
                """
            )
            await db.commit()
            _initialized = True
        finally:
            await db.close()


def format_limit(value: int | None) -> str:
    return "∞" if value is None else str(value)


def format_price(amount: int) -> str:
    return f"Rs {amount}"


# ── Plan lookups ─────────────────────────────────────────────────────────────
async def _plan_row(guild_id: int) -> aiosqlite.Row | None:
    await init()
    db = await _connect()
    try:
        async with db.execute(
            "SELECT plan, expires_at, order_id FROM guild_plans WHERE guild_id = ?", (guild_id,)
        ) as cur:
            return await cur.fetchone()
    finally:
        await db.close()


async def get_plan_key(guild_id: int) -> str:
    row = await _plan_row(guild_id)
    if not row:
        return FREE
    key = row["plan"] if row["plan"] in PLANS else FREE
    expires = row["expires_at"]
    if key != FREE and expires:
        try:
            if datetime.fromisoformat(expires) <= _now():
                return FREE
        except ValueError:
            return FREE
    return key


async def get_expiry(guild_id: int) -> datetime | None:
    row = await _plan_row(guild_id)
    if not row or not row["expires_at"]:
        return None
    try:
        return datetime.fromisoformat(row["expires_at"])
    except ValueError:
        return None


async def get_plan(guild_id: int) -> dict:
    return PLANS[await get_plan_key(guild_id)]


async def referral_bonus(guild_id: int) -> int:
    return await _count_row(
        "SELECT COUNT(*) FROM referrals WHERE guild_id = ?", (guild_id,)
    )


async def get_limits(guild_id: int) -> dict:
    plan = await get_plan(guild_id)
    limits = dict(plan["limits"])
    if plan["key"] == PREMIUM_PLUS:
        limits["servers"] = 4 + await referral_bonus(guild_id)
    return limits


async def limit_for(guild_id: int, feature: str) -> int | None:
    return (await get_limits(guild_id)).get(feature)


async def is_paid(guild_id: int) -> bool:
    return (await get_plan_key(guild_id)) != FREE


async def activate(
    guild_id: int,
    plan_key: str,
    days: int = SUBSCRIPTION_DAYS,
    order_id: str | None = None,
    expires_at: str | None = None,
) -> datetime:
    """Give ``guild_id`` a plan. Returns the new expiry."""
    await init()
    if plan_key not in PLANS:
        raise ValueError(f"Unknown plan: {plan_key}")
    expiry = datetime.fromisoformat(expires_at) if expires_at else _now() + timedelta(days=days)
    db = await _connect()
    try:
        await db.execute(
            """
            INSERT INTO guild_plans (guild_id, plan, expires_at, order_id, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET
                plan = excluded.plan,
                expires_at = excluded.expires_at,
                order_id = COALESCE(excluded.order_id, guild_plans.order_id),
                updated_at = excluded.updated_at
            """,
            (guild_id, plan_key, expiry.isoformat(), order_id, _iso()),
        )
        await db.commit()
    finally:
        await db.close()
    return expiry


async def revoke(guild_id: int, plan_key: str = FREE) -> None:
    await activate(guild_id, plan_key, expires_at=_now().isoformat())


# ── Usage counters ───────────────────────────────────────────────────────────
async def _count_row(sql: str, params: tuple = ()) -> int:
    await init()
    db = await _connect()
    try:
        async with db.execute(sql, params) as cur:
            row = await cur.fetchone()
        return int(row[0]) if row else 0
    finally:
        await db.close()


async def count_rows(path: str, sql: str, params: tuple = ()) -> int:
    """Read-only COUNT against another cog's database (never creates it)."""
    if not os.path.exists(path):
        return 0
    try:
        async with aiosqlite.connect(f"file:{path}?mode=ro", uri=True) as db:
            async with db.execute(sql, params) as cur:
                row = await cur.fetchone()
        return int(row[0]) if row else 0
    except Exception:
        return 0


async def get_usage(guild_id: int, feature: str) -> int:
    return await _count_row(
        "SELECT used FROM premium_usage WHERE guild_id = ? AND feature = ?", (guild_id, feature)
    )


async def consume(guild_id: int, feature: str, amount: int = 1) -> tuple[bool, int, int | None]:
    """Consume ``amount`` units of a counter. Returns (allowed, used, limit)."""
    limit = await limit_for(guild_id, feature)
    used = await get_usage(guild_id, feature)
    if limit is not None and used + amount > limit:
        return False, used, limit
    await init()
    db = await _connect()
    try:
        await db.execute(
            """
            INSERT INTO premium_usage (guild_id, feature, used, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(guild_id, feature) DO UPDATE SET
                used = used + excluded.used,
                updated_at = excluded.updated_at
            """,
            (guild_id, feature, amount, _iso()),
        )
        await db.commit()
    finally:
        await db.close()
    return True, used + amount, limit


async def check_capacity(guild_id: int, feature: str, used: int) -> tuple[bool, int, int | None]:
    limit = await limit_for(guild_id, feature)
    return (limit is None or used < limit), used, limit


# ── AI counters ──────────────────────────────────────────────────────────────
async def ai_used_today(guild_id: int) -> int:
    return await _count_row(
        "SELECT replies FROM ai_daily WHERE guild_id = ? AND day = ?", (guild_id, _today())
    )


async def ai_remaining(guild_id: int) -> int | None:
    limit = await limit_for(guild_id, "ai_chat_per_day")
    if limit is None:
        return None
    used = await ai_used_today(guild_id)
    return max(0, limit - used)


async def consume_ai(guild_id: int) -> tuple[bool, int, int | None]:
    """Count one AI chat reply. Returns (allowed, used, limit)."""
    limit = await limit_for(guild_id, "ai_chat_per_day")
    used = await ai_used_today(guild_id)
    if limit is not None and used >= limit:
        return False, used, limit
    await init()
    db = await _connect()
    try:
        await db.execute(
            """
            INSERT INTO ai_daily (guild_id, day, replies)
            VALUES (?, ?, 1)
            ON CONFLICT(guild_id, day) DO UPDATE SET replies = replies + 1
            """,
            (guild_id, _today()),
        )
        await db.commit()
    finally:
        await db.close()
    return True, used + 1, limit


def ai_limit_notice_pending(guild_id: int) -> bool:
    """True the first time a guild is told it ran out of AI replies today."""
    key = (guild_id, _today())
    if key in _ai_notified:
        return False
    _ai_notified.add(key)
    return True


# ── Order lifecycle ──────────────────────────────────────────────────────────
def new_order_id() -> str:
    return f"ZX-{uuid.uuid4().hex[:8].upper()}"


async def create_order(
    guild_id: int,
    user_id: int,
    plan_key: str,
    method: str,
    origin_channel_id: int | None = None,
    note: str | None = None,
) -> dict:
    await init()
    order_id = new_order_id()
    amount = PLAN_PRICES.get(plan_key, 0)
    db = await _connect()
    try:
        await db.execute(
            """
            INSERT INTO premium_orders
                (order_id, guild_id, user_id, plan, amount, method, status,
                 note, origin_channel_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
            """,
            (order_id, guild_id, user_id, plan_key, amount, method, note, origin_channel_id, _iso()),
        )
        await db.commit()
    finally:
        await db.close()
    return await get_order(order_id)


def _order_dict(row: aiosqlite.Row | None) -> dict | None:
    return dict(row) if row else None


async def get_order(order_id: str) -> dict | None:
    await init()
    db = await _connect()
    try:
        async with db.execute("SELECT * FROM premium_orders WHERE order_id = ?", (order_id,)) as cur:
            row = await cur.fetchone()
        return _order_dict(row)
    finally:
        await db.close()


async def set_order_screenshot(order_id: str, url: str) -> None:
    await _execute("UPDATE premium_orders SET screenshot_url = ? WHERE order_id = ?", (url, order_id))


async def set_order_ticket(order_id: str, channel_id: int) -> None:
    await _execute(
        "UPDATE premium_orders SET ticket_channel_id = ? WHERE order_id = ?", (channel_id, order_id)
    )


async def mark_paid(order_id: str, paid_by: int | None) -> dict | None:
    """Mark an order paid and start its 30 days. Returns the updated order."""
    await init()
    order = await get_order(order_id)
    if not order:
        return None
    if order["status"] != "paid":
        await _execute(
            "UPDATE premium_orders SET status = 'paid', paid_at = ?, paid_by = ? WHERE order_id = ?",
            (_iso(), paid_by, order_id),
        )
        await activate(order["guild_id"], order["plan"], SUBSCRIPTION_DAYS, order_id)
        await add_order_server(order_id, order["guild_id"])
    return await get_order(order_id)


async def _execute(sql: str, params: tuple) -> None:
    await init()
    db = await _connect()
    try:
        await db.execute(sql, params)
        await db.commit()
    finally:
        await db.close()


async def pending_orders(limit: int = 15) -> list[dict]:
    await init()
    db = await _connect()
    try:
        async with db.execute(
            "SELECT * FROM premium_orders WHERE status = 'pending' ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ) as cur:
            return [dict(row) for row in await cur.fetchall()]
    finally:
        await db.close()


async def add_order_server(order_id: str, guild_id: int) -> bool:
    await _execute(
        "INSERT OR IGNORE INTO order_servers (order_id, guild_id, added_at) VALUES (?, ?, ?)",
        (order_id, guild_id, _iso()),
    )
    return True


async def order_server_count(order_id: str) -> int:
    return await _count_row("SELECT COUNT(*) FROM order_servers WHERE order_id = ?", (order_id,))


async def order_guild_ids(order_id: str) -> list[int]:
    await init()
    db = await _connect()
    try:
        async with db.execute(
            "SELECT guild_id FROM order_servers WHERE order_id = ? ORDER BY added_at", (order_id,)
        ) as cur:
            return [int(row["guild_id"]) for row in await cur.fetchall()]
    finally:
        await db.close()


async def active_order_for_guild(guild_id: int) -> dict | None:
    row = await _plan_row(guild_id)
    if not row or not row["order_id"]:
        return None
    order = await get_order(row["order_id"])
    if not order or order["status"] != "paid":
        return None
    return order


async def record_referral(guild_id: int, referrer_id: int) -> bool:
    await init()
    db = await _connect()
    try:
        cur = await db.execute(
            "INSERT OR IGNORE INTO referrals (guild_id, referrer_id, created_at) VALUES (?, ?, ?)",
            (guild_id, referrer_id, _iso()),
        )
        await db.commit()
        return cur.rowcount > 0
    finally:
        await db.close()


# ── Premium keys ─────────────────────────────────────────────────────────────
# A key is a 16-character code such as ``ZXAB-CD2F-GH3K-LM9P``. Staff generate
# them for a plan and a number of days; a server admin redeems one with
# ``/premium keyredeem`` and the plan starts immediately.
KEY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def normalize_key(code: str) -> str:
    """Uppercase letters/digits only, so dashes and spaces do not matter."""
    return "".join(ch for ch in (code or "").upper() if ch.isalnum())


def format_key(code: str) -> str:
    norm = normalize_key(code)
    return "-".join(norm[i:i + 4] for i in range(0, len(norm), 4))


def _random_code() -> str:
    return "ZX" + "".join(secrets.choice(KEY_ALPHABET) for _ in range(14))


async def create_keys(
    plan_key: str,
    days: int = SUBSCRIPTION_DAYS,
    count: int = 1,
    max_uses: int = 1,
    created_by: int | None = None,
    note: str | None = None,
) -> list[str]:
    """Create ``count`` new keys. Returns the plain codes (without dashes)."""
    if plan_key not in PLANS or plan_key == FREE:
        raise ValueError("Keys can only be created for paid plans.")
    days = max(1, min(int(days), 3650))
    count = max(1, min(int(count), 25))
    max_uses = max(1, min(int(max_uses), 50))
    await init()
    codes: list[str] = []
    db = await _connect()
    try:
        while len(codes) < count:
            code = _random_code()
            cur = await db.execute(
                """
                INSERT OR IGNORE INTO premium_keys
                    (code, plan, days, max_uses, uses, revoked, note, created_by, created_at)
                VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)
                """,
                (code, plan_key, days, max_uses, note, created_by, _iso()),
            )
            if cur.rowcount:
                codes.append(code)
        await db.commit()
    finally:
        await db.close()
    return codes


async def get_key(code: str) -> dict | None:
    norm = normalize_key(code)
    if not norm:
        return None
    await init()
    db = await _connect()
    try:
        async with db.execute("SELECT * FROM premium_keys WHERE code = ?", (norm,)) as cur:
            row = await cur.fetchone()
    finally:
        await db.close()
    if not row:
        return None
    data = dict(row)
    data["remaining"] = max(0, int(data["max_uses"]) - int(data["uses"]))
    data["active"] = not data["revoked"] and data["remaining"] > 0
    return data


async def list_keys(limit: int = 20, include_dead: bool = False) -> list[dict]:
    await init()
    sql = "SELECT * FROM premium_keys"
    if not include_dead:
        sql += " WHERE revoked = 0 AND uses < max_uses"
    sql += " ORDER BY created_at DESC LIMIT ?"
    db = await _connect()
    try:
        async with db.execute(sql, (limit,)) as cur:
            rows = [dict(row) for row in await cur.fetchall()]
    finally:
        await db.close()
    for row in rows:
        row["remaining"] = max(0, int(row["max_uses"]) - int(row["uses"]))
    return rows


async def revoke_key(code: str) -> bool:
    norm = normalize_key(code)
    if not norm:
        return False
    await init()
    db = await _connect()
    try:
        cur = await db.execute("UPDATE premium_keys SET revoked = 1 WHERE code = ?", (norm,))
        await db.commit()
        return cur.rowcount > 0
    finally:
        await db.close()


async def key_use_rows(code: str, limit: int = 20) -> list[dict]:
    await init()
    db = await _connect()
    try:
        async with db.execute(
            "SELECT * FROM premium_key_uses WHERE code = ? ORDER BY redeemed_at DESC LIMIT ?",
            (normalize_key(code), limit),
        ) as cur:
            return [dict(row) for row in await cur.fetchall()]
    finally:
        await db.close()


async def redeem_key(
    code: str, guild_id: int, user_id: int | None = None
) -> tuple[bool, str, dict | None]:
    """Redeem a key on ``guild_id``. Returns (ok, error, details)."""
    key = await get_key(code)
    if not key:
        return False, "That key does not exist. Check the code and try again.", None
    if key["revoked"]:
        return False, "That key has been revoked.", None
    if key["remaining"] <= 0:
        return False, "That key has already been used up.", None

    await init()
    db = await _connect()
    try:
        async with db.execute(
            "SELECT 1 FROM premium_key_uses WHERE code = ? AND guild_id = ?",
            (key["code"], guild_id),
        ) as cur:
            already = await cur.fetchone() is not None
        if already:
            return False, "This server has already redeemed that key.", None
        cur = await db.execute(
            "UPDATE premium_keys SET uses = uses + 1 WHERE code = ? AND revoked = 0 AND uses < max_uses",
            (key["code"],),
        )
        if not cur.rowcount:
            await db.rollback()
            return False, "That key has already been used up.", None
        await db.commit()
    finally:
        await db.close()

    now = _now()
    base = now
    if await get_plan_key(guild_id) == key["plan"]:
        current_expiry = await get_expiry(guild_id)
        if current_expiry and current_expiry > now:
            base = current_expiry
    expiry = await activate(
        guild_id, key["plan"], expires_at=(base + timedelta(days=int(key["days"]))).isoformat()
    )

    await _execute(
        """
        INSERT OR REPLACE INTO premium_key_uses
            (code, guild_id, user_id, plan, expires_at, redeemed_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (key["code"], guild_id, user_id, key["plan"], expiry.isoformat(), _iso()),
    )
    return True, "", {
        "code": key["code"],
        "plan": key["plan"],
        "days": int(key["days"]),
        "expiry": expiry,
        "remaining": max(0, int(key["remaining"]) - 1),
        "max_uses": int(key["max_uses"]),
    }


# ── Dashboard snapshot ───────────────────────────────────────────────────────
async def usage_snapshot(guild_id: int) -> list[tuple[str, int, int | None]]:
    """Live counters for the help menu / premium screen: (label, used, limit)."""
    limits = await get_limits(guild_id)
    rows = [
        ("custom_commands", await count_rows("db/tags.db", "SELECT COUNT(*) FROM tags WHERE guild_id = ?", (guild_id,))),
        ("automod_rules", await count_rows("db/automod.db", "SELECT COUNT(*) FROM automod_punishments WHERE guild_id = ?", (guild_id,))),
        ("ticket_panels", await count_rows("db/ticket.db", "SELECT COUNT(*) FROM ticket_panels WHERE guild_id = ?", (guild_id,))),
        ("giveaways", await count_rows("db/giveaways.db", "SELECT COUNT(*) FROM Giveaway WHERE guild_id = ?", (guild_id,))),
        ("embeds", await get_usage(guild_id, "embeds")),
        ("temp_voice", await count_rows("j2c_data.db", "SELECT COUNT(*) FROM private_channels WHERE guild_id = ?", (guild_id,))),
        ("ai_chat_per_day", await ai_used_today(guild_id)),
    ]
    return [(LIMIT_LABELS[key], used, limits.get(key)) for key, used in rows]


async def usage_line(guild_id: int) -> str:
    rows = await usage_snapshot(guild_id)
    return " · ".join(f"{label}: **{used} / {format_limit(limit)}**" for label, used, limit in rows)
