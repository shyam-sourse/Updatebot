"""Shared premium UI pieces: upgrade buttons and limit-reached notices."""

from __future__ import annotations

import discord

from utils import premium

COLOR = 0xFF0000


class UpgradeButton(discord.ui.Button):
    """Opens the /premium screen. Kept import-light to avoid module cycles."""

    def __init__(self, label: str = "Upgrade", **kwargs):
        super().__init__(
            label=label,
            emoji="✨",
            style=discord.ButtonStyle.success,
            **kwargs,
        )

    async def callback(self, interaction: discord.Interaction):
        from cogs.commands.premium import open_premium

        await open_premium(interaction)


def upgrade_button(label: str = "Upgrade") -> UpgradeButton:
    return UpgradeButton(label)


def limit_embed(feature: str, used: int, limit: int | None, plan_name: str | None = None) -> discord.Embed:
    label = premium.LIMIT_LABELS.get(feature, feature.replace("_", " ").title())
    current = plan_name or "Free"
    embed = discord.Embed(
        title="Limit reached",
        description=(
            f"Your **{current}** plan allows **{premium.format_limit(limit)} {label.lower()}** "
            f"and you're already using **{used} / {premium.format_limit(limit)}**.\n\n"
            "Upgrade to raise this limit — you keep everything you already set up."
        ),
        color=COLOR,
    )
    embed.set_footer(text="Use /premium to compare plans or renew.")
    return embed


def limit_view(feature: str, used: int, limit: int | None, plan_name: str | None = None) -> discord.ui.View:
    view = discord.ui.View(timeout=300)
    view.add_item(upgrade_button("Upgrade"))
    view.add_item(
        discord.ui.Button(
            label="Compare plans",
            style=discord.ButtonStyle.link,
            url=premium.SUPPORT_INVITE,
        )
    )
    return view


async def send_limit(
    target,
    feature: str,
    used: int,
    limit: int | None,
    guild_id: int | None = None,
):
    """Send the red limit notice with an upgrade button.

    ``target`` may be a Context, an Interaction, or a Messageable channel.
    """
    plan_name = None
    if guild_id is not None:
        plan_name = (await premium.get_plan(guild_id))["name"]

    embed = limit_embed(feature, used, limit, plan_name)
    view = limit_view(feature, used, limit, plan_name)

    if isinstance(target, discord.Interaction):
        if target.response.is_done():
            return await target.followup.send(embed=embed, view=view, ephemeral=True)
        return await target.response.send_message(embed=embed, view=view, ephemeral=True)

    return await target.send(embed=embed, view=view)

