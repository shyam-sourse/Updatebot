# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 CodeX Devs — All Rights Reserved              ║
# ║                                                                  ║
# ║   AI backend: FreeLLMAPI  (the only AI backend)                  ║
# ║   FREELLM_API_URL • FREELLM_API_KEY • FREELLM_MODEL              ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝
"""Every AI call in the bot funnels through this module.

The backend is a single OpenAI-compatible endpoint configured with
``FREELLM_API_URL`` / ``FREELLM_API_KEY`` / ``FREELLM_MODEL`` and implemented
in :mod:`utils.freellm`. Groq (and the old Gemini code) has been removed
completely — there is no second provider and no key rotation any more.
"""

import aiohttp
import base64
import io
import time
import os
import random
import json
import asyncio
import logging
from types import SimpleNamespace
from langdetect import detect
from gtts import gTTS
from urllib.parse import quote
from utils.config_loader import load_current_language, config
try:
    from duckduckgo_search import AsyncDDGS
except ImportError:
    from ddgs import AsyncDDGS
from dotenv import load_dotenv

load_dotenv()

current_language = load_current_language()
internet_access = config.get('INTERNET_ACCESS', True)


logger = logging.getLogger("discord")

from utils import freellm

#: one error type for every AI failure (old names kept as aliases)
AIError = freellm.FreeLLMError
GroqError = AIError
GeminiError = AIError
GroqAPIError = AIError

#: User-facing text for a failure reason ("no_keys", "quota", "rate_limit", ...)
error_message = freellm.message_for

#: the model this bot asks for when a caller does not pick one
def _configured_model():
    raw = config.get("MODEL_ID") or config.get("FREELLM_MODEL")
    if not raw:
        return None
    raw = str(raw)
    if raw.lower().startswith(("gemini", "models/gemini", "gpt-3.5")):
        return None
    return raw


def default_model():
    """FREELLM_MODEL when set, else config.yml MODEL_ID, else freellm default."""
    return _configured_model() or freellm.model_for()


def is_configured():
    """True when the FreeLLMAPI endpoint is set, so AI features can run."""
    return freellm.is_configured()


def status_line():
    """One-line backend summary for owner commands / logs."""
    return freellm.status_line()


class _Completion:
    """OpenAI-style response object so every existing caller
    (response.choices[0].message.content) keeps working unchanged."""

    def __init__(self, content, tool_calls=None, raw=None):
        message = SimpleNamespace(
            role="assistant",
            content=content,
            tool_calls=tool_calls or None,
        )
        self.choices = [SimpleNamespace(message=message, finish_reason=None)]
        self.raw = raw

    @property
    def text(self):
        """Convenience alias - the old Gemini responses exposed `.text`."""
        return self.choices[0].message.content


def _wrap_tool_calls(raw_calls):
    calls = []
    for call in raw_calls or []:
        fn = call.get("function", {}) or {}
        calls.append(
            SimpleNamespace(
                id=call.get("id"),
                type=call.get("type", "function"),
                function=SimpleNamespace(
                    name=fn.get("name"),
                    arguments=fn.get("arguments") or "{}",
                ),
            )
        )
    return calls or None


def _clean_messages(messages):
    """Normalise the bot's message history into the OpenAI schema."""
    cleaned = []
    for msg in messages:
        if not isinstance(msg, dict):
            msg = {"role": "user", "content": str(msg)}
        role = msg.get("role", "user")
        if role in ("model", "bot"):
            role = "assistant"
        item = {"role": role, "content": msg.get("content", "") or ""}
        # tool plumbing must be preserved verbatim
        if msg.get("tool_calls"):
            item["tool_calls"] = msg["tool_calls"]
        if msg.get("tool_call_id"):
            item["tool_call_id"] = msg["tool_call_id"]
        if msg.get("name") and role in ("tool", "function"):
            item["name"] = msg["name"]
        if not item["content"] and not item.get("tool_calls"):
            continue
        cleaned.append(item)
    return cleaned


def _build_completion(data):
    """Turn a raw OpenAI-style response into the bot's `_Completion`."""
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message", {}) or {}
    text = freellm.message_text(message)
    calls = _wrap_tool_calls(message.get("tool_calls"))
    if not text and not calls:
        raise RuntimeError("Empty response from model")
    return _Completion(text, calls, raw=data)


def _log_ai(prompt_chars, started, model, ok=True, note=None):
    """Report the call in the owner's global bot-log channel."""
    try:
        from utils import botlog
        botlog.ai_call("FreeLLMAPI", model, prompt_chars,
                       time.time() - started, ok=ok, note=note)
    except Exception as log_error:  # never break an AI call because of logging
        logger.warning(f"[botlog] AI log failed: {log_error}")


async def chat_completion(model=None, messages=None, tools=None, **kwargs):
    """Send a chat completion to the configured FreeLLMAPI endpoint.

    - The endpoint comes from ``FREELLM_API_URL`` (base URL or full
      ``/chat/completions`` URL), the key from ``FREELLM_API_KEY`` and the
      model from ``FREELLM_MODEL`` (see :mod:`utils.freellm`).
    - Groq is gone: there is no fallback provider and no key rotation.
    - If the endpoint is missing or the request fails the caller still gets a
      `_Completion` whose text is a readable message, so nothing crashes and
      the user sees "AI limit reached ..." instead of a traceback.
    """
    payload_messages = _clean_messages(messages or [])
    wanted = _configured_model() or model
    used_model = freellm.model_for(wanted)
    prompt_chars = sum(len(str(m.get("content") or "")) for m in payload_messages)
    started = time.time()

    if not freellm.is_configured():
        _log_ai(prompt_chars, started, used_model, ok=False, note="no_keys")
        return _Completion(error_message("no_keys"))

    payload = {"messages": payload_messages, "model": used_model}
    if tools:
        payload["tools"] = tools
        payload["tool_choice"] = kwargs.pop("tool_choice", "auto")
    for name in ("temperature", "max_tokens", "top_p"):
        if kwargs.get(name) is not None:
            payload[name] = kwargs[name]

    try:
        data = await freellm.chat(payload)
        completion = _build_completion(data)
        _log_ai(prompt_chars, started, used_model)
        return completion
    except freellm.FreeLLMError as exc:
        logger.warning(f"[FreeLLM] chat failed ({exc.reason}): {exc}")
        _log_ai(prompt_chars, started, used_model, ok=False, note=exc.reason)
        return _Completion(exc.user_message)
    except Exception as exc:  # noqa: BLE001 - never crash a cog over AI
        logger.warning(f"[FreeLLM] chat crashed: {exc}")
        _log_ai(prompt_chars, started, used_model, ok=False, note="crash")
        return _Completion(error_message("unknown"))


async def ask_ai(prompt, system=None, model=None, **kwargs):
    """Small helper: one-shot prompt -> text."""
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    completion = await chat_completion(
        model=model or default_model(),
        messages=messages,
        **kwargs,
    )
    return completion.choices[0].message.content


#: old name kept alive so nothing that imported it breaks
ask_gemini = ask_ai


async def vision_completion(image_bytes, prompt=None, mime_type="image/jpeg", model=None):
    """Describe / analyse an image through FreeLLMAPI vision.

    Returns a `_Completion` (so `.text` and `.choices[0].message.content` both
    work). Raises `AIError` when the backend fails.
    """
    prompt = prompt or "What is shown in this image? Provide a detailed description."
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime_type};base64,{b64}"},
                },
            ],
        }
    ]
    if not freellm.is_configured():
        raise AIError("no_keys")

    data = await freellm.chat(
        {
            "model": freellm.model_for(_configured_model() or model),
            "messages": messages,
            "max_tokens": 1024,
        }
    )
    text = freellm.message_text(((data.get("choices") or [{}])[0].get("message") or {}))
    if not text:
        raise AIError("unknown", "Empty response from model")
    return _Completion(text, raw=data)


async def generate_response(instructions, history):
    if not freellm.is_configured():
        return error_message("no_keys")

    messages = [
        {"role": "system", "name": "instructions", "content": instructions},
        *history,
    ]

    tools = [
        {
            "type": "function",
            "function": {
                "name": "searchtool",
                "description": "Searches the internet.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The query for search engine",
                        }
                    },
                    "required": ["query"],
                },
            },
        }
    ]
    response = await chat_completion(
        model=default_model(),
        messages=messages,
        tools=tools if config.get('INTERNET_ACCESS', True) else None,
    )
    response_message = response.choices[0].message
    tool_calls = response_message.tool_calls

    if tool_calls:
        available_functions = {
            "searchtool": duckduckgotool,
        }
        # append the assistant turn as a plain dict (JSON serialisable)
        messages.append(
            {
                "role": "assistant",
                "content": response_message.content or "",
                "tool_calls": [
                    {
                        "id": c.id,
                        "type": "function",
                        "function": {
                            "name": c.function.name,
                            "arguments": c.function.arguments,
                        },
                    }
                    for c in tool_calls
                ],
            }
        )

        for tool_call in tool_calls:
            function_name = tool_call.function.name
            function_to_call = available_functions.get(function_name)
            if function_to_call is None:
                continue
            try:
                function_args = json.loads(tool_call.function.arguments or "{}")
            except json.JSONDecodeError:
                function_args = {}
            function_response = await function_to_call(
                query=function_args.get("query", "")
            )
            messages.append(
                {
                    "tool_call_id": tool_call.id,
                    "role": "tool",
                    "name": function_name,
                    "content": function_response,
                }
            )
        second_response = await chat_completion(
            model=default_model(),
            messages=messages,
        )
        return second_response.choices[0].message.content
    return response_message.content


async def duckduckgotool(query) -> str:
    if not config.get('INTERNET_ACCESS', True):
        return "internet access has been disabled by user"
    blob = ''
    results = await AsyncDDGS(proxy=None).text(query, max_results=6)
    try:
        for index, result in enumerate(results[:6]):  # Limiting to 6 results
            blob += f'[{index}] Title : {result["title"]}\nSnippet : {result["body"]}\n\n\n Provide a cohesive response base on provided Search results'
    except Exception as e:
        blob += f"Search error: {e}\n"
    return blob


async def poly_image_gen(session, prompt):
    seed = random.randint(1, 100000)
    image_url = f"https://image.pollinations.ai/prompt/{prompt}?seed={seed}"
    async with session.get(image_url) as response:
        image_data = await response.read()
        return io.BytesIO(image_data)

async def generate_image_prodia(prompt, model, sampler, seed, neg):
    print("\033[1;32m(Prodia) Creating image for :\033[0m", prompt)
    start_time = time.time()
    async def create_job(prompt, model, sampler, seed, neg):
        url = 'https://api.prodia.com/generate'
        params = {
            'new': 'true',
            'prompt': f'{quote(prompt)}',
            'model': model,
            'steps': '100',
            'cfg': '9.5',
            'seed': f'{seed}',
            'sampler': sampler,
            'upscale': 'True',
            'aspect_ratio': 'square'
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                data = await response.json()
                return data['job']

    job_id = await create_job(prompt, model, sampler, seed, neg)
    url = f'https://api.prodia.com/job/{job_id}'
    headers = {
        'authority': 'api.prodia.com',
        'accept': '*/*',
    }

    async with aiohttp.ClientSession() as session:
        while True:
            async with session.get(url, headers=headers) as response:
                json = await response.json()
                if json['status'] == 'succeeded':
                    async with session.get(f'https://images.prodia.xyz/{job_id}.png?download=1', headers=headers) as response:
                        content = await response.content.read()
                        img_file_obj = io.BytesIO(content)
                        duration = time.time() - start_time
                        print(f"\033[1;34m(Prodia) Finished image creation\n\033[0mJob id : {job_id}  Prompt : ", prompt, "in", duration, "seconds.")
                        return img_file_obj

async def text_to_speech(text):
    bytes_obj = io.BytesIO()
    detected_language = detect(text)
    tts = gTTS(text=text, lang=detected_language)
    tts.write_to_fp(bytes_obj)
    bytes_obj.seek(0)
    return bytes_obj
