# AI backend — FreeLLMAPI only

Groq support has been **removed**. The bot now has exactly one AI backend: a
single OpenAI-compatible endpoint. No `GROQ_API_KEY` is read anywhere.

## Configuration (`.env`)

```env
FREELLM_API_URL=https://your-freellmapi-host/v1
FREELLM_API_KEY=your_key
FREELLM_MODEL=your_model_name
```

`FREELLM_API_URL` can be the base URL (`.../v1`) or the full
`.../v1/chat/completions` URL. `FREELLM_API_KEY` may be left blank if the
endpoint needs no auth. Image commands need a model that supports vision.

Restart the bot after changing `.env` (or run `aikeys reload` as the owner).

## Where it is implemented

| File | What it does |
| --- | --- |
| `utils/freellm.py` | transport, error mapping, user-facing messages |
| `utils/ai_utils.py` | `chat_completion`, `ask_ai`, `vision_completion`, `generate_response` |
| `utils/groq_keys.py` | compatibility shim only (`key_manager` status, `GroqError` alias) |
| `cogs/commands/aikeys.py` | owner commands: `aikeys status / test / models / reload` |
| `cogs/commands/aifeatures.py` | 14 extra AI commands (free + premium) |

## Owner commands

```
aikeys            backend panel
aikeys test       live test prompt with latency
aikeys models     models the endpoint serves
aikeys reload     re-read .env without restarting
aihub             list every AI Extras command
```

## User-facing failures

| Situation | Message |
| --- | --- |
| `FREELLM_API_URL` missing | 🔑 **No AI configured.** … add `FREELLM_API_URL` … |
| quota used up | ⏳ **AI limit reached.** The free LLM API has used up its quota |
| rate limited | 🚦 **Too many requests.** … give it a minute |
| bad key | 🔑 **Invalid FreeLLMAPI key.** |
| model missing | 🤖 **Model unavailable.** Check `FREELLM_MODEL` |
| provider outage | 🌐 **The AI server is having issues** right now |
